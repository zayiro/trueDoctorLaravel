/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `address_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `address_service` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `address_id` bigint(20) unsigned NOT NULL,
  `service_id` bigint(20) unsigned NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `duration` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `address_service_address_id_foreign` (`address_id`),
  KEY `address_service_service_id_foreign` (`service_id`),
  CONSTRAINT `address_service_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `address_service_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `address_service` WRITE;
/*!40000 ALTER TABLE `address_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_service` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned DEFAULT NULL,
  `clinic_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'physical',
  `phone` varchar(255) DEFAULT NULL,
  `city_id` varchar(5) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addresses_doctor_id_foreign` (`doctor_id`),
  KEY `addresses_clinic_id_foreign` (`clinic_id`),
  KEY `addresses_city_id_foreign` (`city_id`),
  CONSTRAINT `addresses_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(20) NOT NULL,
  `patient_id` bigint(20) unsigned NOT NULL,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `clinic_id` bigint(20) unsigned DEFAULT NULL,
  `service_id` bigint(20) unsigned NOT NULL,
  `address_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `duration` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `meeting_link` text DEFAULT NULL COMMENT 'Enlace genérico o exclusivo para el Paciente',
  `zoom_meeting_id` varchar(255) DEFAULT NULL COMMENT 'ID numérico de la reunión en Zoom',
  `meeting_link_password` text DEFAULT NULL COMMENT 'Contraseña cifrada de la sala de Zoom para el Meeting SDK',
  `zoom_start_url` text DEFAULT NULL COMMENT 'Enlace exclusivo para que el Doctor inicie como Anfitrión',
  `status` enum('pending','confirmed','cancelled','completed') NOT NULL DEFAULT 'pending',
  `channel` enum('app','web','whatsapp') NOT NULL DEFAULT 'web',
  `notes` text DEFAULT NULL,
  `email_sent` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `appointments_reference_unique` (`reference`),
  KEY `appointments_patient_id_foreign` (`patient_id`),
  KEY `appointments_clinic_id_foreign` (`clinic_id`),
  KEY `appointments_service_id_foreign` (`service_id`),
  KEY `appointments_address_id_foreign` (`address_id`),
  KEY `appointments_doctor_date_time_index` (`doctor_id`,`date`,`start_time`),
  CONSTRAINT `appointments_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`),
  CONSTRAINT `appointments_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE SET NULL,
  CONSTRAINT `appointments_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`),
  CONSTRAINT `appointments_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `appointments_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaigns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `content` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaigns_doctor_id_slug_unique` (`doctor_id`,`slug`),
  CONSTRAINT `campaigns_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `campaigns` WRITE;
/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cities` (
  `id` varchar(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department_id` varchar(5) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cities_slug_unique` (`slug`),
  KEY `cities_department_id_foreign` (`department_id`),
  CONSTRAINT `cities_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES ('05001','Medellín','05','medellin',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('08001','Barranquilla','08','barranquilla',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('11001','Bogotá','11','bogota',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('13001','Cartagena','13','cartagena',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('15001','Tunja','15','tunja',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('17001','Manizales','17','manizales',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('19001','Popayán','19','popayan',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('20001','Valledupar','20','valledupar',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('23001','Montería','23','monteria',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('41001','Neiva','41','neiva',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('44001','Riohacha','44','riohacha',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('47001','Santa Marta','47','santa-marta',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('50001','Villavicencio','50','villavicencio',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('52001','Pasto','52','pasto',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('54001','Cúcuta','54','cucuta',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('63001','Armenia','63','armenia',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('66001','Pereira','66','pereira',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('68001','Bucaramanga','68','bucaramanga',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('70001','Sincelejo','70','sincelejo',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('73001','Ibagué','73','ibague',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('76001','Cali','76','cali',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('76520','Palmira','76','palmira',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),('88001','San Andrés','88','san-andres',1,'2026-06-07 12:03:26','2026-06-07 12:03:26');
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clinic_doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinic_doctor` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(20) unsigned NOT NULL,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending' COMMENT 'pending, approved, rejected, inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clinic_doctor_clinic_id_doctor_id_unique` (`clinic_id`,`doctor_id`),
  KEY `clinic_doctor_doctor_id_foreign` (`doctor_id`),
  CONSTRAINT `clinic_doctor_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clinic_doctor_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clinic_doctor` WRITE;
/*!40000 ALTER TABLE `clinic_doctor` DISABLE KEYS */;
/*!40000 ALTER TABLE `clinic_doctor` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clinic_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinic_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(20) unsigned NOT NULL,
  `plan_id` bigint(20) unsigned DEFAULT NULL,
  `accepts_online_payments` tinyint(1) NOT NULL DEFAULT 0,
  `currency` varchar(255) NOT NULL DEFAULT 'COP',
  `min_notice_hours` int(11) NOT NULL DEFAULT 2,
  `max_advance_days` int(11) NOT NULL DEFAULT 30,
  `requires_approval` tinyint(1) NOT NULL DEFAULT 0,
  `buffer_time_minutes` int(10) unsigned NOT NULL DEFAULT 0,
  `max_appointments_per_day` int(10) unsigned DEFAULT NULL,
  `allow_patient_cancellation` tinyint(1) NOT NULL DEFAULT 1,
  `cancellation_notice_hours` int(10) unsigned NOT NULL DEFAULT 2,
  `allow_patient_rescheduling` tinyint(1) NOT NULL DEFAULT 1,
  `virtual_meeting_platform` varchar(255) NOT NULL DEFAULT 'internal',
  `google_calendar_sync` tinyint(1) NOT NULL DEFAULT 0,
  `email_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `whatsapp_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clinic_settings_clinic_id_foreign` (`clinic_id`),
  KEY `clinic_settings_plan_id_foreign` (`plan_id`),
  CONSTRAINT `clinic_settings_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clinic_settings_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clinic_settings` WRITE;
/*!40000 ALTER TABLE `clinic_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `clinic_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clinic_specialty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinic_specialty` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(20) unsigned NOT NULL,
  `specialty_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clinic_specialty_specialty_id_foreign` (`specialty_id`),
  KEY `clinic_specialty_clinic_id_specialty_id_index` (`clinic_id`,`specialty_id`),
  CONSTRAINT `clinic_specialty_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clinic_specialty_specialty_id_foreign` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clinic_specialty` WRITE;
/*!40000 ALTER TABLE `clinic_specialty` DISABLE KEYS */;
/*!40000 ALTER TABLE `clinic_specialty` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clinics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `nit` varchar(255) NOT NULL,
  `reps_code` varchar(12) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `experience_years` varchar(255) DEFAULT NULL,
  `rating` decimal(3,2) NOT NULL DEFAULT 0.00,
  `reviews_count` int(11) NOT NULL DEFAULT 0,
  `validation_status` varchar(255) NOT NULL DEFAULT 'missing' COMMENT 'Estados: missing, pending_validation, approved, rejected',
  `identity_card_path` varchar(255) DEFAULT NULL,
  `reps_code_card_path` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clinics_slug_unique` (`slug`),
  UNIQUE KEY `clinics_nit_unique` (`nit`),
  UNIQUE KEY `clinics_reps_code_unique` (`reps_code`),
  KEY `clinics_user_id_foreign` (`user_id`),
  CONSTRAINT `clinics_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clinics` WRITE;
/*!40000 ALTER TABLE `clinics` DISABLE KEYS */;
/*!40000 ALTER TABLE `clinics` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contact_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contact_messages` WRITE;
/*!40000 ALTER TABLE `contact_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` varchar(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES ('05','Antioquia',NULL,NULL),('08','Atlántico',NULL,NULL),('11','Bogotá D.C.',NULL,NULL),('13','Bolívar',NULL,NULL),('15','Boyacá',NULL,NULL),('17','Caldas',NULL,NULL),('18','Caquetá',NULL,NULL),('19','Cauca',NULL,NULL),('20','Cesar',NULL,NULL),('23','Córdoba',NULL,NULL),('25','Cundinamarca',NULL,NULL),('27','Chocó',NULL,NULL),('41','Huila',NULL,NULL),('44','La Guajira',NULL,NULL),('47','Magdalena',NULL,NULL),('50','Meta',NULL,NULL),('52','Nariño',NULL,NULL),('54','Norte de Santander',NULL,NULL),('63','Quindío',NULL,NULL),('66','Risaralda',NULL,NULL),('68','Santander',NULL,NULL),('70','Sucre',NULL,NULL),('73','Tolima',NULL,NULL),('76','Valle del Cauca',NULL,NULL),('81','Arauca',NULL,NULL),('85','Casanare',NULL,NULL),('86','Putumayo',NULL,NULL),('88','Archipiélago de San Andrés',NULL,NULL),('91','Amazonas',NULL,NULL),('94','Guainía',NULL,NULL),('95','Guaviare',NULL,NULL),('97','Vaupés',NULL,NULL),('99','Vichada',NULL,NULL);
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `doctor_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `plan_id` bigint(20) unsigned DEFAULT NULL,
  `accepts_online_payments` tinyint(1) NOT NULL DEFAULT 0,
  `currency` varchar(255) NOT NULL DEFAULT 'COP',
  `min_notice_hours` int(11) NOT NULL DEFAULT 2,
  `max_advance_days` int(11) NOT NULL DEFAULT 30,
  `requires_approval` tinyint(1) NOT NULL DEFAULT 0,
  `buffer_time_minutes` int(10) unsigned NOT NULL DEFAULT 0,
  `max_appointments_per_day` int(10) unsigned DEFAULT NULL,
  `allow_patient_cancellation` tinyint(1) NOT NULL DEFAULT 1,
  `cancellation_notice_hours` int(10) unsigned NOT NULL DEFAULT 2,
  `allow_patient_rescheduling` tinyint(1) NOT NULL DEFAULT 1,
  `virtual_meeting_platform` varchar(255) NOT NULL DEFAULT 'internal',
  `google_calendar_sync` tinyint(1) NOT NULL DEFAULT 0,
  `email_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `whatsapp_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `doctor_settings_doctor_id_foreign` (`doctor_id`),
  KEY `doctor_settings_plan_id_foreign` (`plan_id`),
  CONSTRAINT `doctor_settings_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `doctor_settings_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `doctor_settings` WRITE;
/*!40000 ALTER TABLE `doctor_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `doctor_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `doctor_specialty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor_specialty` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `specialty_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `doctor_specialty_specialty_id_foreign` (`specialty_id`),
  KEY `doctor_specialty_doctor_id_specialty_id_index` (`doctor_id`,`specialty_id`),
  CONSTRAINT `doctor_specialty_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `doctor_specialty_specialty_id_foreign` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `doctor_specialty` WRITE;
/*!40000 ALTER TABLE `doctor_specialty` DISABLE KEYS */;
/*!40000 ALTER TABLE `doctor_specialty` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `medical_license` varchar(255) DEFAULT NULL,
  `identification` varchar(255) NOT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `experience_years` varchar(255) DEFAULT NULL,
  `languages` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '["es"]' CHECK (json_valid(`languages`)),
  `rating` decimal(3,2) NOT NULL DEFAULT 0.00,
  `reviews_count` int(11) NOT NULL DEFAULT 0,
  `validation_status` varchar(255) NOT NULL DEFAULT 'missing' COMMENT 'Estados: missing, pending_validation, approved, rejected',
  `identity_card_path` varchar(255) DEFAULT NULL,
  `professional_card_path` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `doctors_slug_unique` (`slug`),
  UNIQUE KEY `doctors_identification_unique` (`identification`),
  KEY `doctors_user_id_foreign` (`user_id`),
  CONSTRAINT `doctors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `exam_analyses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_analyses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `customer_email` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `reason_type` varchar(255) NOT NULL,
  `reason_custom` text DEFAULT NULL,
  `payment_id` varchar(255) DEFAULT NULL,
  `payment_status` enum('pending','paid','failed') NOT NULL DEFAULT 'pending',
  `price` decimal(8,2) NOT NULL DEFAULT 4.99,
  `ai_result` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ai_result`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exam_analyses_user_id_foreign` (`user_id`),
  CONSTRAINT `exam_analyses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `exam_analyses` WRITE;
/*!40000 ALTER TABLE `exam_analyses` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_analyses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `indexed_symptoms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `indexed_symptoms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `search_query` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `specialty_id` bigint(20) unsigned DEFAULT NULL,
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `urgency_level` varchar(255) DEFAULT NULL,
  `ai_advice` text DEFAULT NULL,
  `search_count` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `indexed_symptoms_search_query_unique` (`search_query`),
  UNIQUE KEY `indexed_symptoms_slug_unique` (`slug`),
  KEY `indexed_symptoms_specialty_id_foreign` (`specialty_id`),
  CONSTRAINT `indexed_symptoms_specialty_id_foreign` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `indexed_symptoms` WRITE;
/*!40000 ALTER TABLE `indexed_symptoms` DISABLE KEYS */;
INSERT INTO `indexed_symptoms` VALUES (1,'Fiebre alta que no baja','fiebre-alta-que-no-baja',1,'¿Sientes Fiebre alta que no baja? Orientación Médica Online','¿Sufres de fiebre alta que no baja? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Si la fiebre supera los 38.5°C por más de 48 horas o se acompaña de rigidez en el cuello, es vital una valoración médica presencial.',39,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(2,'Fatiga crónica y cansancio extremo','fatiga-cronica-y-cansancio-extremo',1,'¿Sientes Fatiga crónica y cansancio extremo? Orientación Médica Online','¿Sufres de fatiga crónica y cansancio extremo? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','El cansancio persistente puede deberse a anemias, problemas tiroideos o deficiencias vitamínicas. Requiere analítica de sangre.',14,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(3,'Pérdida de peso repentina sin hacer dieta','perdida-de-peso-repentina-sin-hacer-dieta',1,'¿Sientes Pérdida de peso repentina sin hacer dieta? Orientación Médica Online','¿Sufres de pérdida de peso repentina sin hacer dieta? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Una pérdida de peso inexplicable requiere descartar problemas metabólicos o condiciones subyacentes con un médico internista.',13,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(4,'Sudores nocturnos excesivos','sudores-nocturnos-excesivos',1,'¿Sientes Sudores nocturnos excesivos? Orientación Médica Online','¿Sufres de sudores nocturnos excesivos? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Sudar intensamente por las noches de forma recurrente amerita un chequeo médico completo para evaluar causas del sistema inmune o linfático.',27,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(5,'Presión arterial alta síntomas','presion-arterial-alta-sintomas',1,'¿Sientes Presión arterial alta síntomas? Orientación Médica Online','¿Sufres de presión arterial alta síntomas? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','La hipertensión suele ser silenciosa, pero si presenta dolor de cabeza fuerte o zumbido en oídos, debe tomarse la presión de inmediato.',38,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(6,'Fiebre en bebés de tres meses','fiebre-en-bebes-de-tres-meses',4,'¿Sientes Fiebre en bebés de tres meses? Orientación Médica Online','¿Sufres de fiebre en bebés de tres meses? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Alta','Cualquier pico febril en lactantes menores de 3 meses debe ser evaluado urgentemente por un pediatra de guardia.',35,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(7,'Cólicos fuertes en lactantes','colicos-fuertes-en-lactantes',4,'¿Sientes Cólicos fuertes en lactantes? Orientación Médica Online','¿Sufres de cólicos fuertes en lactantes? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Los cólicos son comunes el primer trimestre, pero si hay vómitos constantes o llanto inconsolable por horas, consulte al pediatra.',43,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(8,'Brote en la piel de niños con fiebre','brote-en-la-piel-de-ninos-con-fiebre',4,'¿Sientes Brote en la piel de niños con fiebre? Orientación Médica Online','¿Sufres de brote en la piel de niños con fiebre? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Alta','Las erupciones cutáneas acompañadas de fiebre pueden indicar infecciones exantemáticas que requieren diagnóstico pediátrico inmediato.',25,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(9,'Tos perruna en niños por la noche','tos-perruna-en-ninos-por-la-noche',4,'¿Sientes Tos perruna en niños por la noche? Orientación Médica Online','¿Sufres de tos perruna en niños por la noche? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Suele deberse a laringitis. Mantener al niño en un ambiente húmedo ayuda, pero vigile que no tenga dificultad para respirar.',26,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(10,'Retraso menstrual y dolor de ovarios','retraso-menstrual-y-dolor-de-ovarios',6,'¿Sientes Retraso menstrual y dolor de ovarios? Orientación Médica Online','¿Sufres de retraso menstrual y dolor de ovarios? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Descarte primero un embarazo. Si es negativo, los desajustes hormonales o quistes ováricos deben ser evaluados por un ginecólogo.',21,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(11,'Flujo vaginal con mal olor y picazón','flujo-vaginal-con-mal-olor-y-picazon',6,'¿Sientes Flujo vaginal con mal olor y picazón? Orientación Médica Online','¿Sufres de flujo vaginal con mal olor y picazón? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Son síntomas claros de una infección por hongos o bacteriana. Evite la automedicación y asista a una consulta para frotis.',50,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(12,'Sangrado fuera del periodo menstrual','sangrado-fuera-del-periodo-menstrual',6,'¿Sientes Sangrado fuera del periodo menstrual? Orientación Médica Online','¿Sufres de sangrado fuera del periodo menstrual? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','El sangrado intermenstrual debe ser valorado mediante ecografía para descartar pólipos, miomas o alteraciones endometriales.',35,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(13,'Dolor menstrual muy fuerte que incapacita','dolor-menstrual-muy-fuerte-que-incapacita',6,'¿Sientes Dolor menstrual muy fuerte que incapacita? Orientación Médica Online','¿Sufres de dolor menstrual muy fuerte que incapacita? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','La dismenorrea severa no es normal y puede ser señal de endometriosis. Un especialista debe realizar una evaluación detallada.',32,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(14,'Dolor en el pecho que se va al brazo izquierdo','dolor-en-el-pecho-que-se-va-al-brazo-izquierdo',3,'¿Sientes Dolor en el pecho que se va al brazo izquierdo? Orientación Médica Online','¿Sufres de dolor en el pecho que se va al brazo izquierdo? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Alta','Este es un síntoma de alarma de infarto. Acuda inmediatamente a la sala de emergencias más cercana. No espere.',25,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(15,'Palpitaciones fuertes en el pecho en reposo','palpitaciones-fuertes-en-el-pecho-en-reposo',3,'¿Sientes Palpitaciones fuertes en el pecho en reposo? Orientación Médica Online','¿Sufres de palpitaciones fuertes en el pecho en reposo? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Sentir el ritmo cardíaco acelerado sin hacer esfuerzo requiere un electrocardiograma para descartar arritmias.',50,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(16,'Falta de aire al caminar poco','falta-de-aire-al-caminar-poco',3,'¿Sientes Falta de aire al caminar poco? Orientación Médica Online','¿Sufres de falta de aire al caminar poco? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','La disnea de esfuerzo puede vincularse a insuficiencia cardíaca o problemas pulmonares. Requiere valoración cardiológica.',47,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(17,'Lunar que cambia de color y bordes irregulares','lunar-que-cambia-de-color-y-bordes-irregulares',5,'¿Sientes Lunar que cambia de color y bordes irregulares? Orientación Médica Online','¿Sufres de lunar que cambia de color y bordes irregulares? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Sigue la regla ABCDE del melanoma. Cualquier cambio de tamaño, borde o color exige una revisión con dermatoscopio.',49,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(18,'Caída del cabello por estrés en mujeres','caida-del-cabello-por-estres-en-mujeres',5,'¿Sientes Caída del cabello por estrés en mujeres? Orientación Médica Online','¿Sufres de caída del cabello por estrés en mujeres? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','El efluvio telógeno es común tras periodos de estrés. Un dermatólogo puede guiarte con lociones y suplementos específicos.',19,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(19,'Manchas rojas en la piel que pican mucho','manchas-rojas-en-la-piel-que-pican-mucho',5,'¿Sientes Manchas rojas en la piel que pican mucho? Orientación Médica Online','¿Sufres de manchas rojas en la piel que pican mucho? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Puede tratarse de dermatitis, eccemas o urticaria. Evite rascarse para no causar infecciones bacterianas secundarias.',49,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(20,'Acné quístico severo en la edad adulta','acne-quistico-severo-en-la-edad-adulta',5,'¿Sientes Acné quístico severo en la edad adulta? Orientación Médica Online','¿Sufres de acné quístico severo en la edad adulta? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','El acné nodular requiere tratamientos médicos dermatológicos regulados para evitar cicatrices profundas en la piel.',40,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(21,'Dolor de espalda baja que baja por la pierna','dolor-de-espalda-baja-que-baja-por-la-pierna',10,'¿Sientes Dolor de espalda baja que baja por la pierna? Orientación Médica Online','¿Sufres de dolor de espalda baja que baja por la pierna? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Suele indicar una compresión del nervio ciático o hernia discal. Evite cargar peso y consulte con un especialista.',46,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(22,'Dolor de rodilla al bajar escaleras','dolor-de-rodilla-al-bajar-escaleras',10,'¿Sientes Dolor de rodilla al bajar escaleras? Orientación Médica Online','¿Sufres de dolor de rodilla al bajar escaleras? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Común en problemas de desgaste de cartílago (condromalacia) o meniscos. Un traumatólogo evaluará si requiere resonancia.',22,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(23,'Esguince de tobillo hinchado y morado','esguince-de-tobillo-hinchado-y-morado',10,'¿Sientes Esguince de tobillo hinchado y morado? Orientación Médica Online','¿Sufres de esguince de tobillo hinchado y morado? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Aplique hielo y mantenga el pie elevado. Es necesario una radiografía para descartar microfracturas óseas.',11,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(24,'Gastritis crónica y ardor en la boca del estómago','gastritis-cronica-y-ardor-en-la-boca-del-estomago',1,'¿Sientes Gastritis crónica y ardor en la boca del estómago? Orientación Médica Online','¿Sufres de gastritis crónica y ardor en la boca del estómago? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','El reflujo y ardor constante pueden requerir una endoscopia para descartar la bacteria Helicobacter pylori.',11,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(25,'Estreñimiento severo de varios días','estrenimiento-severo-de-varios-dias',1,'¿Sientes Estreñimiento severo de varios días? Orientación Médica Online','¿Sufres de estreñimiento severo de varios días? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Aumente el consumo de agua y fibra. Si se acompaña de dolor abdominal intenso o vómitos, acuda a urgencias.',34,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(26,'Sangre roja brillante al evacuar','sangre-roja-brillante-al-evacuar',1,'¿Sientes Sangre roja brillante al evacuar? Orientación Médica Online','¿Sufres de sangre roja brillante al evacuar? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Frecuente en hemorroides o fisuras, pero es mandatorio un chequeo proctológico para descartar patologías mayores del colon.',14,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(27,'Hinchazón abdominal y gases después de comer','hinchazon-abdominal-y-gases-despues-de-comer',1,'¿Sientes Hinchazón abdominal y gases después de comer? Orientación Médica Online','¿Sufres de hinchazón abdominal y gases después de comer? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Puede estar asociado al síndrome de intestino irritable o intolerancias alimentarias (gluten, lactosa).',26,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(28,'Dolor de cabeza insoportable con sensibilidad a la luz','dolor-de-cabeza-insoportable-con-sensibilidad-a-la-luz',1,'¿Sientes Dolor de cabeza insoportable con sensibilidad a la luz? Orientación Médica Online','¿Sufres de dolor de cabeza insoportable con sensibilidad a la luz? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Son síntomas clásicos de migraña con fotofobia. Un neurólogo te ayudará a establecer un tratamiento preventivo eficaz.',33,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(29,'Mareos constantes al mover la cabeza','mareos-constantes-al-mover-la-cabeza',1,'¿Sientes Mareos constantes al mover la cabeza? Orientación Médica Online','¿Sufres de mareos constantes al mover la cabeza? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Puede relacionarse con vértigo posicional paroxístico benigno o problemas del oído interno. Requiere diagnóstico.',25,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(30,'Hormigueo y entumecimiento en las manos por las noches','hormigueo-y-entumecimiento-en-las-manos-por-las-noches',1,'¿Sientes Hormigueo y entumecimiento en las manos por las noches? Orientación Médica Online','¿Sufres de hormigueo y entumecimiento en las manos por las noches? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Síntoma muy habitual del síndrome del túnel carpiano debido a la compresión del nervio mediano en la muñeca.',37,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(31,'Zumbido en el oído constante (Tinnitus)','zumbido-en-el-oido-constante-tinnitus',7,'¿Sientes Zumbido en el oído constante (Tinnitus)? Orientación Médica Online','¿Sufres de zumbido en el oído constante (tinnitus)? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','El tinnitus requiere un estudio audiológico completo para determinar si existe pérdida auditiva asociada.',47,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(32,'Dolor de oído fuerte después de nadar','dolor-de-oido-fuerte-despues-de-nadar',7,'¿Sientes Dolor de oído fuerte después de nadar? Orientación Médica Online','¿Sufres de dolor de oído fuerte después de nadar? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Indica una otitis externa (oído de nadador). Suele requerir gotas antibióticas recetadas por el médico.',24,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(33,'Pérdida del olfato y congestión nasal crónica','perdida-del-olfato-y-congestion-nasal-cronica',7,'¿Sientes Pérdida del olfato y congestión nasal crónica? Orientación Médica Online','¿Sufres de pérdida del olfato y congestión nasal crónica? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','La sinusitis crónica o los pólipos nasales pueden obstruir las vías. Se recomienda una nasosinusoscopia.',17,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(34,'Ardor intenso al orinar y ganas constantes','ardor-intenso-al-orinar-y-ganas-constantes',11,'¿Sientes Ardor intenso al orinar y ganas constantes? Orientación Médica Online','¿Sufres de ardor intenso al orinar y ganas constantes? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Síntomas comunes de infección urinaria (cistitis). Requiere un examen de orina (urocultivo) para dar el antibiótico correcto.',22,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(35,'Dificultad para orinar y chorro débil en hombres','dificultad-para-orinar-y-chorro-debil-en-hombres',11,'¿Sientes Dificultad para orinar y chorro débil en hombres? Orientación Médica Online','¿Sufres de dificultad para orinar y chorro débil en hombres? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','En hombres mayores de 45 años suele indicar un crecimiento de la próstata (hiperplasia). Requiere control anual urológico.',46,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(36,'Visión borrosa de repente en un ojo','vision-borrosa-de-repente-en-un-ojo',8,'¿Sientes Visión borrosa de repente en un ojo? Orientación Médica Online','¿Sufres de visión borrosa de repente en un ojo? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Alta','La pérdida súbita de visión es una emergencia médica que puede deberse a desprendimiento de retina o problemas vasculares.',13,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(37,'Ojos rojos con lagaña verde y picazón','ojos-rojos-con-lagana-verde-y-picazon',8,'¿Sientes Ojos rojos con lagaña verde y picazón? Orientación Médica Online','¿Sufres de ojos rojos con lagaña verde y picazón? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Suelen ser signos de conjuntivitis bacteriana. Evite tocarse los ojos para no contagiar el otro ojo y use gotas indicadas.',42,'2026-06-07 12:03:26','2026-06-07 12:03:26');
/*!40000 ALTER TABLE `indexed_symptoms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `insurances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `insurances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `insurances_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `insurances` WRITE;
/*!40000 ALTER TABLE `insurances` DISABLE KEYS */;
INSERT INTO `insurances` VALUES (1,'Particular / Prepagada','PART01',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(2,'EPS SURA','EPS010',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(3,'EPS Sanitas','EPS005',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(4,'Salud Total','EPS002',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(5,'Nueva EPS','EPS037',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(6,'Compensar EPS','EPS008',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(7,'Coosalud','ESS024',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(8,'Aliansalud','EPS001',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(9,'Famisanar','EPS017',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(10,'S.O.S','EPS018',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(11,'Salud Mía','EPS046',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(12,'Mutual Ser','EPS048',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(13,'Asmet Salud','ESS062',1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(14,'Capital Salud','EPSS37',1,'2026-06-07 12:03:26','2026-06-07 12:03:26');
/*!40000 ALTER TABLE `insurances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` smallint(5) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (1,'default','{\"uuid\":\"60dbc113-479b-4786-ad04-bd0d949d84c7\",\"displayName\":\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\",\"command\":\"O:35:\\\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\\\":0:{}\",\"batchId\":null},\"createdAt\":1780852205,\"delay\":null}',0,NULL,1780852205,1780852205),(2,'default','{\"uuid\":\"23e28e56-a2eb-46cc-a7ea-677d3159af2e\",\"displayName\":\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\",\"command\":\"O:35:\\\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\\\":0:{}\",\"batchId\":null},\"createdAt\":1780852205,\"delay\":null}',0,NULL,1780852205,1780852205),(3,'default','{\"uuid\":\"f0237612-9a20-415d-aa34-6e431b14b8e0\",\"displayName\":\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\",\"command\":\"O:35:\\\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\\\":0:{}\",\"batchId\":null},\"createdAt\":1780852803,\"delay\":null}',0,NULL,1780852803,1780852803),(4,'default','{\"uuid\":\"179d21d0-bcb8-48d2-8566-b211638a1823\",\"displayName\":\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\",\"command\":\"O:35:\\\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\\\":0:{}\",\"batchId\":null},\"createdAt\":1780852804,\"delay\":null}',0,NULL,1780852804,1780852804),(5,'default','{\"uuid\":\"49b78d08-2248-42e6-a4cb-d8897a353579\",\"displayName\":\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\",\"command\":\"O:35:\\\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\\\":0:{}\",\"batchId\":null},\"createdAt\":1780853406,\"delay\":null}',0,NULL,1780853406,1780853406),(6,'default','{\"uuid\":\"06019d0d-52b6-4946-8d78-e294e0d92189\",\"displayName\":\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\",\"command\":\"O:35:\\\"App\\\\Jobs\\\\ProcessPendingZoomMeetings\\\":0:{}\",\"batchId\":null},\"createdAt\":1780853406,\"delay\":null}',0,NULL,1780853406,1780853406);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `medical_expertises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medical_expertises` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `disease_name` varchar(255) NOT NULL,
  `symptoms_keywords` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `medical_expertises_doctor_id_foreign` (`doctor_id`),
  FULLTEXT KEY `medical_expertises_disease_name_symptoms_keywords_fulltext` (`disease_name`,`symptoms_keywords`),
  CONSTRAINT `medical_expertises_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `medical_expertises` WRITE;
/*!40000 ALTER TABLE `medical_expertises` DISABLE KEYS */;
/*!40000 ALTER TABLE `medical_expertises` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_04_26_153750_add_two_factor_columns_to_users_table',1),(5,'2026_04_26_153800_create_personal_access_tokens_table',1),(6,'2026_04_28_150005_create_permission_tables',1),(7,'2026_04_28_205305_create_plans_table',1),(8,'2026_04_28_205306_create_specialties_table',1),(9,'2026_04_28_205307_create_doctors_table',1),(10,'2026_04_28_205316_create_insurances_table',1),(11,'2026_04_28_205317_create_patients_table',1),(12,'2026_04_28_205330_create_departments_table',1),(13,'2026_04_28_205331_create_cities_table',1),(14,'2026_04_28_205332_create_clinics_table',1),(15,'2026_04_28_205333_create_addresses_table',1),(16,'2026_04_28_205341_create_schedules_table',1),(17,'2026_04_28_205347_create_services_table',1),(18,'2026_04_28_205348_create_appointments_table',1),(19,'2026_04_28_205622_create_unavailabilities_table',1),(20,'2026_04_30_235804_create_doctor_specialty_table',1),(21,'2026_05_01_094154_create_reviews_table',1),(22,'2026_05_01_105657_create_address_service_table',1),(23,'2026_05_02_070138_create_notifications_table',1),(24,'2026_05_02_180444_create_campaigns_table',1),(25,'2026_05_03_112915_create_contact_messages_table',1),(26,'2026_05_04_192852_create_doctor_settings_table',1),(27,'2026_05_06_220100_create_patient_allergies_table',1),(28,'2026_05_06_220251_create_patient_surgeries_table',1),(29,'2026_05_06_220343_create_patient_family_histories_table',1),(30,'2026_05_06_220704_create_patient_medications_table',1),(31,'2026_05_06_220847_create_patient_histories_table',1),(32,'2026_05_06_223654_create_patient_consents_table',1),(33,'2026_05_13_183846_create_medical_expertises_table',1),(34,'2026_05_22_143009_create_indexed_symptoms_table',1),(35,'2026_05_23_225607_create_exam_analyses_table',1),(36,'2026_05_24_101730_create_clinic_settings_table',1),(37,'2026_05_24_125649_create_clinic_doctor_table',1),(38,'2026_05_26_184832_create_clinic_specialty_table',1),(39,'2026_05_29_064954_create_patient_history_attachments_table',1),(40,'2026_06_01_200144_create_zoom_creation_failures_table',1),(41,'2026_06_06_203044_create_service_specialty_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (3,'App\\Models\\User',1);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_allergies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_allergies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('drug','food','environment','other') NOT NULL DEFAULT 'other',
  `severity` enum('mild','moderate','severe') NOT NULL DEFAULT 'mild',
  `reaction` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_allergies_patient_id_foreign` (`patient_id`),
  CONSTRAINT `patient_allergies_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_allergies` WRITE;
/*!40000 ALTER TABLE `patient_allergies` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_allergies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_consents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_consents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `signed_at` datetime NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_consents_patient_id_foreign` (`patient_id`),
  KEY `patient_consents_doctor_id_foreign` (`doctor_id`),
  CONSTRAINT `patient_consents_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`),
  CONSTRAINT `patient_consents_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_consents` WRITE;
/*!40000 ALTER TABLE `patient_consents` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_consents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_family_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_family_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `condition` varchar(255) NOT NULL,
  `relationship` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_family_histories_patient_id_foreign` (`patient_id`),
  CONSTRAINT `patient_family_histories_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_family_histories` WRITE;
/*!40000 ALTER TABLE `patient_family_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_family_histories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `appointment_id` bigint(20) unsigned DEFAULT NULL,
  `reason_for_consultation` varchar(255) NOT NULL,
  `entry_type` enum('consultation','follow_up','emergency','note') NOT NULL,
  `symptoms` text DEFAULT NULL,
  `diagnosis` text NOT NULL,
  `treatment_plan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_histories_patient_id_foreign` (`patient_id`),
  KEY `patient_histories_doctor_id_foreign` (`doctor_id`),
  KEY `patient_histories_appointment_id_foreign` (`appointment_id`),
  CONSTRAINT `patient_histories_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `patient_histories_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_histories_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_histories` WRITE;
/*!40000 ALTER TABLE `patient_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_histories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_history_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_history_attachments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `1` (`patient_id`),
  CONSTRAINT `1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_history_attachments` WRITE;
/*!40000 ALTER TABLE `patient_history_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_history_attachments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_medications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_medications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `dosage` varchar(255) DEFAULT NULL,
  `frequency` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_medications_patient_id_foreign` (`patient_id`),
  CONSTRAINT `patient_medications_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_medications` WRITE;
/*!40000 ALTER TABLE `patient_medications` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_medications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_surgeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_surgeries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `year` year(4) DEFAULT NULL,
  `observations` text DEFAULT NULL,
  `anesthesia_complications` tinyint(1) NOT NULL DEFAULT 0,
  `anesthesia_details` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_surgeries_patient_id_foreign` (`patient_id`),
  CONSTRAINT `patient_surgeries_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_surgeries` WRITE;
/*!40000 ALTER TABLE `patient_surgeries` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_surgeries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `identification` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `blood_type` enum('A+','A-','B+','B-','O+','O-','AB+','AB-') DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `weight` decimal(5,2) DEFAULT NULL,
  `height` decimal(3,2) DEFAULT NULL,
  `insurance_id` bigint(20) unsigned DEFAULT NULL,
  `permanent_conditions` text DEFAULT NULL,
  `department_id` varchar(5) DEFAULT NULL,
  `city_id` varchar(5) DEFAULT NULL,
  `residence_zone` enum('Urbana','Rural') NOT NULL DEFAULT 'Urbana',
  `occupation` varchar(255) DEFAULT NULL,
  `civil_status` enum('Soltero/a','Casado/a','Unión Libre','Divorciado/a','Viudo/a') DEFAULT NULL,
  `ethnicity` enum('Indígena','Rrom (Gitano)','Raizal (San Andrés y Providencia)','Palenquero (San Basilio de Palenque)','Negro, Mulato, Afrocolombiano','Ninguna de las anteriores (Mestizo/Blanco)') NOT NULL DEFAULT 'Ninguna de las anteriores (Mestizo/Blanco)',
  `affiliation_type` enum('Contributivo','Subsidiado','Vinculado','Particular','Otro') DEFAULT NULL,
  `regime_type` enum('General','Especial','Excepción') NOT NULL DEFAULT 'General',
  `sisben_level` varchar(5) DEFAULT NULL,
  `emergency_contact_name` varchar(255) DEFAULT NULL,
  `emergency_contact_phone` varchar(255) DEFAULT NULL,
  `emergency_contact_relationship` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `patients_user_id_unique` (`user_id`),
  UNIQUE KEY `patients_identification_unique` (`identification`),
  KEY `patients_insurance_id_foreign` (`insurance_id`),
  CONSTRAINT `patients_insurance_id_foreign` FOREIGN KEY (`insurance_id`) REFERENCES `insurances` (`id`),
  CONSTRAINT `patients_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `plans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `plan` varchar(255) NOT NULL,
  `max_addresses` int(11) NOT NULL DEFAULT 2,
  `max_services` int(11) NOT NULL DEFAULT 3,
  `max_doctors` int(11) NOT NULL DEFAULT 1,
  `max_appointments_per_year` int(11) NOT NULL DEFAULT 50,
  `can_search_patients` tinyint(1) NOT NULL DEFAULT 0,
  `can_see_whatsapp_contact_button` tinyint(1) NOT NULL DEFAULT 0,
  `max_patients_list` int(11) NOT NULL DEFAULT 20,
  `can_export_history` tinyint(1) NOT NULL DEFAULT 0,
  `has_telemedicine` tinyint(1) NOT NULL DEFAULT 1,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plans_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` VALUES (1,'Plan Free','free','free',2,3,1,50,0,0,20,0,1,0.00,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(2,'Plan Premium','premium','premium',10,20,1,500,1,1,200,1,1,2400000.00,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(3,'Plan Gold','gold','gold',20,50,1,9999,1,1,10000,1,1,3500000.00,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(4,'Plan Clínica Gold','clinic_gold','clinic_gold',15,100,25,99999,1,1,50000,1,1,8500000.00,'2026-06-07 12:03:26','2026-06-07 12:03:26');
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `rating` tinyint(3) unsigned NOT NULL,
  `comment` text DEFAULT NULL,
  `reviewable_type` varchar(255) NOT NULL,
  `reviewable_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_user_id_foreign` (`user_id`),
  KEY `reviews_reviewable_type_reviewable_id_index` (`reviewable_type`,`reviewable_id`),
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'patient','web','2026-06-07 12:03:26','2026-06-07 12:03:26'),(2,'doctor','web','2026-06-07 12:03:26','2026-06-07 12:03:26'),(3,'admin','web','2026-06-07 12:03:26','2026-06-07 12:03:26'),(4,'receptionist','web','2026-06-07 12:03:26','2026-06-07 12:03:26'),(5,'clinic','web','2026-06-07 12:03:26','2026-06-07 12:03:26');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned DEFAULT NULL,
  `address_id` bigint(20) unsigned NOT NULL,
  `day` tinyint(3) unsigned NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schedules_doctor_id_foreign` (`doctor_id`),
  KEY `schedules_address_doctor_day_index` (`address_id`,`doctor_id`,`day`),
  CONSTRAINT `schedules_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedules_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `service_specialty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_specialty` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `service_id` bigint(20) unsigned NOT NULL,
  `specialty_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_specialty_tenant_unique` (`service_id`,`specialty_id`,`user_id`),
  KEY `service_specialty_specialty_id_foreign` (`specialty_id`),
  KEY `service_specialty_user_id_foreign` (`user_id`),
  CONSTRAINT `service_specialty_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_specialty_specialty_id_foreign` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_specialty_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `service_specialty` WRITE;
/*!40000 ALTER TABLE `service_specialty` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_specialty` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` enum('physical','virtual') NOT NULL DEFAULT 'physical',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `specialties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `specialties` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `specialties_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `specialties` WRITE;
/*!40000 ALTER TABLE `specialties` DISABLE KEYS */;
INSERT INTO `specialties` VALUES (1,'Medicina General','medicina-general',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(2,'Psicólogia','psicologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(3,'Cardiología','cardiologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(4,'Pediatría','pediatria',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(5,'Dermatología','dermatologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(6,'Ginecología','ginecologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(7,'Otorrinolaringología','otorrinolaringologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(8,'Oftalmología','oftalmologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(9,'Psiquiatría','psiquiatria',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(10,'Traumatología','traumatologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(11,'Urología','urologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(12,'Ortopedista y Traumatólogia','ortopedista-y-traumatologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(13,'Odontólogia','odontologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(14,'Cirujano Plástico','cirujano-plastico',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(15,'Internista','internista',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(16,'Endocrinólogia','endocrinologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(17,'Neurólogia','neurologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(18,'Gastroenterólogia','gastroenterologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(19,'Cirujano General','cirujano-general',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(20,'Neurocirujano','neurocirujano',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(21,'Nutricionista','nutricionista',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(22,'Fisioterapeuta','fisioterapeuta',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(23,'Terapeuta Complementario','terapeuta-complementario',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(24,'Alergólogia','alergologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(25,'Reumatólogia','reumatologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(26,'Neumólogia','neumologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(27,'Cirujano Maxilofacial','cirujano-maxilofacial',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(28,'Cirujano Vascular','cirujano-vascular',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(29,'Médico Alternativo','medico-alternativo',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(30,'Fonoaudiílogia','fonoaudiilogia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(31,'Médico Fisiatra Rehabilitador','medico-fisiatra-rehabilitador',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(32,'Nefrólogia','nefrologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(33,'Médico Estetico','medico-estetico',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(34,'Sexologia','sexologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(35,'Hematólogia','hematologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(36,'Infectólogia','infectologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(37,'Neuropsicólogia','neuropsicologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(38,'oncólogo','oncologo',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(39,'Endocrinólogia Pediátrica','endocrinologia-pediatrica',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(40,'Neurólogia Pediátrica','neurologia-pediatrica',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(41,'Nutriólogia','nutriologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(42,'Neumólogia Pediátrica','neumologia-pediatrica',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(43,'Médico Laboral','medico-laboral',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(44,'Radiologia','radiologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(45,'Especialista en Medicina Deportiva','especialista-en-medicina-deportiva',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(46,'Cirujano Pediátrico','cirujano-pediatrico',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(47,'Geriatra','geriatra',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(48,'Cirujano de Cabeza y Cuello','cirujano-de-cabeza-y-cuello',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(49,'Anestesiólogia','anestesiologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(50,'Cirujano Cardiovascular','cirujano-cardiovascular',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(51,'Mastológia','mastologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(52,'Especialista en Medicina Familiar','especialista-en-medicina-familiar',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(53,'Podólogo','podologo',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(54,'Genetista','genetista',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(55,'Protólogo','protologo',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(56,'Terapeuta Ocupacional','terapeuta-ocupacional',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(57,'Especialista en Tratamiento del Dolor','especialista-en-tratamiento-del-dolor',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(58,'Audiólogia','audiologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(59,'Cirujano de Tórax','cirujano-de-torax',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(60,'Nefrólogia Pediátrica','nefrologia-pediatrica',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(61,'Coloproctólogia','coloproctologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(62,'Tecnico en Laboratorio','tecnico-en-laboratorio',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(63,'Hepatólogia','hepatologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(64,'Gastroenterólogo Pediátrico','gastroenterologo-pediatrico',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(65,'Toxicólogia','toxicologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(66,'Terapeuta Respiratorio','terapeuta-respiratorio',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(67,'Especialista en Cuidados Críticos','especialista-en-cuidados-criticos',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(68,'Ortopedista Infantil','ortopedista-infantil',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(69,'Cardiólogia Pediátrica','cardiologia-pediatrica',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(70,'Cirujano de Mama y Tejidos Blandos','cirujano-de-mama-y-tejidos-blandos',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(71,'Oftalmólogo Pediátrico','oftalmologo-pediatrico',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(72,'Epidemiólogia','epidemiologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(73,'Psiquiatra Infantil','psiquiatra-infantil',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(74,'Neurofisiólogia','neurofisiologia',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(75,'Infectólogo Pediatra','infectologo-pediatra',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(76,'Oncólogo Radioterápico','oncologo-radioterapico',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(77,'Alergólogo Pediátrico','alergologo-pediatrico',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(78,'Especialista en Medicina Nuclear','especialista-en-medicina-nuclear',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(79,'Especialista en Medicina Domiciliaria','especialista-en-medicina-domiciliaria',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(80,'Psicoanalista','psicoanalista',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(81,'Médico Vascular','medico-vascular',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(82,'Enfermero','enfermero',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(83,'Especialista en Medicina de Urgencias','especialista-en-medicina-de-urgencias',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(84,'Neuro Oftalmólogo','neuro-oftalmologo',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(85,'Perinatólogo','perinatologo',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(86,'Urólogo Pediátrico','urologo-pediatrico',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(87,'Auxiliar de Enfermería','auxiliar-de-enfermeria',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(88,'Ortodoncista','ortodoncista',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(89,'Reumatólogo Pediátrico','reumatologo-pediatrico',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(90,'Dermatólogo Pediátrico','dermatologo-pediatrico',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(91,'Especialista en Salud Pública','especialista-en-salud-publica',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(92,'Radioterapeuta','radioterapeuta',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(93,'Psicopedagogo','psicopedagogo',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(94,'Especialista en Medicina Aeroespacial','especialista-en-medicina-aeroespacial',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(95,'Odontopediatria','odontopediatria',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(96,'Homeópata','homeopata',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(97,'Oncólogo Pediátrico','oncologo-pediatrico',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(98,'Cirujano Oncólogo','cirujano-oncologo',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26'),(99,'Bacteriólogo','bacteriologo',NULL,1,'2026-06-07 12:03:26','2026-06-07 12:03:26');
/*!40000 ALTER TABLE `specialties` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `unavailabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `unavailabilities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `address_id` bigint(20) unsigned DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unavailabilities_doctor_id_foreign` (`doctor_id`),
  KEY `unavailabilities_address_id_foreign` (`address_id`),
  CONSTRAINT `unavailabilities_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `unavailabilities_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `unavailabilities` WRITE;
/*!40000 ALTER TABLE `unavailabilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `unavailabilities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `current_team_id` bigint(20) unsigned DEFAULT NULL,
  `profile_photo_path` varchar(2048) DEFAULT NULL,
  `role` enum('admin','doctor','patient','clinic') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Andres Ocampo','administrador@ejemplo.com','2026-06-07 12:03:27','$2y$12$rYu9iqo3T1GkcKJsMvoVKOif85XN79G.kbvLmWaAHKf1NzCbZRfO2',NULL,NULL,NULL,'Yl6Ffk3DjS',NULL,NULL,'admin','2026-06-07 12:03:27','2026-06-07 12:03:27');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `zoom_creation_failures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `zoom_creation_failures` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `appointment_id` bigint(20) unsigned NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `last_error` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `zoom_creation_failures_appointment_id_foreign` (`appointment_id`),
  CONSTRAINT `zoom_creation_failures_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `zoom_creation_failures` WRITE;
/*!40000 ALTER TABLE `zoom_creation_failures` DISABLE KEYS */;
/*!40000 ALTER TABLE `zoom_creation_failures` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

