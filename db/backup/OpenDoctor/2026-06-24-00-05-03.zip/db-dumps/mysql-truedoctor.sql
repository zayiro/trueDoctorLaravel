/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `address_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `address_service` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `address_id` bigint(20) unsigned NOT NULL,
  `service_id` bigint(20) unsigned NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `duration` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address_service_unique` (`address_id`,`service_id`),
  KEY `address_service_service_id_foreign` (`service_id`),
  CONSTRAINT `address_service_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `address_service_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `address_service` WRITE;
/*!40000 ALTER TABLE `address_service` DISABLE KEYS */;
INSERT INTO `address_service` VALUES (2,10,2,48300.00,20,'2026-06-08 12:03:38','2026-06-08 12:03:38'),(3,10,3,78400.00,20,'2026-06-08 12:17:20','2026-06-08 12:17:20'),(4,1,1,70200.00,20,'2026-06-12 08:19:12','2026-06-14 10:50:39'),(5,11,4,156000.00,20,'2026-06-12 08:21:53','2026-06-12 09:32:47'),(7,9,2,84600.00,20,'2026-06-12 19:32:42','2026-06-12 19:32:42'),(8,11,5,200000.00,20,'2026-06-13 17:33:44','2026-06-13 17:33:44'),(10,2,1,96700.00,20,'2026-06-17 11:28:03','2026-06-17 11:28:03');
/*!40000 ALTER TABLE `address_service` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned DEFAULT NULL,
  `clinic_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'physical',
  `phone` varchar(255) DEFAULT NULL,
  `city_id` varchar(5) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `addresses_doctor_name_unique` (`doctor_id`,`name`),
  UNIQUE KEY `addresses_clinic_name_unique` (`clinic_id`,`name`),
  UNIQUE KEY `addresses_doctor_address_unique` (`doctor_id`,`address`),
  UNIQUE KEY `addresses_clinic_address_unique` (`clinic_id`,`address`),
  KEY `addresses_city_id_foreign` (`city_id`),
  CONSTRAINT `addresses_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (1,NULL,1,'Atención Virtual / Telemedicina (Institucional)','Plataforma Online','virtual','+573026433874','05001',1,NULL,'2026-06-07 12:51:06','2026-06-17 11:28:03'),(2,1,NULL,'Atención Virtual / Telemedicina','Plataforma Online','virtual','+573026433874','05001',1,NULL,'2026-06-07 12:59:05','2026-06-17 11:28:03'),(8,7,NULL,'Atención Virtual / Telemedicina','Plataforma Online','virtual','+573208272753','05001',1,NULL,'2026-06-07 14:32:52','2026-06-14 08:59:38'),(9,1,NULL,'Consultorio 112 - Edificio Central Park','cra 7E # 70-134','physical','3208272753','76001',1,NULL,'2026-06-08 06:59:34','2026-06-12 19:32:42'),(10,7,NULL,'Consultorio 304 - Edificio Siglo XIX','Avenida 5 Norte # 78-30','physical','3026433874','11001',1,NULL,'2026-06-08 10:58:44','2026-06-12 19:32:42'),(11,NULL,1,'Edificio Institucional Versalles','Avenida 5Norte # 65-128','physical','3208272753','76001',1,NULL,'2026-06-12 06:45:20','2026-06-12 09:32:47');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `affected_appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `affected_appointments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `unavailability_id` bigint(20) unsigned NOT NULL,
  `appointment_id` bigint(20) unsigned NOT NULL,
  `patient_id` bigint(20) unsigned NOT NULL,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `rescheduled_to_appointment_id` bigint(20) unsigned DEFAULT NULL,
  `original_date` date NOT NULL,
  `original_start_time` time NOT NULL,
  `original_end_time` time NOT NULL,
  `status` enum('pending_reschedule','rescheduled','cancelled','confirmed') NOT NULL DEFAULT 'pending_reschedule',
  `notification_sent_at` timestamp NULL DEFAULT NULL,
  `rescheduled_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `affected_appointments_rescheduled_to_appointment_id_foreign` (`rescheduled_to_appointment_id`),
  KEY `affected_appointments_unavailability_id_index` (`unavailability_id`),
  KEY `affected_appointments_appointment_id_index` (`appointment_id`),
  KEY `affected_appointments_patient_id_index` (`patient_id`),
  KEY `affected_appointments_doctor_id_index` (`doctor_id`),
  KEY `affected_appointments_status_index` (`status`),
  KEY `affected_appointments_created_at_index` (`created_at`),
  CONSTRAINT `affected_appointments_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `affected_appointments_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `affected_appointments_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `affected_appointments_rescheduled_to_appointment_id_foreign` FOREIGN KEY (`rescheduled_to_appointment_id`) REFERENCES `appointments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `affected_appointments_unavailability_id_foreign` FOREIGN KEY (`unavailability_id`) REFERENCES `unavailabilities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `affected_appointments` WRITE;
/*!40000 ALTER TABLE `affected_appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `affected_appointments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `api_client_endpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_client_endpoints` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `api_client_id` bigint(20) unsigned NOT NULL,
  `endpoint` varchar(255) NOT NULL,
  `is_allowed` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_client_endpoints_api_client_id_endpoint_unique` (`api_client_id`,`endpoint`),
  KEY `api_client_endpoints_api_client_id_index` (`api_client_id`),
  CONSTRAINT `api_client_endpoints_api_client_id_foreign` FOREIGN KEY (`api_client_id`) REFERENCES `api_clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `api_client_endpoints` WRITE;
/*!40000 ALTER TABLE `api_client_endpoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_client_endpoints` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `api_client_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_client_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `api_client_id` bigint(20) unsigned NOT NULL,
  `endpoint` varchar(255) NOT NULL,
  `method` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `status_code` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `api_client_logs_api_client_id_index` (`api_client_id`),
  KEY `api_client_logs_created_at_index` (`created_at`),
  KEY `api_client_logs_api_client_id_created_at_index` (`api_client_id`,`created_at`),
  CONSTRAINT `api_client_logs_api_client_id_foreign` FOREIGN KEY (`api_client_id`) REFERENCES `api_clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `api_client_logs` WRITE;
/*!40000 ALTER TABLE `api_client_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_client_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `api_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `api_key` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_clients_name_unique` (`name`),
  UNIQUE KEY `api_clients_api_key_unique` (`api_key`),
  KEY `api_clients_api_key_index` (`api_key`),
  KEY `api_clients_is_active_index` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `api_clients` WRITE;
/*!40000 ALTER TABLE `api_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `appointment_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointment_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `appointment_id` bigint(20) unsigned NOT NULL,
  `event_type` varchar(255) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`payload`)),
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_type` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `appointment_events_appointment_id_index` (`appointment_id`),
  KEY `appointment_events_event_type_index` (`event_type`),
  KEY `appointment_events_user_id_index` (`user_id`),
  KEY `appointment_events_created_at_index` (`created_at`),
  KEY `appointment_events_appointment_id_event_type_index` (`appointment_id`,`event_type`),
  CONSTRAINT `appointment_events_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `appointment_events_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `appointment_events` WRITE;
/*!40000 ALTER TABLE `appointment_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointment_events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `appointment_state_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointment_state_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `appointment_id` bigint(20) unsigned NOT NULL,
  `from_status` varchar(255) NOT NULL,
  `to_status` varchar(255) NOT NULL,
  `reason` text DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `appointment_state_transitions_user_id_foreign` (`user_id`),
  KEY `appointment_state_transitions_appointment_id_index` (`appointment_id`),
  KEY `appointment_state_transitions_from_status_index` (`from_status`),
  KEY `appointment_state_transitions_to_status_index` (`to_status`),
  KEY `appointment_state_transitions_created_at_index` (`created_at`),
  CONSTRAINT `appointment_state_transitions_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `appointment_state_transitions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `appointment_state_transitions` WRITE;
/*!40000 ALTER TABLE `appointment_state_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointment_state_transitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(20) NOT NULL,
  `patient_id` bigint(20) unsigned NOT NULL,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `clinic_id` bigint(20) unsigned DEFAULT NULL,
  `service_id` bigint(20) unsigned NOT NULL,
  `address_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `duration` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `meeting_link` text DEFAULT NULL COMMENT 'Enlace genérico o exclusivo para el Paciente',
  `zoom_meeting_id` varchar(255) DEFAULT NULL COMMENT 'ID numérico de la reunión en Zoom',
  `meeting_link_password` text DEFAULT NULL COMMENT 'Contraseña cifrada de la sala de Zoom para el Meeting SDK',
  `zoom_start_url` text DEFAULT NULL COMMENT 'Enlace exclusivo para que el Doctor inicie como Anfitrión',
  `status` enum('pending','confirmed','cancelled','completed') NOT NULL DEFAULT 'pending',
  `payment_status` enum('pending','paid','cancelled','failed') NOT NULL DEFAULT 'pending',
  `channel` enum('app','web','whatsapp') NOT NULL DEFAULT 'web',
  `notes` text DEFAULT NULL,
  `email_sent` tinyint(1) NOT NULL DEFAULT 0,
  `reschedule_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `appointments_reference_unique` (`reference`),
  KEY `appointments_doctor_date_time_index` (`doctor_id`,`date`,`start_time`),
  KEY `idx_appointments_doctor_date_status` (`doctor_id`,`date`,`status`),
  KEY `idx_appointments_clinic_date_status` (`clinic_id`,`date`,`status`),
  KEY `idx_appointments_patient_date_status` (`patient_id`,`date`,`status`),
  KEY `idx_appointments_address_doctor_date` (`address_id`,`doctor_id`,`date`),
  KEY `idx_appointments_service_date_status` (`service_id`,`date`,`status`),
  CONSTRAINT `appointments_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`),
  CONSTRAINT `appointments_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE SET NULL,
  CONSTRAINT `appointments_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`),
  CONSTRAINT `appointments_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `appointments_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('opendoctor-cache-1f61ca70e317b7bbd0e4ba76520a0bb6','i:1;',1782264571),('opendoctor-cache-1f61ca70e317b7bbd0e4ba76520a0bb6:timer','i:1782264571;',1782264571),('opendoctor-cache-20577099a72a3c3a85e6842dedba3c7b','i:1;',1782274245),('opendoctor-cache-20577099a72a3c3a85e6842dedba3c7b:timer','i:1782274245;',1782274245),('opendoctor-cache-597ff8a935da9b7db038997ae70b0382','i:1;',1782262924),('opendoctor-cache-597ff8a935da9b7db038997ae70b0382:timer','i:1782262924;',1782262924),('opendoctor-cache-712ae05deca2a81c23309b13e9c41d7c','i:1;',1782275934),('opendoctor-cache-712ae05deca2a81c23309b13e9c41d7c:timer','i:1782275934;',1782275934),('opendoctor-cache-7c6ddc3bf1bb196fa199945fdd6b3a0d','i:1;',1782265262),('opendoctor-cache-7c6ddc3bf1bb196fa199945fdd6b3a0d:timer','i:1782265262;',1782265262),('opendoctor-cache-availability:appointments:1:2:2026-06-24','a:0:{}',1782277674),('opendoctor-cache-availability:appointments:1:9:2026-06-23','a:0:{}',1782277674),('opendoctor-cache-availability:appointments:1:9:2026-06-24','a:0:{}',1782277674),('opendoctor-cache-availability:appointments:7:1:2026-06-27','a:0:{}',1782277674),('opendoctor-cache-availability:appointments:7:10:2026-06-23','a:0:{}',1782277674),('opendoctor-cache-availability:appointments:7:10:2026-06-24','a:0:{}',1782277674),('opendoctor-cache-availability:appointments:7:11:2026-06-27','a:0:{}',1782277674),('opendoctor-cache-availability:appointments:7:8:2026-06-23','a:0:{}',1782277674),('opendoctor-cache-availability:appointments:7:8:2026-06-24','a:0:{}',1782277674),('opendoctor-cache-availability:min_notice:1','i:2;',1782277674),('opendoctor-cache-availability:min_notice:doctors:1','i:2;',1782277674),('opendoctor-cache-availability:min_notice:doctors:7','i:2;',1782277674),('opendoctor-cache-availability:schedules:1:7:2','a:0:{}',1782277674),('opendoctor-cache-availability:schedules:1:7:3','a:0:{}',1782277674),('opendoctor-cache-availability:schedules:1:7:4','a:0:{}',1782277674),('opendoctor-cache-availability:schedules:1:7:5','a:0:{}',1782277674),('opendoctor-cache-availability:schedules:1:7:6','a:1:{i:0;a:12:{s:2:\"id\";i:23;s:9:\"doctor_id\";i:7;s:10:\"address_id\";i:1;s:9:\"clinic_id\";N;s:3:\"day\";i:6;s:10:\"start_time\";s:5:\"08:00\";s:8:\"end_time\";s:5:\"13:00\";s:9:\"is_active\";b:1;s:10:\"created_at\";s:27:\"2026-06-13T01:14:39.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-13T01:14:39.000000Z\";s:6:\"doctor\";a:18:{s:2:\"id\";i:7;s:4:\"slug\";s:30:\"pedro-pablo-perez-pinzon-NLDRU\";s:7:\"user_id\";i:9;s:15:\"medical_license\";s:10:\"1694788597\";s:14:\"identification\";s:10:\"1112461968\";s:6:\"gender\";s:4:\"male\";s:3:\"bio\";N;s:5:\"phone\";s:13:\"+573208272753\";s:16:\"experience_years\";N;s:9:\"languages\";a:1:{i:0;s:2:\"es\";}s:6:\"rating\";s:4:\"0.00\";s:13:\"reviews_count\";i:0;s:17:\"validation_status\";s:8:\"approved\";s:18:\"identity_card_path\";s:62:\"verification_docs/ad0RQLK2TxOxlmgTTNPrfgBb90v2QgOBCjkx3M2k.jpg\";s:22:\"professional_card_path\";s:62:\"verification_docs/Jmer4qzsUoxk3AbLt6PbyYFEfRUzWpW3g8LLSEYc.jpg\";s:6:\"active\";b:1;s:10:\"created_at\";s:27:\"2026-06-07T19:32:52.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-07T21:42:30.000000Z\";}s:7:\"address\";a:12:{s:2:\"id\";i:1;s:9:\"doctor_id\";N;s:9:\"clinic_id\";i:1;s:4:\"name\";s:48:\"Atención Virtual / Telemedicina (Institucional)\";s:7:\"address\";s:17:\"Plataforma Online\";s:4:\"type\";s:7:\"virtual\";s:5:\"phone\";s:13:\"+573026433874\";s:7:\"city_id\";s:5:\"05001\";s:6:\"status\";b:1;s:10:\"deleted_at\";N;s:10:\"created_at\";s:27:\"2026-06-07T17:51:06.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-17T16:28:03.000000Z\";}}}',1782277674),('opendoctor-cache-availability:schedules:10:7:2','a:1:{i:0;a:12:{s:2:\"id\";i:18;s:9:\"doctor_id\";i:7;s:10:\"address_id\";i:10;s:9:\"clinic_id\";N;s:3:\"day\";i:2;s:10:\"start_time\";s:5:\"06:00\";s:8:\"end_time\";s:5:\"18:00\";s:9:\"is_active\";b:1;s:10:\"created_at\";s:27:\"2026-06-08T16:10:09.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-08T16:10:09.000000Z\";s:6:\"doctor\";a:18:{s:2:\"id\";i:7;s:4:\"slug\";s:30:\"pedro-pablo-perez-pinzon-NLDRU\";s:7:\"user_id\";i:9;s:15:\"medical_license\";s:10:\"1694788597\";s:14:\"identification\";s:10:\"1112461968\";s:6:\"gender\";s:4:\"male\";s:3:\"bio\";N;s:5:\"phone\";s:13:\"+573208272753\";s:16:\"experience_years\";N;s:9:\"languages\";a:1:{i:0;s:2:\"es\";}s:6:\"rating\";s:4:\"0.00\";s:13:\"reviews_count\";i:0;s:17:\"validation_status\";s:8:\"approved\";s:18:\"identity_card_path\";s:62:\"verification_docs/ad0RQLK2TxOxlmgTTNPrfgBb90v2QgOBCjkx3M2k.jpg\";s:22:\"professional_card_path\";s:62:\"verification_docs/Jmer4qzsUoxk3AbLt6PbyYFEfRUzWpW3g8LLSEYc.jpg\";s:6:\"active\";b:1;s:10:\"created_at\";s:27:\"2026-06-07T19:32:52.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-07T21:42:30.000000Z\";}s:7:\"address\";a:12:{s:2:\"id\";i:10;s:9:\"doctor_id\";i:7;s:9:\"clinic_id\";N;s:4:\"name\";s:36:\"Consultorio 304 - Edificio Siglo XIX\";s:7:\"address\";s:23:\"Avenida 5 Norte # 78-30\";s:4:\"type\";s:8:\"physical\";s:5:\"phone\";s:10:\"3026433874\";s:7:\"city_id\";s:5:\"11001\";s:6:\"status\";b:1;s:10:\"deleted_at\";N;s:10:\"created_at\";s:27:\"2026-06-08T15:58:44.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-13T00:32:42.000000Z\";}}}',1782277674),('opendoctor-cache-availability:schedules:10:7:3','a:1:{i:0;a:12:{s:2:\"id\";i:19;s:9:\"doctor_id\";i:7;s:10:\"address_id\";i:10;s:9:\"clinic_id\";N;s:3:\"day\";i:3;s:10:\"start_time\";s:5:\"06:00\";s:8:\"end_time\";s:5:\"18:00\";s:9:\"is_active\";b:1;s:10:\"created_at\";s:27:\"2026-06-08T16:10:09.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-08T16:10:09.000000Z\";s:6:\"doctor\";a:18:{s:2:\"id\";i:7;s:4:\"slug\";s:30:\"pedro-pablo-perez-pinzon-NLDRU\";s:7:\"user_id\";i:9;s:15:\"medical_license\";s:10:\"1694788597\";s:14:\"identification\";s:10:\"1112461968\";s:6:\"gender\";s:4:\"male\";s:3:\"bio\";N;s:5:\"phone\";s:13:\"+573208272753\";s:16:\"experience_years\";N;s:9:\"languages\";a:1:{i:0;s:2:\"es\";}s:6:\"rating\";s:4:\"0.00\";s:13:\"reviews_count\";i:0;s:17:\"validation_status\";s:8:\"approved\";s:18:\"identity_card_path\";s:62:\"verification_docs/ad0RQLK2TxOxlmgTTNPrfgBb90v2QgOBCjkx3M2k.jpg\";s:22:\"professional_card_path\";s:62:\"verification_docs/Jmer4qzsUoxk3AbLt6PbyYFEfRUzWpW3g8LLSEYc.jpg\";s:6:\"active\";b:1;s:10:\"created_at\";s:27:\"2026-06-07T19:32:52.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-07T21:42:30.000000Z\";}s:7:\"address\";a:12:{s:2:\"id\";i:10;s:9:\"doctor_id\";i:7;s:9:\"clinic_id\";N;s:4:\"name\";s:36:\"Consultorio 304 - Edificio Siglo XIX\";s:7:\"address\";s:23:\"Avenida 5 Norte # 78-30\";s:4:\"type\";s:8:\"physical\";s:5:\"phone\";s:10:\"3026433874\";s:7:\"city_id\";s:5:\"11001\";s:6:\"status\";b:1;s:10:\"deleted_at\";N;s:10:\"created_at\";s:27:\"2026-06-08T15:58:44.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-13T00:32:42.000000Z\";}}}',1782277674),('opendoctor-cache-availability:schedules:11:7:2','a:0:{}',1782277674),('opendoctor-cache-availability:schedules:11:7:3','a:0:{}',1782277674),('opendoctor-cache-availability:schedules:11:7:4','a:0:{}',1782277674),('opendoctor-cache-availability:schedules:11:7:5','a:0:{}',1782277674),('opendoctor-cache-availability:schedules:11:7:6','a:1:{i:0;a:12:{s:2:\"id\";i:24;s:9:\"doctor_id\";i:7;s:10:\"address_id\";i:11;s:9:\"clinic_id\";N;s:3:\"day\";i:6;s:10:\"start_time\";s:5:\"09:22\";s:8:\"end_time\";s:5:\"13:00\";s:9:\"is_active\";b:1;s:10:\"created_at\";s:27:\"2026-06-13T01:23:03.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-13T01:23:03.000000Z\";s:6:\"doctor\";a:18:{s:2:\"id\";i:7;s:4:\"slug\";s:30:\"pedro-pablo-perez-pinzon-NLDRU\";s:7:\"user_id\";i:9;s:15:\"medical_license\";s:10:\"1694788597\";s:14:\"identification\";s:10:\"1112461968\";s:6:\"gender\";s:4:\"male\";s:3:\"bio\";N;s:5:\"phone\";s:13:\"+573208272753\";s:16:\"experience_years\";N;s:9:\"languages\";a:1:{i:0;s:2:\"es\";}s:6:\"rating\";s:4:\"0.00\";s:13:\"reviews_count\";i:0;s:17:\"validation_status\";s:8:\"approved\";s:18:\"identity_card_path\";s:62:\"verification_docs/ad0RQLK2TxOxlmgTTNPrfgBb90v2QgOBCjkx3M2k.jpg\";s:22:\"professional_card_path\";s:62:\"verification_docs/Jmer4qzsUoxk3AbLt6PbyYFEfRUzWpW3g8LLSEYc.jpg\";s:6:\"active\";b:1;s:10:\"created_at\";s:27:\"2026-06-07T19:32:52.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-07T21:42:30.000000Z\";}s:7:\"address\";a:12:{s:2:\"id\";i:11;s:9:\"doctor_id\";N;s:9:\"clinic_id\";i:1;s:4:\"name\";s:32:\"Edificio Institucional Versalles\";s:7:\"address\";s:23:\"Avenida 5Norte # 65-128\";s:4:\"type\";s:8:\"physical\";s:5:\"phone\";s:10:\"3208272753\";s:7:\"city_id\";s:5:\"76001\";s:6:\"status\";b:1;s:10:\"deleted_at\";N;s:10:\"created_at\";s:27:\"2026-06-12T11:45:20.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-12T14:32:47.000000Z\";}}}',1782277674),('opendoctor-cache-availability:schedules:2:1:2','a:0:{}',1782277674),('opendoctor-cache-availability:schedules:2:1:3','a:1:{i:0;a:12:{s:2:\"id\";i:2;s:9:\"doctor_id\";i:1;s:10:\"address_id\";i:2;s:9:\"clinic_id\";N;s:3:\"day\";i:3;s:10:\"start_time\";s:5:\"06:00\";s:8:\"end_time\";s:5:\"18:00\";s:9:\"is_active\";b:1;s:10:\"created_at\";s:27:\"2026-06-08T15:32:37.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-08T15:32:37.000000Z\";s:6:\"doctor\";a:18:{s:2:\"id\";i:1;s:4:\"slug\";s:36:\"juan-sebastian-chaparro-vargas-RS0ON\";s:7:\"user_id\";i:3;s:15:\"medical_license\";s:10:\"7896582678\";s:14:\"identification\";s:9:\"169447522\";s:6:\"gender\";s:4:\"male\";s:3:\"bio\";N;s:5:\"phone\";s:13:\"+573026433874\";s:16:\"experience_years\";s:1:\"3\";s:9:\"languages\";a:2:{i:0;s:2:\"es\";i:1;s:2:\"en\";}s:6:\"rating\";s:4:\"0.00\";s:13:\"reviews_count\";i:0;s:17:\"validation_status\";s:8:\"approved\";s:18:\"identity_card_path\";s:62:\"verification_docs/UZLlpGH3ozHFUCHO34DYjcd3Rm5SZLCgsc5M0cm8.jpg\";s:22:\"professional_card_path\";s:62:\"verification_docs/kCYtIxFZ4nMNzCuomszegR4CJxv3FTEEb55s0lV0.jpg\";s:6:\"active\";b:1;s:10:\"created_at\";s:27:\"2026-06-07T17:59:05.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-13T23:50:01.000000Z\";}s:7:\"address\";a:12:{s:2:\"id\";i:2;s:9:\"doctor_id\";i:1;s:9:\"clinic_id\";N;s:4:\"name\";s:32:\"Atención Virtual / Telemedicina\";s:7:\"address\";s:17:\"Plataforma Online\";s:4:\"type\";s:7:\"virtual\";s:5:\"phone\";s:13:\"+573026433874\";s:7:\"city_id\";s:5:\"05001\";s:6:\"status\";b:1;s:10:\"deleted_at\";N;s:10:\"created_at\";s:27:\"2026-06-07T17:59:05.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-17T16:28:03.000000Z\";}}}',1782277674),('opendoctor-cache-availability:schedules:8:7:2','a:1:{i:0;a:12:{s:2:\"id\";i:12;s:9:\"doctor_id\";i:7;s:10:\"address_id\";i:8;s:9:\"clinic_id\";N;s:3:\"day\";i:2;s:10:\"start_time\";s:5:\"06:00\";s:8:\"end_time\";s:5:\"18:00\";s:9:\"is_active\";b:1;s:10:\"created_at\";s:27:\"2026-06-08T16:09:08.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-08T16:09:08.000000Z\";s:6:\"doctor\";a:18:{s:2:\"id\";i:7;s:4:\"slug\";s:30:\"pedro-pablo-perez-pinzon-NLDRU\";s:7:\"user_id\";i:9;s:15:\"medical_license\";s:10:\"1694788597\";s:14:\"identification\";s:10:\"1112461968\";s:6:\"gender\";s:4:\"male\";s:3:\"bio\";N;s:5:\"phone\";s:13:\"+573208272753\";s:16:\"experience_years\";N;s:9:\"languages\";a:1:{i:0;s:2:\"es\";}s:6:\"rating\";s:4:\"0.00\";s:13:\"reviews_count\";i:0;s:17:\"validation_status\";s:8:\"approved\";s:18:\"identity_card_path\";s:62:\"verification_docs/ad0RQLK2TxOxlmgTTNPrfgBb90v2QgOBCjkx3M2k.jpg\";s:22:\"professional_card_path\";s:62:\"verification_docs/Jmer4qzsUoxk3AbLt6PbyYFEfRUzWpW3g8LLSEYc.jpg\";s:6:\"active\";b:1;s:10:\"created_at\";s:27:\"2026-06-07T19:32:52.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-07T21:42:30.000000Z\";}s:7:\"address\";a:12:{s:2:\"id\";i:8;s:9:\"doctor_id\";i:7;s:9:\"clinic_id\";N;s:4:\"name\";s:32:\"Atención Virtual / Telemedicina\";s:7:\"address\";s:17:\"Plataforma Online\";s:4:\"type\";s:7:\"virtual\";s:5:\"phone\";s:13:\"+573208272753\";s:7:\"city_id\";s:5:\"05001\";s:6:\"status\";b:1;s:10:\"deleted_at\";N;s:10:\"created_at\";s:27:\"2026-06-07T19:32:52.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-14T13:59:38.000000Z\";}}}',1782277674),('opendoctor-cache-availability:schedules:8:7:3','a:1:{i:0;a:12:{s:2:\"id\";i:13;s:9:\"doctor_id\";i:7;s:10:\"address_id\";i:8;s:9:\"clinic_id\";N;s:3:\"day\";i:3;s:10:\"start_time\";s:5:\"06:00\";s:8:\"end_time\";s:5:\"18:00\";s:9:\"is_active\";b:1;s:10:\"created_at\";s:27:\"2026-06-08T16:09:08.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-08T16:09:08.000000Z\";s:6:\"doctor\";a:18:{s:2:\"id\";i:7;s:4:\"slug\";s:30:\"pedro-pablo-perez-pinzon-NLDRU\";s:7:\"user_id\";i:9;s:15:\"medical_license\";s:10:\"1694788597\";s:14:\"identification\";s:10:\"1112461968\";s:6:\"gender\";s:4:\"male\";s:3:\"bio\";N;s:5:\"phone\";s:13:\"+573208272753\";s:16:\"experience_years\";N;s:9:\"languages\";a:1:{i:0;s:2:\"es\";}s:6:\"rating\";s:4:\"0.00\";s:13:\"reviews_count\";i:0;s:17:\"validation_status\";s:8:\"approved\";s:18:\"identity_card_path\";s:62:\"verification_docs/ad0RQLK2TxOxlmgTTNPrfgBb90v2QgOBCjkx3M2k.jpg\";s:22:\"professional_card_path\";s:62:\"verification_docs/Jmer4qzsUoxk3AbLt6PbyYFEfRUzWpW3g8LLSEYc.jpg\";s:6:\"active\";b:1;s:10:\"created_at\";s:27:\"2026-06-07T19:32:52.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-07T21:42:30.000000Z\";}s:7:\"address\";a:12:{s:2:\"id\";i:8;s:9:\"doctor_id\";i:7;s:9:\"clinic_id\";N;s:4:\"name\";s:32:\"Atención Virtual / Telemedicina\";s:7:\"address\";s:17:\"Plataforma Online\";s:4:\"type\";s:7:\"virtual\";s:5:\"phone\";s:13:\"+573208272753\";s:7:\"city_id\";s:5:\"05001\";s:6:\"status\";b:1;s:10:\"deleted_at\";N;s:10:\"created_at\";s:27:\"2026-06-07T19:32:52.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-14T13:59:38.000000Z\";}}}',1782277674),('opendoctor-cache-availability:schedules:9:1:2','a:1:{i:0;a:12:{s:2:\"id\";i:6;s:9:\"doctor_id\";i:1;s:10:\"address_id\";i:9;s:9:\"clinic_id\";N;s:3:\"day\";i:2;s:10:\"start_time\";s:5:\"06:00\";s:8:\"end_time\";s:5:\"18:00\";s:9:\"is_active\";b:1;s:10:\"created_at\";s:27:\"2026-06-08T15:34:57.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-08T15:34:57.000000Z\";s:6:\"doctor\";a:18:{s:2:\"id\";i:1;s:4:\"slug\";s:36:\"juan-sebastian-chaparro-vargas-RS0ON\";s:7:\"user_id\";i:3;s:15:\"medical_license\";s:10:\"7896582678\";s:14:\"identification\";s:9:\"169447522\";s:6:\"gender\";s:4:\"male\";s:3:\"bio\";N;s:5:\"phone\";s:13:\"+573026433874\";s:16:\"experience_years\";s:1:\"3\";s:9:\"languages\";a:2:{i:0;s:2:\"es\";i:1;s:2:\"en\";}s:6:\"rating\";s:4:\"0.00\";s:13:\"reviews_count\";i:0;s:17:\"validation_status\";s:8:\"approved\";s:18:\"identity_card_path\";s:62:\"verification_docs/UZLlpGH3ozHFUCHO34DYjcd3Rm5SZLCgsc5M0cm8.jpg\";s:22:\"professional_card_path\";s:62:\"verification_docs/kCYtIxFZ4nMNzCuomszegR4CJxv3FTEEb55s0lV0.jpg\";s:6:\"active\";b:1;s:10:\"created_at\";s:27:\"2026-06-07T17:59:05.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-13T23:50:01.000000Z\";}s:7:\"address\";a:12:{s:2:\"id\";i:9;s:9:\"doctor_id\";i:1;s:9:\"clinic_id\";N;s:4:\"name\";s:39:\"Consultorio 112 - Edificio Central Park\";s:7:\"address\";s:15:\"cra 7E # 70-134\";s:4:\"type\";s:8:\"physical\";s:5:\"phone\";s:10:\"3208272753\";s:7:\"city_id\";s:5:\"76001\";s:6:\"status\";b:1;s:10:\"deleted_at\";N;s:10:\"created_at\";s:27:\"2026-06-08T11:59:34.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-13T00:32:42.000000Z\";}}}',1782277674),('opendoctor-cache-availability:schedules:9:1:3','a:1:{i:0;a:12:{s:2:\"id\";i:7;s:9:\"doctor_id\";i:1;s:10:\"address_id\";i:9;s:9:\"clinic_id\";N;s:3:\"day\";i:3;s:10:\"start_time\";s:5:\"06:00\";s:8:\"end_time\";s:5:\"18:00\";s:9:\"is_active\";b:1;s:10:\"created_at\";s:27:\"2026-06-08T15:34:57.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-08T15:34:57.000000Z\";s:6:\"doctor\";a:18:{s:2:\"id\";i:1;s:4:\"slug\";s:36:\"juan-sebastian-chaparro-vargas-RS0ON\";s:7:\"user_id\";i:3;s:15:\"medical_license\";s:10:\"7896582678\";s:14:\"identification\";s:9:\"169447522\";s:6:\"gender\";s:4:\"male\";s:3:\"bio\";N;s:5:\"phone\";s:13:\"+573026433874\";s:16:\"experience_years\";s:1:\"3\";s:9:\"languages\";a:2:{i:0;s:2:\"es\";i:1;s:2:\"en\";}s:6:\"rating\";s:4:\"0.00\";s:13:\"reviews_count\";i:0;s:17:\"validation_status\";s:8:\"approved\";s:18:\"identity_card_path\";s:62:\"verification_docs/UZLlpGH3ozHFUCHO34DYjcd3Rm5SZLCgsc5M0cm8.jpg\";s:22:\"professional_card_path\";s:62:\"verification_docs/kCYtIxFZ4nMNzCuomszegR4CJxv3FTEEb55s0lV0.jpg\";s:6:\"active\";b:1;s:10:\"created_at\";s:27:\"2026-06-07T17:59:05.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-13T23:50:01.000000Z\";}s:7:\"address\";a:12:{s:2:\"id\";i:9;s:9:\"doctor_id\";i:1;s:9:\"clinic_id\";N;s:4:\"name\";s:39:\"Consultorio 112 - Edificio Central Park\";s:7:\"address\";s:15:\"cra 7E # 70-134\";s:4:\"type\";s:8:\"physical\";s:5:\"phone\";s:10:\"3208272753\";s:7:\"city_id\";s:5:\"76001\";s:6:\"status\";b:1;s:10:\"deleted_at\";N;s:10:\"created_at\";s:27:\"2026-06-08T11:59:34.000000Z\";s:10:\"updated_at\";s:27:\"2026-06-13T00:32:42.000000Z\";}}}',1782277674),('opendoctor-cache-availability:slot_duration:1','i:20;',1782277674),('opendoctor-cache-availability:slot_duration:10','i:20;',1782277674),('opendoctor-cache-availability:slot_duration:11','i:20;',1782277674),('opendoctor-cache-availability:slot_duration:2','i:20;',1782277674),('opendoctor-cache-availability:slot_duration:8','i:20;',1782277674),('opendoctor-cache-availability:slot_duration:9','i:20;',1782277674),('opendoctor-cache-availability:unavailabilities:1:2026-06-23:9','a:0:{}',1782277674),('opendoctor-cache-availability:unavailabilities:1:2026-06-24:2','a:0:{}',1782277674),('opendoctor-cache-availability:unavailabilities:1:2026-06-24:9','a:0:{}',1782277674),('opendoctor-cache-availability:unavailabilities:7:2026-06-23:10','a:0:{}',1782277674),('opendoctor-cache-availability:unavailabilities:7:2026-06-23:8','a:0:{}',1782277674),('opendoctor-cache-availability:unavailabilities:7:2026-06-24:10','a:0:{}',1782277674),('opendoctor-cache-availability:unavailabilities:7:2026-06-24:8','a:0:{}',1782277674),('opendoctor-cache-availability:unavailabilities:7:2026-06-27:1','a:0:{}',1782277674),('opendoctor-cache-availability:unavailabilities:7:2026-06-27:11','a:0:{}',1782277674);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
INSERT INTO `cache_locks` VALUES ('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422550000','QVrDrCZpOZbgIQPx',1782280806),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552140','s0YhCnR2PvmU9H4n',1782272403),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552150','kEajS1qlnRWWv9Be',1782273003),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552200','ODa3VZzoy6dCgseO',1782273604),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552210','UFjTYnukysR3gs2z',1782274203),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552220','5f9ibctvQl3qafm9',1782274802),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552230','H2c9PMe3bSgMhJPB',1782275403),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552240','GAEX7zFGPN7Zd6fH',1782276002),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552250','JYVb5Ul8T0Re3jFq',1782276603),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552300','CaD3vxn0KC6Pa3pU',1782277205),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552310','rxgRDS66CjGo3EHJ',1782277803),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552320','BVdAAXM79pYHsay9',1782278403),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552330','F8eGhOQAJkwpu5EH',1782279003),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552340','Rn2B09sM2Jx6FQRl',1782279603),('opendoctor-cache-framework/schedule-0d3ccf4227c71130201e182cc36a1362618422552350','fhmknHECAtNlH9Es',1782280203);
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaigns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `content` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaigns_doctor_id_slug_unique` (`doctor_id`,`slug`),
  CONSTRAINT `campaigns_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `campaigns` WRITE;
/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cities` (
  `id` varchar(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department_id` varchar(5) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cities_slug_unique` (`slug`),
  KEY `cities_department_id_foreign` (`department_id`),
  CONSTRAINT `cities_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES ('05001','Medellín','05','medellin',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('08001','Barranquilla','08','barranquilla',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('11001','Bogotá','11','bogota',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('13001','Cartagena','13','cartagena',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('15001','Tunja','15','tunja',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('17001','Manizales','17','manizales',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('19001','Popayán','19','popayan',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('20001','Valledupar','20','valledupar',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('23001','Montería','23','monteria',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('41001','Neiva','41','neiva',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('44001','Riohacha','44','riohacha',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('47001','Santa Marta','47','santa-marta',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('50001','Villavicencio','50','villavicencio',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('52001','Pasto','52','pasto',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('54001','Cúcuta','54','cucuta',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('63001','Armenia','63','armenia',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('66001','Pereira','66','pereira',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('68001','Bucaramanga','68','bucaramanga',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('70001','Sincelejo','70','sincelejo',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('73001','Ibagué','73','ibague',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('76001','Cali','76','cali',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('76520','Palmira','76','palmira',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),('88001','San Andrés','88','san-andres',1,'2026-06-07 12:46:47','2026-06-07 12:46:47');
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clinic_doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinic_doctor` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(20) unsigned NOT NULL,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending' COMMENT 'pending, approved, rejected, inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clinic_doctor_clinic_id_doctor_id_unique` (`clinic_id`,`doctor_id`),
  KEY `clinic_doctor_doctor_id_foreign` (`doctor_id`),
  CONSTRAINT `clinic_doctor_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clinic_doctor_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clinic_doctor` WRITE;
/*!40000 ALTER TABLE `clinic_doctor` DISABLE KEYS */;
INSERT INTO `clinic_doctor` VALUES (3,1,7,'approved','2026-06-07 20:16:49','2026-06-08 10:57:40');
/*!40000 ALTER TABLE `clinic_doctor` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clinic_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinic_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(20) unsigned NOT NULL,
  `plan_id` bigint(20) unsigned DEFAULT NULL,
  `accepts_online_payments` tinyint(1) NOT NULL DEFAULT 0,
  `currency` varchar(255) NOT NULL DEFAULT 'COP',
  `min_notice_hours` int(11) NOT NULL DEFAULT 2,
  `max_advance_days` int(11) NOT NULL DEFAULT 30,
  `requires_approval` tinyint(1) NOT NULL DEFAULT 0,
  `buffer_time_minutes` int(10) unsigned NOT NULL DEFAULT 0,
  `max_appointments_per_day` int(10) unsigned DEFAULT NULL,
  `allow_patient_cancellation` tinyint(1) NOT NULL DEFAULT 1,
  `cancellation_notice_hours` int(10) unsigned NOT NULL DEFAULT 2,
  `allow_patient_rescheduling` tinyint(1) NOT NULL DEFAULT 1,
  `virtual_meeting_platform` varchar(255) NOT NULL DEFAULT 'internal',
  `google_calendar_sync` tinyint(1) NOT NULL DEFAULT 0,
  `email_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `whatsapp_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clinic_settings_clinic_id_foreign` (`clinic_id`),
  KEY `clinic_settings_plan_id_foreign` (`plan_id`),
  CONSTRAINT `clinic_settings_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clinic_settings_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clinic_settings` WRITE;
/*!40000 ALTER TABLE `clinic_settings` DISABLE KEYS */;
INSERT INTO `clinic_settings` VALUES (1,1,4,0,'COP',2,30,0,0,NULL,1,2,1,'internal',0,1,0,'2026-06-07 12:51:06','2026-06-07 12:51:06');
/*!40000 ALTER TABLE `clinic_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clinic_specialty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinic_specialty` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(20) unsigned NOT NULL,
  `specialty_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clinic_specialty_specialty_id_foreign` (`specialty_id`),
  KEY `clinic_specialty_clinic_id_specialty_id_index` (`clinic_id`,`specialty_id`),
  CONSTRAINT `clinic_specialty_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clinic_specialty_specialty_id_foreign` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clinic_specialty` WRITE;
/*!40000 ALTER TABLE `clinic_specialty` DISABLE KEYS */;
INSERT INTO `clinic_specialty` VALUES (1,1,24,'2026-06-07 12:51:06','2026-06-07 12:51:06'),(2,1,49,'2026-06-07 12:51:06','2026-06-07 12:51:06'),(3,1,3,'2026-06-07 12:51:06','2026-06-07 12:51:06'),(4,1,99,'2026-06-07 12:51:06','2026-06-07 12:51:06'),(5,1,87,'2026-06-07 12:51:06','2026-06-07 12:51:06'),(6,1,11,'2026-06-13 18:50:22','2026-06-13 18:50:22');
/*!40000 ALTER TABLE `clinic_specialty` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clinics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `nit` varchar(255) NOT NULL,
  `reps_code` varchar(12) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `experience_years` varchar(255) DEFAULT NULL,
  `rating` decimal(3,2) NOT NULL DEFAULT 0.00,
  `reviews_count` int(11) NOT NULL DEFAULT 0,
  `validation_status` varchar(255) NOT NULL DEFAULT 'missing' COMMENT 'Estados: missing, pending_validation, approved, rejected',
  `identity_card_path` varchar(255) DEFAULT NULL,
  `reps_code_card_path` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `languages` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT json_array('es') CHECK (json_valid(`languages`)),
  PRIMARY KEY (`id`),
  UNIQUE KEY `clinics_slug_unique` (`slug`),
  UNIQUE KEY `clinics_nit_unique` (`nit`),
  UNIQUE KEY `clinics_reps_code_unique` (`reps_code`),
  KEY `clinics_user_id_foreign` (`user_id`),
  CONSTRAINT `clinics_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clinics` WRITE;
/*!40000 ALTER TABLE `clinics` DISABLE KEYS */;
INSERT INTO `clinics` VALUES (1,'clinica-versalles-FC98',2,'169447523','123456789856','+573026433874',NULL,'5',0.00,0,'approved','verification_docs/xSdCOMCK7LKTQqu5pFbtz6cniBKlMJCjj1GwNHp4.jpg','verification_docs/20bOPnvQKTvAdEjUFJyq1lfT0xDnal517NFiCSaC.jpg',1,'2026-06-07 12:51:06','2026-06-14 17:26:59','[\"es\",\"en\"]');
/*!40000 ALTER TABLE `clinics` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contact_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contact_messages` WRITE;
/*!40000 ALTER TABLE `contact_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` varchar(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES ('05','Antioquia',NULL,NULL),('08','Atlántico',NULL,NULL),('11','Bogotá D.C.',NULL,NULL),('13','Bolívar',NULL,NULL),('15','Boyacá',NULL,NULL),('17','Caldas',NULL,NULL),('18','Caquetá',NULL,NULL),('19','Cauca',NULL,NULL),('20','Cesar',NULL,NULL),('23','Córdoba',NULL,NULL),('25','Cundinamarca',NULL,NULL),('27','Chocó',NULL,NULL),('41','Huila',NULL,NULL),('44','La Guajira',NULL,NULL),('47','Magdalena',NULL,NULL),('50','Meta',NULL,NULL),('52','Nariño',NULL,NULL),('54','Norte de Santander',NULL,NULL),('63','Quindío',NULL,NULL),('66','Risaralda',NULL,NULL),('68','Santander',NULL,NULL),('70','Sucre',NULL,NULL),('73','Tolima',NULL,NULL),('76','Valle del Cauca',NULL,NULL),('81','Arauca',NULL,NULL),('85','Casanare',NULL,NULL),('86','Putumayo',NULL,NULL),('88','Archipiélago de San Andrés',NULL,NULL),('91','Amazonas',NULL,NULL),('94','Guainía',NULL,NULL),('95','Guaviare',NULL,NULL),('97','Vaupés',NULL,NULL),('99','Vichada',NULL,NULL);
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `doctor_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `plan_id` bigint(20) unsigned DEFAULT NULL,
  `accepts_online_payments` tinyint(1) NOT NULL DEFAULT 0,
  `currency` varchar(255) NOT NULL DEFAULT 'COP',
  `min_notice_hours` int(11) NOT NULL DEFAULT 2,
  `max_advance_days` int(11) NOT NULL DEFAULT 30,
  `requires_approval` tinyint(1) NOT NULL DEFAULT 0,
  `buffer_time_minutes` int(10) unsigned NOT NULL DEFAULT 0,
  `max_appointments_per_day` int(10) unsigned DEFAULT NULL,
  `allow_patient_cancellation` tinyint(1) NOT NULL DEFAULT 1,
  `cancellation_notice_hours` int(10) unsigned NOT NULL DEFAULT 2,
  `allow_patient_rescheduling` tinyint(1) NOT NULL DEFAULT 1,
  `virtual_meeting_platform` varchar(255) NOT NULL DEFAULT 'internal',
  `google_calendar_sync` tinyint(1) NOT NULL DEFAULT 0,
  `email_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `whatsapp_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `doctor_settings_doctor_id_foreign` (`doctor_id`),
  KEY `doctor_settings_plan_id_foreign` (`plan_id`),
  CONSTRAINT `doctor_settings_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `doctor_settings_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `doctor_settings` WRITE;
/*!40000 ALTER TABLE `doctor_settings` DISABLE KEYS */;
INSERT INTO `doctor_settings` VALUES (1,1,2,0,'COP',2,30,0,0,NULL,1,2,1,'internal',0,1,0,'2026-06-07 12:59:05','2026-06-07 12:59:05'),(7,7,2,0,'COP',2,30,0,0,NULL,1,2,1,'internal',0,1,0,'2026-06-07 14:32:52','2026-06-07 15:01:07');
/*!40000 ALTER TABLE `doctor_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `doctor_specialty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor_specialty` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `specialty_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `doctor_specialty_specialty_id_foreign` (`specialty_id`),
  KEY `doctor_specialty_doctor_id_specialty_id_index` (`doctor_id`,`specialty_id`),
  CONSTRAINT `doctor_specialty_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `doctor_specialty_specialty_id_foreign` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `doctor_specialty` WRITE;
/*!40000 ALTER TABLE `doctor_specialty` DISABLE KEYS */;
INSERT INTO `doctor_specialty` VALUES (1,1,24,'2026-06-07 12:59:05','2026-06-07 12:59:05'),(2,1,58,'2026-06-07 12:59:05','2026-06-07 12:59:05'),(3,1,49,'2026-06-07 12:59:05','2026-06-07 12:59:05'),(4,1,69,'2026-06-07 12:59:05','2026-06-07 12:59:05'),(5,7,24,'2026-06-07 14:32:52','2026-06-07 14:32:52'),(6,7,49,'2026-06-07 14:32:52','2026-06-07 14:32:52'),(7,7,99,'2026-06-07 14:32:52','2026-06-07 14:32:52'),(8,7,3,'2026-06-07 14:32:52','2026-06-07 14:32:52');
/*!40000 ALTER TABLE `doctor_specialty` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `medical_license` varchar(255) DEFAULT NULL,
  `identification` varchar(255) NOT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `experience_years` varchar(255) DEFAULT NULL,
  `languages` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '["es"]' CHECK (json_valid(`languages`)),
  `rating` decimal(3,2) NOT NULL DEFAULT 0.00,
  `reviews_count` int(11) NOT NULL DEFAULT 0,
  `validation_status` varchar(255) NOT NULL DEFAULT 'missing' COMMENT 'Estados: missing, pending_validation, approved, rejected',
  `identity_card_path` varchar(255) DEFAULT NULL,
  `professional_card_path` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `doctors_slug_unique` (`slug`),
  UNIQUE KEY `doctors_identification_unique` (`identification`),
  KEY `doctors_user_id_foreign` (`user_id`),
  CONSTRAINT `doctors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` VALUES (1,'juan-sebastian-chaparro-vargas-RS0ON',3,'7896582678','169447522','male',NULL,'+573026433874','3','[\"es\",\"en\"]',0.00,0,'approved','verification_docs/UZLlpGH3ozHFUCHO34DYjcd3Rm5SZLCgsc5M0cm8.jpg','verification_docs/kCYtIxFZ4nMNzCuomszegR4CJxv3FTEEb55s0lV0.jpg',1,'2026-06-07 12:59:05','2026-06-13 18:50:01'),(7,'pedro-pablo-perez-pinzon-NLDRU',9,'1694788597','1112461968','male',NULL,'+573208272753',NULL,'[\"es\"]',0.00,0,'approved','verification_docs/ad0RQLK2TxOxlmgTTNPrfgBb90v2QgOBCjkx3M2k.jpg','verification_docs/Jmer4qzsUoxk3AbLt6PbyYFEfRUzWpW3g8LLSEYc.jpg',1,'2026-06-07 14:32:52','2026-06-07 16:42:30');
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `exam_analyses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_analyses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `customer_email` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `reason_type` varchar(255) NOT NULL,
  `reason_custom` text DEFAULT NULL,
  `payment_id` varchar(255) DEFAULT NULL,
  `payment_status` enum('pending','paid','failed') NOT NULL DEFAULT 'pending',
  `price` decimal(8,2) NOT NULL DEFAULT 4.99,
  `ai_result` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ai_result`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exam_analyses_user_id_foreign` (`user_id`),
  CONSTRAINT `exam_analyses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `exam_analyses` WRITE;
/*!40000 ALTER TABLE `exam_analyses` DISABLE KEYS */;
INSERT INTO `exam_analyses` VALUES (1,NULL,'smartripreservas@gmail.com','medical-exams/Qwcz9mKxlgxyxT6DvySw03baV9gm6Zxvb2VX5dRN.pdf','rutina','tengo azucar en sangre','PAY-Q3PBDWRDDA','paid',18500.00,'{\"nombre_examen\":\"An\\u00e1lisis de qu\\u00edmica cl\\u00ednica\",\"especialidad_slug\":\"medicina-general\",\"hallazgos_clave\":[{\"parametro\":\"Microalbuminuria en orina parcial\",\"valor_detectado\":\"262.00 mg\\/dL\",\"estado\":\"Elevado\"},{\"parametro\":\"Albuminuria en orina parcial\",\"valor_detectado\":\"50.80 mg\\/L\",\"estado\":\"Elevado\"},{\"parametro\":\"Relaci\\u00f3n albuminuria\\/creatina microalbumin\",\"valor_detectado\":\"19.39 mgAlb\\/gCre\",\"estado\":\"Elevado\"},{\"parametro\":\"Colesterol de alta densidad HDL\",\"valor_detectado\":\"35.5 mg\\/dL\",\"estado\":\"Bajo\"},{\"parametro\":\"Colesterol total\",\"valor_detectado\":\"318.0 mg\\/dL\",\"estado\":\"Elevado\"},{\"parametro\":\"Colesterol de baja densidad LDL\",\"valor_detectado\":\"165 mg\\/dL\",\"estado\":\"Elevado\"}],\"conclusion_paciente\":\"El paciente presenta microalbuminuria elevada en orina parcial, lo que puede indicar da\\u00f1o renal, probablemente relacionado con diabetes. Adem\\u00e1s, hay un perfil lip\\u00eddico alterado con colesterol total y LDL elevados y HDL bajo, lo que sugiere un riesgo cardiovascular aumentado.\",\"recomendaciones\":\"Se recomienda que el paciente consulte con un m\\u00e9dico para evaluar el da\\u00f1o renal potencial y recibir tratamiento para mejorar el control de l\\u00edpidos y az\\u00facar en sangre. Tambi\\u00e9n es aconsejable realizar un seguimiento regular de la funci\\u00f3n renal y el perfil lip\\u00eddico, junto con un estilo de vida saludable que incluya dieta balanceada y ejercicio.\"}','2026-06-09 05:58:46','2026-06-09 08:52:36'),(2,NULL,'ocampotecnologo@gmail.com','medical-exams/aHuaT1fAq10AI8KYuvEBOGhaS1VlrksPpbyWEkAa.pdf','rutina',NULL,NULL,'paid',18500.00,NULL,'2026-06-09 18:38:26','2026-06-13 13:04:04');
/*!40000 ALTER TABLE `exam_analyses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
INSERT INTO `failed_jobs` VALUES (1,'b3072b88-4e08-40f1-8a06-8804f8490779','database','default','{\"uuid\":\"b3072b88-4e08-40f1-8a06-8804f8490779\",\"displayName\":\"App\\\\Mail\\\\ExamPaymentPendingAlert\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:32:\\\"App\\\\Mail\\\\ExamPaymentPendingAlert\\\":4:{s:11:\\\"recoveryUrl\\\";s:135:\\\"https:\\/\\/opendoctor.online\\/examenes\\/1\\/pago?expires=1781089126&signature=af8f0b6526fe42cbf0300ba5b68be52556d9a82403ec32e3c873427ec947b270\\\";s:8:\\\"analysis\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:23:\\\"App\\\\Models\\\\ExamAnalysis\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:26:\\\"smartripreservas@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1781002726,\"delay\":null}','InvalidArgumentException: View [emails.exam-payment-pending-alert] not found. in /var/www/html/vendor/laravel/framework/src/Illuminate/View/FileViewFinder.php:138\nStack trace:\n#0 /var/www/html/vendor/laravel/framework/src/Illuminate/View/FileViewFinder.php(78): Illuminate\\View\\FileViewFinder->findInPaths()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Factory.php(150): Illuminate\\View\\FileViewFinder->find()\n#2 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(444): Illuminate\\View\\Factory->make()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(419): Illuminate\\Mail\\Mailer->renderView()\n#4 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(312): Illuminate\\Mail\\Mailer->addContent()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(209): Illuminate\\Mail\\Mailer->send()\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->{closure:Illuminate\\Mail\\Mailable::send():202}()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(202): Illuminate\\Mail\\Mailable->withLocale()\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(89): Illuminate\\Mail\\Mailable->send()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#35 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#37 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#38 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#39 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#40 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#41 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#42 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#43 {main}','2026-06-20 22:10:53'),(2,'f7f18fd1-4a33-43c3-a8be-1a0cbcf81ece','database','default','{\"uuid\":\"f7f18fd1-4a33-43c3-a8be-1a0cbcf81ece\",\"displayName\":\"App\\\\Mail\\\\ExamAnalysisReady\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:26:\\\"App\\\\Mail\\\\ExamAnalysisReady\\\":3:{s:8:\\\"analysis\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:23:\\\"App\\\\Models\\\\ExamAnalysis\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:26:\\\"smartripreservas@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1781006747,\"delay\":null}','Illuminate\\Routing\\Exceptions\\UrlGenerationException: Missing required parameter for [Route: medical-analysis.show] [URI: medical-analysis/result/{medicalAnalysis}] [Missing parameter: medicalAnalysis]. in /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Exceptions/UrlGenerationException.php:35\nStack trace:\n#0 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/RouteUrlGenerator.php(94): Illuminate\\Routing\\Exceptions\\UrlGenerationException::forMissingParameters()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/UrlGenerator.php(561): Illuminate\\Routing\\RouteUrlGenerator->to()\n#2 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/UrlGenerator.php(538): Illuminate\\Routing\\UrlGenerator->toRoute()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/helpers.php(870): Illuminate\\Routing\\UrlGenerator->route()\n#4 /var/www/html/storage/framework/views/f8796fde1e9a5ea07071a26446de3d22.php(47): route()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/Filesystem/Filesystem.php(123): require(\'...\')\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Filesystem/Filesystem.php(124): Illuminate\\Filesystem\\Filesystem::{closure:Illuminate\\Filesystem\\Filesystem::getRequire():120}()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Engines/PhpEngine.php(57): Illuminate\\Filesystem\\Filesystem->getRequire()\n#8 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(22): Illuminate\\View\\Engines\\PhpEngine->evaluatePath()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Engines/CompilerEngine.php(76): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->evaluatePath()\n#10 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(10): Illuminate\\View\\Engines\\CompilerEngine->get()\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(208): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->get()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(191): Illuminate\\View\\View->getContents()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(160): Illuminate\\View\\View->renderContents()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(444): Illuminate\\View\\View->render()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(419): Illuminate\\Mail\\Mailer->renderView()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(312): Illuminate\\Mail\\Mailer->addContent()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(209): Illuminate\\Mail\\Mailer->send()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->{closure:Illuminate\\Mail\\Mailable::send():202}()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(202): Illuminate\\Mail\\Mailable->withLocale()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(89): Illuminate\\Mail\\Mailable->send()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#35 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#37 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#38 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#39 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#40 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#41 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#42 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#43 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#44 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#45 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#46 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#47 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#48 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#49 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#50 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#51 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#52 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#53 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#54 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#55 {main}\n\nNext Illuminate\\View\\ViewException: Missing required parameter for [Route: medical-analysis.show] [URI: medical-analysis/result/{medicalAnalysis}] [Missing parameter: medicalAnalysis]. (View: /var/www/html/resources/views/emails/exam-analysis-ready.blade.php) in /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Exceptions/UrlGenerationException.php:35\nStack trace:\n#0 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(58): Illuminate\\View\\Engines\\CompilerEngine->handleViewException()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Engines/PhpEngine.php(59): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->handleViewException()\n#2 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(22): Illuminate\\View\\Engines\\PhpEngine->evaluatePath()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Engines/CompilerEngine.php(76): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->evaluatePath()\n#4 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(10): Illuminate\\View\\Engines\\CompilerEngine->get()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(208): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->get()\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(191): Illuminate\\View\\View->getContents()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(160): Illuminate\\View\\View->renderContents()\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(444): Illuminate\\View\\View->render()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(419): Illuminate\\Mail\\Mailer->renderView()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(312): Illuminate\\Mail\\Mailer->addContent()\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(209): Illuminate\\Mail\\Mailer->send()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->{closure:Illuminate\\Mail\\Mailable::send():202}()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(202): Illuminate\\Mail\\Mailable->withLocale()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(89): Illuminate\\Mail\\Mailable->send()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#35 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#37 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#38 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#39 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#40 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#41 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#42 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#43 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#44 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#45 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#46 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#47 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#48 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#49 {main}','2026-06-20 22:10:53'),(3,'31a2d4e6-ab6a-431f-8350-e2f5eb3f3f6f','database','default','{\"uuid\":\"31a2d4e6-ab6a-431f-8350-e2f5eb3f3f6f\",\"displayName\":\"App\\\\Mail\\\\ExamAnalysisReady\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:26:\\\"App\\\\Mail\\\\ExamAnalysisReady\\\":3:{s:8:\\\"analysis\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:23:\\\"App\\\\Models\\\\ExamAnalysis\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:26:\\\"smartripreservas@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1781006860,\"delay\":null}','Illuminate\\Routing\\Exceptions\\UrlGenerationException: Missing required parameter for [Route: medical-analysis.show] [URI: medical-analysis/result/{medicalAnalysis}] [Missing parameter: medicalAnalysis]. in /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Exceptions/UrlGenerationException.php:35\nStack trace:\n#0 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/RouteUrlGenerator.php(94): Illuminate\\Routing\\Exceptions\\UrlGenerationException::forMissingParameters()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/UrlGenerator.php(561): Illuminate\\Routing\\RouteUrlGenerator->to()\n#2 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/UrlGenerator.php(538): Illuminate\\Routing\\UrlGenerator->toRoute()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/helpers.php(870): Illuminate\\Routing\\UrlGenerator->route()\n#4 /var/www/html/storage/framework/views/f8796fde1e9a5ea07071a26446de3d22.php(47): route()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/Filesystem/Filesystem.php(123): require(\'...\')\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Filesystem/Filesystem.php(124): Illuminate\\Filesystem\\Filesystem::{closure:Illuminate\\Filesystem\\Filesystem::getRequire():120}()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Engines/PhpEngine.php(57): Illuminate\\Filesystem\\Filesystem->getRequire()\n#8 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(22): Illuminate\\View\\Engines\\PhpEngine->evaluatePath()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Engines/CompilerEngine.php(76): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->evaluatePath()\n#10 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(10): Illuminate\\View\\Engines\\CompilerEngine->get()\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(208): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->get()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(191): Illuminate\\View\\View->getContents()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(160): Illuminate\\View\\View->renderContents()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(444): Illuminate\\View\\View->render()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(419): Illuminate\\Mail\\Mailer->renderView()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(312): Illuminate\\Mail\\Mailer->addContent()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(209): Illuminate\\Mail\\Mailer->send()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->{closure:Illuminate\\Mail\\Mailable::send():202}()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(202): Illuminate\\Mail\\Mailable->withLocale()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(89): Illuminate\\Mail\\Mailable->send()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#35 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#37 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#38 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#39 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#40 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#41 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#42 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#43 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#44 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#45 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#46 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#47 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#48 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#49 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#50 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#51 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#52 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#53 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#54 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#55 {main}\n\nNext Illuminate\\View\\ViewException: Missing required parameter for [Route: medical-analysis.show] [URI: medical-analysis/result/{medicalAnalysis}] [Missing parameter: medicalAnalysis]. (View: /var/www/html/resources/views/emails/exam-analysis-ready.blade.php) in /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Exceptions/UrlGenerationException.php:35\nStack trace:\n#0 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(58): Illuminate\\View\\Engines\\CompilerEngine->handleViewException()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Engines/PhpEngine.php(59): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->handleViewException()\n#2 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(22): Illuminate\\View\\Engines\\PhpEngine->evaluatePath()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Engines/CompilerEngine.php(76): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->evaluatePath()\n#4 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(10): Illuminate\\View\\Engines\\CompilerEngine->get()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(208): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->get()\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(191): Illuminate\\View\\View->getContents()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(160): Illuminate\\View\\View->renderContents()\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(444): Illuminate\\View\\View->render()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(419): Illuminate\\Mail\\Mailer->renderView()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(312): Illuminate\\Mail\\Mailer->addContent()\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(209): Illuminate\\Mail\\Mailer->send()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->{closure:Illuminate\\Mail\\Mailable::send():202}()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(202): Illuminate\\Mail\\Mailable->withLocale()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(89): Illuminate\\Mail\\Mailable->send()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#35 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#37 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#38 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#39 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#40 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#41 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#42 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#43 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#44 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#45 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#46 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#47 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#48 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#49 {main}','2026-06-20 22:10:53'),(4,'c0f96931-a2eb-48da-a577-9427515a6e79','database','default','{\"uuid\":\"c0f96931-a2eb-48da-a577-9427515a6e79\",\"displayName\":\"App\\\\Mail\\\\ExamAnalysisReady\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:26:\\\"App\\\\Mail\\\\ExamAnalysisReady\\\":3:{s:8:\\\"analysis\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:23:\\\"App\\\\Models\\\\ExamAnalysis\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:26:\\\"smartripreservas@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1781007768,\"delay\":null}','Illuminate\\Routing\\Exceptions\\UrlGenerationException: Missing required parameter for [Route: medical-analysis.show] [URI: medical-analysis/result/{medicalAnalysis}] [Missing parameter: medicalAnalysis]. in /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Exceptions/UrlGenerationException.php:35\nStack trace:\n#0 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/RouteUrlGenerator.php(94): Illuminate\\Routing\\Exceptions\\UrlGenerationException::forMissingParameters()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/UrlGenerator.php(561): Illuminate\\Routing\\RouteUrlGenerator->to()\n#2 /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/UrlGenerator.php(538): Illuminate\\Routing\\UrlGenerator->toRoute()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/helpers.php(870): Illuminate\\Routing\\UrlGenerator->route()\n#4 /var/www/html/storage/framework/views/f8796fde1e9a5ea07071a26446de3d22.php(47): route()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/Filesystem/Filesystem.php(123): require(\'...\')\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Filesystem/Filesystem.php(124): Illuminate\\Filesystem\\Filesystem::{closure:Illuminate\\Filesystem\\Filesystem::getRequire():120}()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Engines/PhpEngine.php(57): Illuminate\\Filesystem\\Filesystem->getRequire()\n#8 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(22): Illuminate\\View\\Engines\\PhpEngine->evaluatePath()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Engines/CompilerEngine.php(76): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->evaluatePath()\n#10 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(10): Illuminate\\View\\Engines\\CompilerEngine->get()\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(208): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->get()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(191): Illuminate\\View\\View->getContents()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(160): Illuminate\\View\\View->renderContents()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(444): Illuminate\\View\\View->render()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(419): Illuminate\\Mail\\Mailer->renderView()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(312): Illuminate\\Mail\\Mailer->addContent()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(209): Illuminate\\Mail\\Mailer->send()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->{closure:Illuminate\\Mail\\Mailable::send():202}()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(202): Illuminate\\Mail\\Mailable->withLocale()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(89): Illuminate\\Mail\\Mailable->send()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#35 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#37 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#38 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#39 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#40 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#41 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#42 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#43 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#44 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#45 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#46 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#47 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#48 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#49 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#50 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#51 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#52 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#53 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#54 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#55 {main}\n\nNext Illuminate\\View\\ViewException: Missing required parameter for [Route: medical-analysis.show] [URI: medical-analysis/result/{medicalAnalysis}] [Missing parameter: medicalAnalysis]. (View: /var/www/html/resources/views/emails/exam-analysis-ready.blade.php) in /var/www/html/vendor/laravel/framework/src/Illuminate/Routing/Exceptions/UrlGenerationException.php:35\nStack trace:\n#0 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(58): Illuminate\\View\\Engines\\CompilerEngine->handleViewException()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Engines/PhpEngine.php(59): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->handleViewException()\n#2 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(22): Illuminate\\View\\Engines\\PhpEngine->evaluatePath()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Engines/CompilerEngine.php(76): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->evaluatePath()\n#4 /var/www/html/vendor/livewire/livewire/src/Mechanisms/ExtendBlade/ExtendedCompilerEngine.php(10): Illuminate\\View\\Engines\\CompilerEngine->get()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(208): Livewire\\Mechanisms\\ExtendBlade\\ExtendedCompilerEngine->get()\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(191): Illuminate\\View\\View->getContents()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/View/View.php(160): Illuminate\\View\\View->renderContents()\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(444): Illuminate\\View\\View->render()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(419): Illuminate\\Mail\\Mailer->renderView()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(312): Illuminate\\Mail\\Mailer->addContent()\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(209): Illuminate\\Mail\\Mailer->send()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->{closure:Illuminate\\Mail\\Mailable::send():202}()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(202): Illuminate\\Mail\\Mailable->withLocale()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(89): Illuminate\\Mail\\Mailable->send()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#35 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#37 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#38 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#39 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#40 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#41 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#42 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#43 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#44 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#45 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#46 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#47 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#48 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#49 {main}','2026-06-20 22:10:53'),(5,'f6ba3781-3ea8-4f5e-adc7-a3d5b0702f14','database','default','{\"uuid\":\"f6ba3781-3ea8-4f5e-adc7-a3d5b0702f14\",\"displayName\":\"App\\\\Mail\\\\ExamPaymentPendingAlert\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:32:\\\"App\\\\Mail\\\\ExamPaymentPendingAlert\\\":4:{s:11:\\\"recoveryUrl\\\";s:135:\\\"https:\\/\\/opendoctor.online\\/examenes\\/2\\/pago?expires=1781134706&signature=80429e059b08ac23932330553613c7284fc989b3d4a98c37caf62ca0009697d5\\\";s:8:\\\"analysis\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:23:\\\"App\\\\Models\\\\ExamAnalysis\\\";s:2:\\\"id\\\";i:2;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:25:\\\"ocampotecnologo@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1781048306,\"delay\":null}','InvalidArgumentException: View [emails.exam-payment-pending-alert] not found. in /var/www/html/vendor/laravel/framework/src/Illuminate/View/FileViewFinder.php:138\nStack trace:\n#0 /var/www/html/vendor/laravel/framework/src/Illuminate/View/FileViewFinder.php(78): Illuminate\\View\\FileViewFinder->findInPaths()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Factory.php(150): Illuminate\\View\\FileViewFinder->find()\n#2 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(444): Illuminate\\View\\Factory->make()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(419): Illuminate\\Mail\\Mailer->renderView()\n#4 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(312): Illuminate\\Mail\\Mailer->addContent()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(209): Illuminate\\Mail\\Mailer->send()\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->{closure:Illuminate\\Mail\\Mailable::send():202}()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(202): Illuminate\\Mail\\Mailable->withLocale()\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(89): Illuminate\\Mail\\Mailable->send()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#35 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#37 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#38 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#39 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#40 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#41 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#42 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#43 {main}','2026-06-20 22:10:54'),(6,'6d680d09-0338-4709-8ee8-fef82a872589','database','default','{\"uuid\":\"6d680d09-0338-4709-8ee8-fef82a872589\",\"displayName\":\"App\\\\Listeners\\\\SendAppointmentRescheduledNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":28:{s:5:\\\"class\\\";s:52:\\\"App\\\\Listeners\\\\SendAppointmentRescheduledNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:33:\\\"App\\\\Events\\\\AppointmentRescheduled\\\":2:{s:11:\\\"appointment\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:22:\\\"App\\\\Models\\\\Appointment\\\";s:2:\\\"id\\\";i:16;s:9:\\\"relations\\\";a:1:{i:0;s:7:\\\"service\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:16:\\\"previousDateTime\\\";s:16:\\\"24\\/06\\/2026 08:40\\\";}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:23:\\\"deleteWhenMissingModels\\\";b:0;s:14:\\\"shouldBeUnique\\\";b:0;s:29:\\\"shouldBeUniqueUntilProcessing\\\";b:0;s:8:\\\"uniqueId\\\";N;s:9:\\\"uniqueFor\\\";N;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1781835689,\"delay\":null}','InvalidArgumentException: View [view.name] not found. in /var/www/html/vendor/laravel/framework/src/Illuminate/View/FileViewFinder.php:138\nStack trace:\n#0 /var/www/html/vendor/laravel/framework/src/Illuminate/View/FileViewFinder.php(78): Illuminate\\View\\FileViewFinder->findInPaths()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Factory.php(150): Illuminate\\View\\FileViewFinder->find()\n#2 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(444): Illuminate\\View\\Factory->make()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(419): Illuminate\\Mail\\Mailer->renderView()\n#4 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(312): Illuminate\\Mail\\Mailer->addContent()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(209): Illuminate\\Mail\\Mailer->send()\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->{closure:Illuminate\\Mail\\Mailable::send():202}()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(202): Illuminate\\Mail\\Mailable->withLocale()\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(353): Illuminate\\Mail\\Mailable->send()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(300): Illuminate\\Mail\\Mailer->sendMailable()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/PendingMail.php(123): Illuminate\\Mail\\Mailer->send()\n#11 /var/www/html/app/Listeners/SendAppointmentRescheduledNotification.php(32): Illuminate\\Mail\\PendingMail->send()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Events/CallQueuedListener.php(141): App\\Listeners\\SendAppointmentRescheduledNotification->handle()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Events\\CallQueuedListener->handle()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#35 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#37 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#38 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#39 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#40 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#41 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#42 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#43 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#44 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#45 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#46 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#47 {main}','2026-06-21 00:38:53'),(7,'288c5416-74db-4dfd-9e2e-bc56da2eae65','database','default','{\"uuid\":\"288c5416-74db-4dfd-9e2e-bc56da2eae65\",\"displayName\":\"App\\\\Listeners\\\\SendAppointmentRescheduledNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":28:{s:5:\\\"class\\\";s:52:\\\"App\\\\Listeners\\\\SendAppointmentRescheduledNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:33:\\\"App\\\\Events\\\\AppointmentRescheduled\\\":2:{s:11:\\\"appointment\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:22:\\\"App\\\\Models\\\\Appointment\\\";s:2:\\\"id\\\";i:16;s:9:\\\"relations\\\";a:1:{i:0;s:7:\\\"service\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:16:\\\"previousDateTime\\\";s:16:\\\"23\\/06\\/2026 10:00\\\";}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:23:\\\"deleteWhenMissingModels\\\";b:0;s:14:\\\"shouldBeUnique\\\";b:0;s:29:\\\"shouldBeUniqueUntilProcessing\\\";b:0;s:8:\\\"uniqueId\\\";N;s:9:\\\"uniqueFor\\\";N;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1781835736,\"delay\":null}','InvalidArgumentException: View [view.name] not found. in /var/www/html/vendor/laravel/framework/src/Illuminate/View/FileViewFinder.php:138\nStack trace:\n#0 /var/www/html/vendor/laravel/framework/src/Illuminate/View/FileViewFinder.php(78): Illuminate\\View\\FileViewFinder->findInPaths()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/View/Factory.php(150): Illuminate\\View\\FileViewFinder->find()\n#2 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(444): Illuminate\\View\\Factory->make()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(419): Illuminate\\Mail\\Mailer->renderView()\n#4 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(312): Illuminate\\Mail\\Mailer->addContent()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(209): Illuminate\\Mail\\Mailer->send()\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->{closure:Illuminate\\Mail\\Mailable::send():202}()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(202): Illuminate\\Mail\\Mailable->withLocale()\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(353): Illuminate\\Mail\\Mailable->send()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(300): Illuminate\\Mail\\Mailer->sendMailable()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/PendingMail.php(123): Illuminate\\Mail\\Mailer->send()\n#11 /var/www/html/app/Listeners/SendAppointmentRescheduledNotification.php(32): Illuminate\\Mail\\PendingMail->send()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Events/CallQueuedListener.php(141): App\\Listeners\\SendAppointmentRescheduledNotification->handle()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Events\\CallQueuedListener->handle()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#35 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#37 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#38 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#39 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#40 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#41 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#42 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#43 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#44 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#45 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#46 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#47 {main}','2026-06-21 00:38:53'),(8,'6fa4a251-a7f9-42cc-a0ac-074dfaa45de8','database','default','{\"uuid\":\"6fa4a251-a7f9-42cc-a0ac-074dfaa45de8\",\"displayName\":\"App\\\\Listeners\\\\SendCancellationEmail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":3,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":\"60\",\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":28:{s:5:\\\"class\\\";s:35:\\\"App\\\\Listeners\\\\SendCancellationEmail\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:31:\\\"App\\\\Events\\\\AppointmentCancelled\\\":1:{s:11:\\\"appointment\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:22:\\\"App\\\\Models\\\\Appointment\\\";s:2:\\\"id\\\";i:9;s:9:\\\"relations\\\";a:3:{i:0;s:6:\\\"doctor\\\";i:1;s:15:\\\"doctor.settings\\\";i:2;s:6:\\\"clinic\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";i:3;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";i:60;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:23:\\\"deleteWhenMissingModels\\\";b:0;s:14:\\\"shouldBeUnique\\\";b:0;s:29:\\\"shouldBeUniqueUntilProcessing\\\";b:0;s:8:\\\"uniqueId\\\";N;s:9:\\\"uniqueFor\\\";N;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1781615748,\"delay\":null}','Error: Class \"App\\Listeners\\DB\" not found in /var/www/html/app/Listeners/SendCancellationEmail.php:107\nStack trace:\n#0 /var/www/html/app/Listeners/SendCancellationEmail.php(67): App\\Listeners\\SendCancellationEmail->registerZoomFailure()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/Events/CallQueuedListener.php(141): App\\Listeners\\SendCancellationEmail->handle()\n#2 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Events\\CallQueuedListener->handle()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#4 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#28 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#30 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#31 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#32 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#35 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#36 {main}','2026-06-21 00:40:46'),(9,'fc2a73c8-fb3a-4905-9ece-6ffbda2374ec','database','default','{\"uuid\":\"fc2a73c8-fb3a-4905-9ece-6ffbda2374ec\",\"displayName\":\"App\\\\Listeners\\\\SendCancellationEmail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":3,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":\"60\",\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":28:{s:5:\\\"class\\\";s:35:\\\"App\\\\Listeners\\\\SendCancellationEmail\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:31:\\\"App\\\\Events\\\\AppointmentCancelled\\\":1:{s:11:\\\"appointment\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:22:\\\"App\\\\Models\\\\Appointment\\\";s:2:\\\"id\\\";i:9;s:9:\\\"relations\\\";a:3:{i:0;s:6:\\\"doctor\\\";i:1;s:15:\\\"doctor.settings\\\";i:2;s:6:\\\"clinic\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";i:3;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";i:60;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:23:\\\"deleteWhenMissingModels\\\";b:0;s:14:\\\"shouldBeUnique\\\";b:0;s:29:\\\"shouldBeUniqueUntilProcessing\\\";b:0;s:8:\\\"uniqueId\\\";N;s:9:\\\"uniqueFor\\\";N;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1781615748,\"delay\":null}','Error: Class \"App\\Listeners\\DB\" not found in /var/www/html/app/Listeners/SendCancellationEmail.php:107\nStack trace:\n#0 /var/www/html/app/Listeners/SendCancellationEmail.php(67): App\\Listeners\\SendCancellationEmail->registerZoomFailure()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/Events/CallQueuedListener.php(141): App\\Listeners\\SendCancellationEmail->handle()\n#2 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Events\\CallQueuedListener->handle()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#4 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#28 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#30 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#31 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#32 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#35 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#36 {main}','2026-06-21 00:40:46'),(10,'99aae2d3-204d-4619-a032-4ee4e4f365d6','database','default','{\"uuid\":\"99aae2d3-204d-4619-a032-4ee4e4f365d6\",\"displayName\":\"App\\\\Listeners\\\\SendCancellationEmail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":3,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":\"60\",\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":28:{s:5:\\\"class\\\";s:35:\\\"App\\\\Listeners\\\\SendCancellationEmail\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:31:\\\"App\\\\Events\\\\AppointmentCancelled\\\":1:{s:11:\\\"appointment\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:22:\\\"App\\\\Models\\\\Appointment\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:3:{i:0;s:6:\\\"doctor\\\";i:1;s:15:\\\"doctor.settings\\\";i:2;s:6:\\\"clinic\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";i:3;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";i:60;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:23:\\\"deleteWhenMissingModels\\\";b:0;s:14:\\\"shouldBeUnique\\\";b:0;s:29:\\\"shouldBeUniqueUntilProcessing\\\";b:0;s:8:\\\"uniqueId\\\";N;s:9:\\\"uniqueFor\\\";N;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1781615808,\"delay\":null}','Error: Class \"App\\Listeners\\DB\" not found in /var/www/html/app/Listeners/SendCancellationEmail.php:107\nStack trace:\n#0 /var/www/html/app/Listeners/SendCancellationEmail.php(67): App\\Listeners\\SendCancellationEmail->registerZoomFailure()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/Events/CallQueuedListener.php(141): App\\Listeners\\SendCancellationEmail->handle()\n#2 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Events\\CallQueuedListener->handle()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#4 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#28 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#30 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#31 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#32 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#35 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#36 {main}','2026-06-21 00:40:52'),(11,'15a8c278-3548-47ec-b712-302935074c9a','database','default','{\"uuid\":\"15a8c278-3548-47ec-b712-302935074c9a\",\"displayName\":\"App\\\\Listeners\\\\SendCancellationEmail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":3,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":\"60\",\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":28:{s:5:\\\"class\\\";s:35:\\\"App\\\\Listeners\\\\SendCancellationEmail\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:31:\\\"App\\\\Events\\\\AppointmentCancelled\\\":1:{s:11:\\\"appointment\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:22:\\\"App\\\\Models\\\\Appointment\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:3:{i:0;s:6:\\\"doctor\\\";i:1;s:15:\\\"doctor.settings\\\";i:2;s:6:\\\"clinic\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";i:3;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";i:60;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:23:\\\"deleteWhenMissingModels\\\";b:0;s:14:\\\"shouldBeUnique\\\";b:0;s:29:\\\"shouldBeUniqueUntilProcessing\\\";b:0;s:8:\\\"uniqueId\\\";N;s:9:\\\"uniqueFor\\\";N;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1781615808,\"delay\":null}','Error: Class \"App\\Listeners\\DB\" not found in /var/www/html/app/Listeners/SendCancellationEmail.php:107\nStack trace:\n#0 /var/www/html/app/Listeners/SendCancellationEmail.php(67): App\\Listeners\\SendCancellationEmail->registerZoomFailure()\n#1 /var/www/html/vendor/laravel/framework/src/Illuminate/Events/CallQueuedListener.php(141): App\\Listeners\\SendCancellationEmail->handle()\n#2 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Events\\CallQueuedListener->handle()\n#3 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#4 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#5 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(136): Illuminate\\Container\\Container->call()\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():133}()\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(140): Illuminate\\Pipeline\\Pipeline->then()\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(153): Illuminate\\Bus\\Dispatcher->dispatchNow()\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():146}()\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(137): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():178}()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(146): Illuminate\\Pipeline\\Pipeline->then()\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(84): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware()\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call()\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(515): Illuminate\\Queue\\Jobs\\Job->fire()\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(461): Illuminate\\Queue\\Worker->process()\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(224): Illuminate\\Queue\\Worker->runJob()\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(799): Illuminate\\Container\\BoundMethod::call()\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(280): Illuminate\\Container\\Container->call()\n#28 /var/www/html/vendor/symfony/console/Command/Command.php(291): Illuminate\\Console\\Command->execute()\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(249): Symfony\\Component\\Console\\Command\\Command->run()\n#30 /var/www/html/vendor/symfony/console/Application.php(1107): Illuminate\\Console\\Command->run()\n#31 /var/www/html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#32 /var/www/html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#35 /var/www/html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#36 {main}','2026-06-21 00:40:52');
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `indexed_symptoms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `indexed_symptoms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `search_query` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `specialty_id` bigint(20) unsigned DEFAULT NULL,
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `urgency_level` varchar(255) DEFAULT NULL,
  `ai_advice` text DEFAULT NULL,
  `search_count` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `indexed_symptoms_search_query_unique` (`search_query`),
  UNIQUE KEY `indexed_symptoms_slug_unique` (`slug`),
  KEY `indexed_symptoms_specialty_id_foreign` (`specialty_id`),
  CONSTRAINT `indexed_symptoms_specialty_id_foreign` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `indexed_symptoms` WRITE;
/*!40000 ALTER TABLE `indexed_symptoms` DISABLE KEYS */;
INSERT INTO `indexed_symptoms` VALUES (1,'Fiebre alta que no baja','fiebre-alta-que-no-baja',1,'¿Sientes Fiebre alta que no baja? Orientación Médica Online','¿Sufres de fiebre alta que no baja? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Si la fiebre supera los 38.5°C por más de 48 horas o se acompaña de rigidez en el cuello, es vital una valoración médica presencial.',53,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(2,'Fatiga crónica y cansancio extremo','fatiga-cronica-y-cansancio-extremo',1,'¿Sientes Fatiga crónica y cansancio extremo? Orientación Médica Online','¿Sufres de fatiga crónica y cansancio extremo? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','El cansancio persistente puede deberse a anemias, problemas tiroideos o deficiencias vitamínicas. Requiere analítica de sangre.',49,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(3,'Pérdida de peso repentina sin hacer dieta','perdida-de-peso-repentina-sin-hacer-dieta',1,'¿Sientes Pérdida de peso repentina sin hacer dieta? Orientación Médica Online','¿Sufres de pérdida de peso repentina sin hacer dieta? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Una pérdida de peso inexplicable requiere descartar problemas metabólicos o condiciones subyacentes con un médico internista.',48,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(4,'Sudores nocturnos excesivos','sudores-nocturnos-excesivos',1,'¿Sientes Sudores nocturnos excesivos? Orientación Médica Online','¿Sufres de sudores nocturnos excesivos? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Sudar intensamente por las noches de forma recurrente amerita un chequeo médico completo para evaluar causas del sistema inmune o linfático.',62,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(5,'Presión arterial alta síntomas','presion-arterial-alta-sintomas',1,'¿Sientes Presión arterial alta síntomas? Orientación Médica Online','¿Sufres de presión arterial alta síntomas? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','La hipertensión suele ser silenciosa, pero si presenta dolor de cabeza fuerte o zumbido en oídos, debe tomarse la presión de inmediato.',45,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(6,'Fiebre en bebés de tres meses','fiebre-en-bebes-de-tres-meses',4,'¿Sientes Fiebre en bebés de tres meses? Orientación Médica Online','¿Sufres de fiebre en bebés de tres meses? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Alta','Cualquier pico febril en lactantes menores de 3 meses debe ser evaluado urgentemente por un pediatra de guardia.',59,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(7,'Cólicos fuertes en lactantes','colicos-fuertes-en-lactantes',4,'¿Sientes Cólicos fuertes en lactantes? Orientación Médica Online','¿Sufres de cólicos fuertes en lactantes? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Los cólicos son comunes el primer trimestre, pero si hay vómitos constantes o llanto inconsolable por horas, consulte al pediatra.',53,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(8,'Brote en la piel de niños con fiebre','brote-en-la-piel-de-ninos-con-fiebre',4,'¿Sientes Brote en la piel de niños con fiebre? Orientación Médica Online','¿Sufres de brote en la piel de niños con fiebre? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Alta','Las erupciones cutáneas acompañadas de fiebre pueden indicar infecciones exantemáticas que requieren diagnóstico pediátrico inmediato.',31,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(9,'Tos perruna en niños por la noche','tos-perruna-en-ninos-por-la-noche',4,'¿Sientes Tos perruna en niños por la noche? Orientación Médica Online','¿Sufres de tos perruna en niños por la noche? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Suele deberse a laringitis. Mantener al niño en un ambiente húmedo ayuda, pero vigile que no tenga dificultad para respirar.',35,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(10,'Retraso menstrual y dolor de ovarios','retraso-menstrual-y-dolor-de-ovarios',6,'¿Sientes Retraso menstrual y dolor de ovarios? Orientación Médica Online','¿Sufres de retraso menstrual y dolor de ovarios? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Descarte primero un embarazo. Si es negativo, los desajustes hormonales o quistes ováricos deben ser evaluados por un ginecólogo.',36,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(11,'Flujo vaginal con mal olor y picazón','flujo-vaginal-con-mal-olor-y-picazon',6,'¿Sientes Flujo vaginal con mal olor y picazón? Orientación Médica Online','¿Sufres de flujo vaginal con mal olor y picazón? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Son síntomas claros de una infección por hongos o bacteriana. Evite la automedicación y asista a una consulta para frotis.',26,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(12,'Sangrado fuera del periodo menstrual','sangrado-fuera-del-periodo-menstrual',6,'¿Sientes Sangrado fuera del periodo menstrual? Orientación Médica Online','¿Sufres de sangrado fuera del periodo menstrual? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','El sangrado intermenstrual debe ser valorado mediante ecografía para descartar pólipos, miomas o alteraciones endometriales.',32,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(13,'Dolor menstrual muy fuerte que incapacita','dolor-menstrual-muy-fuerte-que-incapacita',6,'¿Sientes Dolor menstrual muy fuerte que incapacita? Orientación Médica Online','¿Sufres de dolor menstrual muy fuerte que incapacita? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','La dismenorrea severa no es normal y puede ser señal de endometriosis. Un especialista debe realizar una evaluación detallada.',45,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(14,'Dolor en el pecho que se va al brazo izquierdo','dolor-en-el-pecho-que-se-va-al-brazo-izquierdo',3,'¿Sientes Dolor en el pecho que se va al brazo izquierdo? Orientación Médica Online','¿Sufres de dolor en el pecho que se va al brazo izquierdo? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Alta','Este es un síntoma de alarma de infarto. Acuda inmediatamente a la sala de emergencias más cercana. No espere.',40,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(15,'Palpitaciones fuertes en el pecho en reposo','palpitaciones-fuertes-en-el-pecho-en-reposo',3,'¿Sientes Palpitaciones fuertes en el pecho en reposo? Orientación Médica Online','¿Sufres de palpitaciones fuertes en el pecho en reposo? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Sentir el ritmo cardíaco acelerado sin hacer esfuerzo requiere un electrocardiograma para descartar arritmias.',63,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(16,'Falta de aire al caminar poco','falta-de-aire-al-caminar-poco',3,'¿Sientes Falta de aire al caminar poco? Orientación Médica Online','¿Sufres de falta de aire al caminar poco? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','La disnea de esfuerzo puede vincularse a insuficiencia cardíaca o problemas pulmonares. Requiere valoración cardiológica.',52,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(17,'Lunar que cambia de color y bordes irregulares','lunar-que-cambia-de-color-y-bordes-irregulares',5,'¿Sientes Lunar que cambia de color y bordes irregulares? Orientación Médica Online','¿Sufres de lunar que cambia de color y bordes irregulares? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Sigue la regla ABCDE del melanoma. Cualquier cambio de tamaño, borde o color exige una revisión con dermatoscopio.',46,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(18,'Caída del cabello por estrés en mujeres','caida-del-cabello-por-estres-en-mujeres',5,'¿Sientes Caída del cabello por estrés en mujeres? Orientación Médica Online','¿Sufres de caída del cabello por estrés en mujeres? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','El efluvio telógeno es común tras periodos de estrés. Un dermatólogo puede guiarte con lociones y suplementos específicos.',57,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(19,'Manchas rojas en la piel que pican mucho','manchas-rojas-en-la-piel-que-pican-mucho',5,'¿Sientes Manchas rojas en la piel que pican mucho? Orientación Médica Online','¿Sufres de manchas rojas en la piel que pican mucho? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Puede tratarse de dermatitis, eccemas o urticaria. Evite rascarse para no causar infecciones bacterianas secundarias.',60,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(20,'Acné quístico severo en la edad adulta','acne-quistico-severo-en-la-edad-adulta',5,'¿Sientes Acné quístico severo en la edad adulta? Orientación Médica Online','¿Sufres de acné quístico severo en la edad adulta? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','El acné nodular requiere tratamientos médicos dermatológicos regulados para evitar cicatrices profundas en la piel.',61,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(21,'Dolor de espalda baja que baja por la pierna','dolor-de-espalda-baja-que-baja-por-la-pierna',10,'¿Sientes Dolor de espalda baja que baja por la pierna? Orientación Médica Online','¿Sufres de dolor de espalda baja que baja por la pierna? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Suele indicar una compresión del nervio ciático o hernia discal. Evite cargar peso y consulte con un especialista.',29,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(22,'Dolor de rodilla al bajar escaleras','dolor-de-rodilla-al-bajar-escaleras',10,'¿Sientes Dolor de rodilla al bajar escaleras? Orientación Médica Online','¿Sufres de dolor de rodilla al bajar escaleras? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Común en problemas de desgaste de cartílago (condromalacia) o meniscos. Un traumatólogo evaluará si requiere resonancia.',28,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(23,'Esguince de tobillo hinchado y morado','esguince-de-tobillo-hinchado-y-morado',10,'¿Sientes Esguince de tobillo hinchado y morado? Orientación Médica Online','¿Sufres de esguince de tobillo hinchado y morado? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Aplique hielo y mantenga el pie elevado. Es necesario una radiografía para descartar microfracturas óseas.',47,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(24,'Gastritis crónica y ardor en la boca del estómago','gastritis-cronica-y-ardor-en-la-boca-del-estomago',1,'¿Sientes Gastritis crónica y ardor en la boca del estómago? Orientación Médica Online','¿Sufres de gastritis crónica y ardor en la boca del estómago? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','El reflujo y ardor constante pueden requerir una endoscopia para descartar la bacteria Helicobacter pylori.',27,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(25,'Estreñimiento severo de varios días','estrenimiento-severo-de-varios-dias',1,'¿Sientes Estreñimiento severo de varios días? Orientación Médica Online','¿Sufres de estreñimiento severo de varios días? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Aumente el consumo de agua y fibra. Si se acompaña de dolor abdominal intenso o vómitos, acuda a urgencias.',41,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(26,'Sangre roja brillante al evacuar','sangre-roja-brillante-al-evacuar',1,'¿Sientes Sangre roja brillante al evacuar? Orientación Médica Online','¿Sufres de sangre roja brillante al evacuar? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Frecuente en hemorroides o fisuras, pero es mandatorio un chequeo proctológico para descartar patologías mayores del colon.',60,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(27,'Hinchazón abdominal y gases después de comer','hinchazon-abdominal-y-gases-despues-de-comer',1,'¿Sientes Hinchazón abdominal y gases después de comer? Orientación Médica Online','¿Sufres de hinchazón abdominal y gases después de comer? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Puede estar asociado al síndrome de intestino irritable o intolerancias alimentarias (gluten, lactosa).',42,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(28,'Dolor de cabeza insoportable con sensibilidad a la luz','dolor-de-cabeza-insoportable-con-sensibilidad-a-la-luz',1,'¿Sientes Dolor de cabeza insoportable con sensibilidad a la luz? Orientación Médica Online','¿Sufres de dolor de cabeza insoportable con sensibilidad a la luz? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Media','Son síntomas clásicos de migraña con fotofobia. Un neurólogo te ayudará a establecer un tratamiento preventivo eficaz.',32,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(29,'Mareos constantes al mover la cabeza','mareos-constantes-al-mover-la-cabeza',1,'¿Sientes Mareos constantes al mover la cabeza? Orientación Médica Online','¿Sufres de mareos constantes al mover la cabeza? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Puede relacionarse con vértigo posicional paroxístico benigno o problemas del oído interno. Requiere diagnóstico.',58,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(30,'Hormigueo y entumecimiento en las manos por las noches','hormigueo-y-entumecimiento-en-las-manos-por-las-noches',1,'¿Sientes Hormigueo y entumecimiento en las manos por las noches? Orientación Médica Online','¿Sufres de hormigueo y entumecimiento en las manos por las noches? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Síntoma muy habitual del síndrome del túnel carpiano debido a la compresión del nervio mediano en la muñeca.',38,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(31,'Zumbido en el oído constante (Tinnitus)','zumbido-en-el-oido-constante-tinnitus',7,'¿Sientes Zumbido en el oído constante (Tinnitus)? Orientación Médica Online','¿Sufres de zumbido en el oído constante (tinnitus)? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','El tinnitus requiere un estudio audiológico completo para determinar si existe pérdida auditiva asociada.',48,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(32,'Dolor de oído fuerte después de nadar','dolor-de-oido-fuerte-despues-de-nadar',7,'¿Sientes Dolor de oído fuerte después de nadar? Orientación Médica Online','¿Sufres de dolor de oído fuerte después de nadar? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Indica una otitis externa (oído de nadador). Suele requerir gotas antibióticas recetadas por el médico.',67,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(33,'Pérdida del olfato y congestión nasal crónica','perdida-del-olfato-y-congestion-nasal-cronica',7,'¿Sientes Pérdida del olfato y congestión nasal crónica? Orientación Médica Online','¿Sufres de pérdida del olfato y congestión nasal crónica? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','La sinusitis crónica o los pólipos nasales pueden obstruir las vías. Se recomienda una nasosinusoscopia.',30,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(34,'Ardor intenso al orinar y ganas constantes','ardor-intenso-al-orinar-y-ganas-constantes',11,'¿Sientes Ardor intenso al orinar y ganas constantes? Orientación Médica Online','¿Sufres de ardor intenso al orinar y ganas constantes? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Síntomas comunes de infección urinaria (cistitis). Requiere un examen de orina (urocultivo) para dar el antibiótico correcto.',61,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(35,'Dificultad para orinar y chorro débil en hombres','dificultad-para-orinar-y-chorro-debil-en-hombres',11,'¿Sientes Dificultad para orinar y chorro débil en hombres? Orientación Médica Online','¿Sufres de dificultad para orinar y chorro débil en hombres? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','En hombres mayores de 45 años suele indicar un crecimiento de la próstata (hiperplasia). Requiere control anual urológico.',46,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(36,'Visión borrosa de repente en un ojo','vision-borrosa-de-repente-en-un-ojo',8,'¿Sientes Visión borrosa de repente en un ojo? Orientación Médica Online','¿Sufres de visión borrosa de repente en un ojo? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Alta','La pérdida súbita de visión es una emergencia médica que puede deberse a desprendimiento de retina o problemas vasculares.',38,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(37,'Ojos rojos con lagaña verde y picazón','ojos-rojos-con-lagana-verde-y-picazon',8,'¿Sientes Ojos rojos con lagaña verde y picazón? Orientación Médica Online','¿Sufres de ojos rojos con lagaña verde y picazón? Lee nuestra guía de orientación médica, conoce el nivel de urgencia y agenda cita con especialistas.','Baja','Suelen ser signos de conjuntivitis bacteriana. Evite tocarse los ojos para no contagiar el otro ojo y use gotas indicadas.',77,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(38,'Estornudos frecuentes, congestión nasal, picor en nariz o garganta, ojos llorosos, tos seca, sibilancias','estornudos-frecuentes-congestion-nasal-picor-en-nariz-o-garganta-ojos-llorosos-tos-seca-sibilancias',24,'Síntomas de Alergia: Estornudos, Congestión y Más','Descubre los síntomas relacionados con alergias, como estornudos frecuentes, congestión nasal y picor. Aprende cómo un alergólogo puede ayudarte.','Media','Es recomendable evitar alérgenos conocidos y considerar una consulta con un alergólogo para pruebas y tratamiento adecuado.',2,'2026-06-22 16:10:17','2026-06-22 16:10:17'),(39,'me duele la cabeza','me-duele-la-cabeza',1,'Dolor de Cabeza - Causas y Tratamientos','Descubre las causas comunes del dolor de cabeza y cuándo es necesario consultar a un médico. Obtén información útil y consejos para el alivio.','Media','Es recomendable que consultes a un médico si el dolor persiste o se agrava, especialmente si está acompañado de otros síntomas como náuseas, vómitos o visión borrosa.',3,'2026-06-22 17:22:12','2026-06-22 17:22:12'),(40,'Alergologia','alergologia',NULL,'Consulta a un Alergólogo para Tu Salud','¿Tienes síntomas de alergia? Un alergólogo puede ayudarte a identificar y tratar tus alergias de manera efectiva.','Media','Si presentas síntomas de alergia como estornudos, picazón, o irritación en la piel, es recomendable que consultes a un alergólogo para una evaluación adecuada y tratamiento.',1,'2026-06-22 21:40:09','2026-06-22 21:40:09');
/*!40000 ALTER TABLE `indexed_symptoms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `insurances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `insurances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `insurances_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `insurances` WRITE;
/*!40000 ALTER TABLE `insurances` DISABLE KEYS */;
INSERT INTO `insurances` VALUES (1,'Particular / Prepagada','PART01',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(2,'EPS SURA','EPS010',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(3,'EPS Sanitas','EPS005',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(4,'Salud Total','EPS002',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(5,'Nueva EPS','EPS037',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(6,'Compensar EPS','EPS008',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(7,'Coosalud','ESS024',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(8,'Aliansalud','EPS001',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(9,'Famisanar','EPS017',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(10,'S.O.S','EPS018',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(11,'Salud Mía','EPS046',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(12,'Mutual Ser','EPS048',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(13,'Asmet Salud','ESS062',1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(14,'Capital Salud','EPSS37',1,'2026-06-07 12:46:47','2026-06-07 12:46:47');
/*!40000 ALTER TABLE `insurances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` smallint(5) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=4281 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `medical_analyses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medical_analyses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `access_token` varchar(64) DEFAULT NULL COMMENT 'Token público impredecible usado en la URL en vez del ID autoincremental',
  `file_paths` text DEFAULT NULL,
  `ai_response` longtext DEFAULT NULL,
  `ai_provider` enum('openai','claude','gemini') DEFAULT NULL COMMENT 'Proveedor de IA usado para generar ai_response',
  `customer_email` varchar(255) NOT NULL,
  `reason_type` varchar(255) NOT NULL,
  `reason_custom` text DEFAULT NULL,
  `status` enum('pending','processing','completed','failed','error') NOT NULL DEFAULT 'pending',
  `payment_id` varchar(255) DEFAULT NULL,
  `payment_status` enum('pending','processing','completed','failed','error') NOT NULL DEFAULT 'pending',
  `price` decimal(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `access_token` (`access_token`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `medical_analyses` WRITE;
/*!40000 ALTER TABLE `medical_analyses` DISABLE KEYS */;
INSERT INTO `medical_analyses` VALUES (1,'isaKeboFotRY3K3jPJY0INxQqea7OEyaEBbQEZIXYLaek030','\"[\\\"medical-exams\\\\\\/AdvxkHMAI3om2Mg3PHrEjpI4iIwWYCJoUukSpDMK.pdf\\\"]\"',NULL,'openai','cgoprayer@gmail.com','rutina','diabetes','failed',NULL,'pending',18700.00,'2026-06-19 21:19:52','2026-06-19 23:20:03'),(2,'DDnlEFISlWO3fSvHEEdt0OZwbNZUpyMl1x5mG7ycDRGY4kDj','\"[\\\"medical-exams\\\\\\/4fMCDLTDVopwL8xnvnfsDwWEJEdj16zCHaCDqO98.pdf\\\"]\"',NULL,'openai','cgoprayer@gmail.com','rutina','diabetes','failed',NULL,'pending',18700.00,'2026-06-19 21:23:18','2026-06-19 23:20:03'),(3,'wjbIUqPkSWV57ITrmr3fM40YrMYpMsTnUham1Mv5MBWxGyQ1','\"[\\\"medical-exams\\\\\\/IqGueOvbPbi27vZcK9W1bMqfSAQIB0IiIV6JqZc8.pdf\\\"]\"',NULL,'openai','cgoprayer@gmail.com','rutina','diabetes','failed',NULL,'pending',18700.00,'2026-06-19 21:51:32','2026-06-19 23:20:03'),(4,'sl7KmD6424SnfRIt7rl7Y5DJm2fKnDlndxWKBZu4CHWRWtmm','\"[\\\"medical-exams\\\\\\/WpFHEbeqEIVxwJ3PhxIuzVx2gWJdcWpmFFQofqEW.pdf\\\"]\"',NULL,'openai','cgoprayer@gmail.com','rutina','diabetes','failed',NULL,'pending',18700.00,'2026-06-19 22:44:24','2026-06-19 23:20:03'),(5,'BPgY0p6FEtvox98GxDUgO4fF3UfPW3HLZDxNdDZD5Z7g2QEs','\"[\\\"medical-exams\\\\\\/TIkpOD9DiQoKuZAaajmMqXbDxIcXwvzbvbcvjg2Y.pdf\\\"]\"','{\"nombre_examen\":\"Qu\\u00edmica cl\\u00ednica (microalbuminuria en orina parcial + perfil lip\\u00eddico)\",\"especialidad_slug\":\"endocrinologia\",\"hallazgos_clave\":[{\"parametro\":\"Creatinina, orina parcial\",\"valor_detectado\":\"262.00 mg\\/dL\",\"estado\":\"Elevado\"},{\"parametro\":\"Albuminuria en orina parcial\",\"valor_detectado\":\"50.80 mg\\/L\",\"estado\":\"Elevado\"},{\"parametro\":\"Relaci\\u00f3n alb\\u00famina\\/creatinina (ACR) microalbuminuria\",\"valor_detectado\":\"19.39 mgAlb\\/gCre\",\"estado\":\"Normal\"},{\"parametro\":\"Colesterol HDL\",\"valor_detectado\":\"35.5 mg\\/dL\",\"estado\":\"Bajo\"},{\"parametro\":\"Colesterol total\",\"valor_detectado\":\"318.0 mg\\/dL\",\"estado\":\"Elevado\"},{\"parametro\":\"Colesterol LDL (calculado\\/reportado)\",\"valor_detectado\":\"165 mg\\/dL (ref. hasta 130). Nota: interpretar con cautela por hipertrigliceridemia; sugieren LDL directo\",\"estado\":\"Elevado\"}],\"conclusion_paciente\":\"En control preventivo con antecedente de diabetes: el perfil lip\\u00eddico est\\u00e1 alterado con hipercolesterolemia marcada (colesterol total 318 mg\\/dL), LDL elevado (165 mg\\/dL) y HDL bajo (35.5 mg\\/dL), lo que incrementa el riesgo cardiovascular. En ri\\u00f1\\u00f3n\\/diabetes: la relaci\\u00f3n alb\\u00famina\\/creatinina (ACR) es 19.39 mg\\/g (dentro de rango <20), sin evidencia de albuminuria persistente en este resultado; sin embargo, la alb\\u00famina en muestra aislada (50.8 mg\\/L) est\\u00e1 elevada y conviene confirmar con repetici\\u00f3n\\/seguimiento (idealmente ACR en primera orina de la ma\\u00f1ana).\",\"recomendaciones\":\"1) Dislipidemia: priorizar manejo intensivo del riesgo cardiovascular en diabetes (cambios de estilo de vida + discutir inicio\\/ajuste de estatina de alta intensidad seg\\u00fan gu\\u00edas y riesgo global). 2) Confirmaci\\u00f3n de l\\u00edpidos: solicitar triglic\\u00e9ridos (no visibles en esta p\\u00e1gina) y repetir perfil lip\\u00eddico en ayunas; pedir LDL directo si hay hipertrigliceridemia (tal como sugiere el informe). 3) Ri\\u00f1\\u00f3n\\/diabetes: repetir ACR (microalbuminuria) en 1\\u20133 meses o en 2 de 3 muestras si hay sospecha; complementar con creatinina s\\u00e9rica y eGFR (no visibles aqu\\u00ed) y control de presi\\u00f3n arterial. 4) Control metab\\u00f3lico: verificar HbA1c y glucosa (no visibles en esta p\\u00e1gina) para ajustar tratamiento de diabetes. 5) Si LDL permanece elevado o hay alto riesgo: considerar evaluaci\\u00f3n cardiovascular global y metas de LDL m\\u00e1s estrictas; seguimiento con endocrinolog\\u00eda\\/medicina general.\"}','openai','cgoprayer@gmail.com','rutina','diabetes','completed',NULL,'pending',18700.00,'2026-06-19 22:49:26','2026-06-19 23:20:03'),(6,'6jjgfzKsoxUOgN9stxMO0yobO23LDkaFDWRCsRm7WmOFWgKe','\"[\\\"medical-exams\\\\\\/2AxH8lYc5bXRYIQTHd6LvNS4Sxg096q64Tjqod3S.pdf\\\"]\"','{\"nombre_examen\":\"Quimica clinica (microalbuminuria en orina parcial y perfil lipidico)\",\"especialidad_slug\":\"endocrinologia\",\"hallazgos_clave\":[{\"parametro\":\"Creatinina, orina parcial\",\"valor_detectado\":\"262.00 mg\\/dL\",\"estado\":\"Elevado\"},{\"parametro\":\"Albuminuria en orina parcial\",\"valor_detectado\":\"50.80 mg\\/L\",\"estado\":\"Elevado\"},{\"parametro\":\"Relacion albuminuria\\/creatinina (ACR)\",\"valor_detectado\":\"19.39 mgAlb\\/gCre\",\"estado\":\"Normal\"},{\"parametro\":\"Colesterol HDL\",\"valor_detectado\":\"35.5 mg\\/dL\",\"estado\":\"Bajo\"},{\"parametro\":\"Colesterol total\",\"valor_detectado\":\"318.0 mg\\/dL\",\"estado\":\"Elevado\"},{\"parametro\":\"Colesterol LDL (calculado)\",\"valor_detectado\":\"165 mg\\/dL (nota: interpretar con cautela por hipertrigliceridemia; sugieren LDL directo)\",\"estado\":\"Elevado\"}],\"conclusion_paciente\":\"En el contexto de diabetes y control preventivo, el perfil lipidico muestra dislipidemia significativa: colesterol total muy alto (318), LDL alto (165; con recomendacion del laboratorio de confirmar con LDL directo por posible hipertrigliceridemia) y HDL bajo (35.5), lo que incrementa el riesgo cardiovascular. En tamizaje renal por diabetes, la relacion albumina\\/creatinina (ACR) es 19.39 mg\\/g, dentro de rango normal (<20), sin evidencia de albuminuria persistente en este resultado; sin embargo, la albumina en orina (50.8 mg\\/L) y la creatinina urinaria (262 mg\\/dL) aparecen elevadas de forma aislada y deben interpretarse con el ACR y repeticion\\/confirmacion segun protocolo.\",\"recomendaciones\":\"1) Riesgo cardiovascular (diabetes + dislipidemia): consultar para ajuste\\/optimizacion de manejo lipidico (habitualmente estatina de alta intensidad en diabetes segun riesgo) y metas de LDL individualizadas. 2) Confirmar LDL: solicitar LDL directo y trigliceridos en ayunas (el informe sugiere hipertrigliceridemia que puede alterar el calculo). 3) Completar evaluacion metabolica: HbA1c, glucosa en ayunas, funcion hepatica (AST\\/ALT) antes\\/tras cambios de estatina, y presion arterial. 4) Ri\\u00f1on diabetico: repetir ACR en orina (ideal primera orina de la ma\\u00f1ana) para confirmar ausencia de albuminuria (se recomienda 2 de 3 muestras anormales en 3\\u20136 meses para diagnostico). Solicitar creatinina serica y eGFR si no estan disponibles. 5) Estilo de vida: plan nutricional (reduccion de grasas saturadas\\/trans, azucares simples y alcohol si TG altos), actividad fisica regular y control de peso; adherencia a tratamiento antidiabetico. 6) Si hay antecedentes de enfermedad cardiovascular, dolor toracico, disnea o multiples factores de riesgo, considerar valoracion adicional de riesgo cardiovascular y manejo integral.\"}','openai','cgoprayer@gmail.com','rutina','diabetes','completed',NULL,'pending',18700.00,'2026-06-20 00:06:17','2026-06-20 00:06:27'),(7,'TQl6OpROUUbXd8QRVkwSGesuam082P7ZPCTusN26lzuV3g0K',NULL,'{\"nombre_examen\":\"Quimica clinica (microalbuminuria en orina parcial y perfil lipidico)\",\"especialidad_slug\":\"endocrinologia\",\"hallazgos_clave\":[{\"parametro\":\"Creatinina, orina parcial\",\"valor_detectado\":\"262.00 mg\\/dL\",\"estado\":\"Elevado\"},{\"parametro\":\"Albuminuria en orina parcial\",\"valor_detectado\":\"50.80 mg\\/L\",\"estado\":\"Elevado\"},{\"parametro\":\"Relacion albuminuria\\/creatinina (ACR)\",\"valor_detectado\":\"19.39 mgAlb\\/gCre\",\"estado\":\"Normal\"},{\"parametro\":\"Colesterol HDL\",\"valor_detectado\":\"35.5 mg\\/dL\",\"estado\":\"Bajo\"},{\"parametro\":\"Colesterol total\",\"valor_detectado\":\"318.0 mg\\/dL\",\"estado\":\"Elevado\"},{\"parametro\":\"Colesterol LDL (calculado)\",\"valor_detectado\":\"165 mg\\/dL\",\"estado\":\"Elevado\"}],\"conclusion_paciente\":\"En el control se observa dislipidemia importante (colesterol total muy alto, LDL alto y HDL bajo), lo que incrementa el riesgo cardiovascular, especialmente en el contexto de diabetes. En el tamizaje renal por diabetes, la relacion albumina\\/creatinina (ACR) es normal (<20 mg\\/g), sin evidencia de microalbuminuria por este indice, aunque la albumina en orina aislada aparece elevada; el ACR es el parametro principal para clasificacion y seguimiento.\",\"recomendaciones\":\"1) Diabetes y riesgo cardiovascular: priorizar manejo intensivo de lipidos (objetivo de LDL mas estricto en diabetes); discutir inicio\\/ajuste de estatina de alta intensidad y evaluar necesidad de terapia adicional segun riesgo global. 2) Repetir perfil lipidico en ayunas y solicitar LDL directo (el informe sugiere cautela por hipertrigliceridemia, que puede alterar el calculo de LDL). 3) Ri\\u00f1on: repetir ACR (primera orina de la ma\\u00f1ana) para confirmacion y seguimiento anual; complementar con creatinina serica y eGFR (si no estan disponibles) y control de presion arterial. 4) Estilo de vida: plan nutricional (reducir grasas saturadas\\/trans, azucares simples), actividad fisica regular, control de peso y evitar tabaco\\/alcohol excesivo. 5) Seguimiento: control con endocrinologia\\/medicina general en 4\\u201312 semanas para revisar metas de LDL, adherencia y efectos adversos; antes si hay sintomas cardiovasculares.\"}','openai','ocampotecnologo@gmail.com','rutina','diabetes','completed','7-26062010-HPKZ5','failed',18700.00,'2026-06-20 00:47:30','2026-06-20 10:47:02');
/*!40000 ALTER TABLE `medical_analyses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `medical_expertises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medical_expertises` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `disease_name` varchar(255) NOT NULL,
  `symptoms_keywords` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `medical_expertises_doctor_id_foreign` (`doctor_id`),
  FULLTEXT KEY `medical_expertises_disease_name_symptoms_keywords_fulltext` (`disease_name`,`symptoms_keywords`),
  CONSTRAINT `medical_expertises_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `medical_expertises` WRITE;
/*!40000 ALTER TABLE `medical_expertises` DISABLE KEYS */;
/*!40000 ALTER TABLE `medical_expertises` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_04_26_153750_add_two_factor_columns_to_users_table',1),(5,'2026_04_26_153800_create_personal_access_tokens_table',1),(6,'2026_04_28_150005_create_permission_tables',1),(7,'2026_04_28_205305_create_plans_table',1),(8,'2026_04_28_205306_create_specialties_table',1),(9,'2026_04_28_205307_create_doctors_table',1),(10,'2026_04_28_205316_create_insurances_table',1),(11,'2026_04_28_205317_create_patients_table',1),(12,'2026_04_28_205330_create_departments_table',1),(13,'2026_04_28_205331_create_cities_table',1),(14,'2026_04_28_205332_create_clinics_table',1),(15,'2026_04_28_205333_create_addresses_table',1),(16,'2026_04_28_205341_create_schedules_table',1),(17,'2026_04_28_205347_create_services_table',1),(18,'2026_04_28_205348_create_appointments_table',1),(19,'2026_04_28_205622_create_unavailabilities_table',1),(20,'2026_04_30_235804_create_doctor_specialty_table',1),(21,'2026_05_01_094154_create_reviews_table',1),(22,'2026_05_01_105657_create_address_service_table',1),(23,'2026_05_02_070138_create_notifications_table',1),(24,'2026_05_02_180444_create_campaigns_table',1),(25,'2026_05_03_112915_create_contact_messages_table',1),(26,'2026_05_04_192852_create_doctor_settings_table',1),(27,'2026_05_06_220100_create_patient_allergies_table',1),(28,'2026_05_06_220251_create_patient_surgeries_table',1),(29,'2026_05_06_220343_create_patient_family_histories_table',1),(30,'2026_05_06_220704_create_patient_medications_table',1),(31,'2026_05_06_220847_create_patient_histories_table',1),(32,'2026_05_06_223654_create_patient_consents_table',1),(33,'2026_05_13_183846_create_medical_expertises_table',1),(34,'2026_05_22_143009_create_indexed_symptoms_table',1),(35,'2026_05_23_225607_create_exam_analyses_table',1),(36,'2026_05_24_101730_create_clinic_settings_table',1),(37,'2026_05_24_125649_create_clinic_doctor_table',1),(38,'2026_05_26_184832_create_clinic_specialty_table',1),(39,'2026_05_29_064954_create_patient_history_attachments_table',1),(40,'2026_06_01_200144_create_zoom_creation_failures_table',1),(41,'2026_06_06_203044_create_service_specialty_table',1),(42,'2026_06_17_055153_create_search_logs_table',2),(43,'2024_01_01_000000_create_api_clients_table',3),(44,'2024_01_01_000000_create_appointment_events_table',3),(45,'2024_01_01_000000_create_appointment_state_transitions_table',3),(46,'2026_06_18_000001_create_api_clients_table',4),(47,'2026_06_18_000002_add_composite_indexes_for_optimization',5),(48,'2026_06_18_000002_create_api_client_endpoints_table',5),(49,'2026_06_18_000003_create_api_client_logs_table',5),(50,'2026_06_18_000000_add_clinic_context_to_schedules_table',6),(51,'2026_06_18_000000_create_affected_appointments_table',7),(52,'2026_06_19_000001_add_integrity_constraints_to_addresses',8),(53,'2024_01_01_000000_create_api_client_endpoints_table',9),(54,'2024_01_01_000000_create_api_client_logs_table',9),(55,'2026_06_19_143614_create_medical_analyses_table',10),(56,'2026_06_19_173007_create_settings_table',10),(57,'2026_06_22_192344_create_signed_documents_table',11);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',10),(2,'App\\Models\\User',3),(2,'App\\Models\\User',9),(3,'App\\Models\\User',1),(5,'App\\Models\\User',2);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('1a538a21-2759-4a0d-908f-244ef0fe479c','App\\Notifications\\AppointmentRescheduledNotification','App\\Models\\User',9,'{\"appointment_id\":11,\"reference\":\"26061507-7PK\",\"title\":\"Cita Reagendada\",\"message\":\"El paciente ha reagendado la cita 26061507-7PK para el d\\u00eda 18\\/06\\/2026 a las 10:20:00.\",\"action_url\":\"\\/patient\\/appointments\"}','2026-06-16 12:15:24','2026-06-16 12:11:31','2026-06-16 12:15:24'),('222a8a01-5011-4549-b210-a67089c7550a','App\\Notifications\\AppointmentRescheduledNotification','App\\Models\\User',9,'{\"appointment_id\":8,\"reference\":\"26061120-TBY\",\"title\":\"Cita Reagendada\",\"message\":\"El paciente ha reagendado la cita para el d\\u00eda 29\\/06\\/2026 a las 08:00:00.\",\"action_url\":\"\\/partner\\/appointments\"}','2026-06-16 11:45:31','2026-06-16 11:42:29','2026-06-16 11:45:31'),('74d167e3-a0ca-4e72-89a0-e2739f21f3f5','App\\Notifications\\AppointmentRescheduledNotification','App\\Models\\User',9,'{\"appointment_id\":16,\"reference\":\"26061821-L2J\",\"title\":\"Cita Reagendada\",\"message\":\"El paciente ha reagendado la cita 26061821-L2J para el d\\u00eda 25\\/06\\/2026 a las 13:40:00.\",\"action_url\":\"\\/partner\\/appointments\"}',NULL,'2026-06-18 21:22:16','2026-06-18 21:22:16'),('76943759-1bbf-47af-a7d5-4473117b42d1','App\\Notifications\\AppointmentCancelledNotification','App\\Models\\User',9,'{\"appointment_id\":16,\"reference\":\"26061821-L2J\",\"title\":\"Cita Cancelada\",\"message\":\"El paciente ha reagendado la cita 26061821-L2J para el d\\u00eda 25\\/06\\/2026 a las 13:40:00.\",\"action_url\":\"\\/partner\\/appointments\"}',NULL,'2026-06-18 21:37:39','2026-06-18 21:37:39'),('a1c0a50e-7493-4d9b-a774-fac077329ea1','App\\Notifications\\AppointmentRescheduledNotification','App\\Models\\User',3,'{\"appointment_id\":14,\"reference\":\"26061606-WGZ\",\"title\":\"Cita Reagendada\",\"message\":\"El paciente ha reagendado la cita para el d\\u00eda 19\\/06\\/2026 a las 09:00:00.\",\"action_url\":\"\\/patient\\/appointments\"}','2026-06-16 12:16:02','2026-06-16 09:10:52','2026-06-16 12:16:02'),('be44086d-7a51-45f1-be21-f8be1f53a4fa','App\\Notifications\\AppointmentRescheduledNotification','App\\Models\\User',9,'{\"appointment_id\":11,\"reference\":\"26061507-7PK\",\"title\":\"Cita Reagendada\",\"message\":\"El paciente ha reagendado la cita para el d\\u00eda 24\\/06\\/2026 a las 13:20:00.\",\"action_url\":\"\\/patient\\/appointments\"}','2026-06-16 11:33:41','2026-06-16 11:15:20','2026-06-16 11:33:41'),('c03cc517-9405-4e00-8d7f-4581f1bd3312','App\\Notifications\\AppointmentRescheduledNotification','App\\Models\\User',9,'{\"appointment_id\":16,\"reference\":\"26061821-L2J\",\"title\":\"Cita Reagendada\",\"message\":\"El paciente ha reagendado la cita 26061821-L2J para el d\\u00eda 23\\/06\\/2026 a las 10:00:00.\",\"action_url\":\"\\/partner\\/appointments\"}',NULL,'2026-06-18 21:21:29','2026-06-18 21:21:29'),('c260543b-0a8d-453e-a0aa-c23e70d9fffb','App\\Notifications\\AppointmentRescheduledNotification','App\\Models\\User',9,'{\"appointment_id\":11,\"reference\":\"26061507-7PK\",\"title\":\"Cita Reagendada\",\"message\":\"El paciente ha reagendado la cita 26061507-7PK para el d\\u00eda 18\\/06\\/2026 a las 17:00:00.\",\"action_url\":\"\\/partner\\/appointments\"}','2026-06-16 12:18:42','2026-06-16 12:18:11','2026-06-16 12:18:42'),('ddd72396-4aaf-4b79-ac2b-b88f5e416293','App\\Notifications\\ConsultationAudioUploadFailedNotification','App\\Models\\User',3,'{\"patient_id\":1,\"appointment_id\":null,\"title\":\"Audio de consulta sin subir\",\"message\":\"Hubo un problema de red al subir la grabaci\\u00f3n de la consulta con Pepito Perez lopez. Tu audio qued\\u00f3 guardado en este dispositivo \\u2014 entra a la ficha del paciente para reintentar la subida.\",\"action_url\":\"\\/partner\\/patients\\/1\"}','2026-06-21 16:58:33','2026-06-21 16:57:09','2026-06-21 16:58:33');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_allergies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_allergies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('drug','food','environment','other') NOT NULL DEFAULT 'other',
  `severity` enum('mild','moderate','severe') NOT NULL DEFAULT 'mild',
  `reaction` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_allergies_patient_id_foreign` (`patient_id`),
  CONSTRAINT `patient_allergies_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_allergies` WRITE;
/*!40000 ALTER TABLE `patient_allergies` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_allergies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_consents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_consents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `signed_at` datetime NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_consents_patient_id_foreign` (`patient_id`),
  KEY `patient_consents_doctor_id_foreign` (`doctor_id`),
  CONSTRAINT `patient_consents_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`),
  CONSTRAINT `patient_consents_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_consents` WRITE;
/*!40000 ALTER TABLE `patient_consents` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_consents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_family_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_family_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `condition` varchar(255) NOT NULL,
  `relationship` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_family_histories_patient_id_foreign` (`patient_id`),
  CONSTRAINT `patient_family_histories_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_family_histories` WRITE;
/*!40000 ALTER TABLE `patient_family_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_family_histories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `appointment_id` bigint(20) unsigned DEFAULT NULL,
  `reason_for_consultation` varchar(255) NOT NULL,
  `entry_type` enum('consultation','follow_up','emergency','note') NOT NULL,
  `symptoms` text DEFAULT NULL,
  `diagnosis` text NOT NULL,
  `treatment_plan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_histories_patient_id_foreign` (`patient_id`),
  KEY `patient_histories_doctor_id_foreign` (`doctor_id`),
  KEY `patient_histories_appointment_id_foreign` (`appointment_id`),
  CONSTRAINT `patient_histories_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `patient_histories_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_histories_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_histories` WRITE;
/*!40000 ALTER TABLE `patient_histories` DISABLE KEYS */;
INSERT INTO `patient_histories` VALUES (1,1,1,NULL,'dolor abdominal en la parte baja desde hace 4 días','consultation','sintomas','diagnostico','plan de tratamiento','2026-06-21 17:33:18','2026-06-21 17:33:18');
/*!40000 ALTER TABLE `patient_histories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_history_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_history_attachments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `1` (`patient_id`),
  CONSTRAINT `1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_history_attachments` WRITE;
/*!40000 ALTER TABLE `patient_history_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_history_attachments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_medications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_medications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `dosage` varchar(255) DEFAULT NULL,
  `frequency` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_medications_patient_id_foreign` (`patient_id`),
  CONSTRAINT `patient_medications_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_medications` WRITE;
/*!40000 ALTER TABLE `patient_medications` DISABLE KEYS */;
INSERT INTO `patient_medications` VALUES (1,1,'albumina','200mg','12 horas','en las mañanas',1,'2026-06-21 17:33:18','2026-06-21 17:33:18');
/*!40000 ALTER TABLE `patient_medications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_surgeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_surgeries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `year` year(4) DEFAULT NULL,
  `observations` text DEFAULT NULL,
  `anesthesia_complications` tinyint(1) NOT NULL DEFAULT 0,
  `anesthesia_details` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_surgeries_patient_id_foreign` (`patient_id`),
  CONSTRAINT `patient_surgeries_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_surgeries` WRITE;
/*!40000 ALTER TABLE `patient_surgeries` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_surgeries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `identification` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `blood_type` enum('A+','A-','B+','B-','O+','O-','AB+','AB-') DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `weight` decimal(5,2) DEFAULT NULL,
  `height` decimal(3,2) DEFAULT NULL,
  `insurance_id` bigint(20) unsigned DEFAULT NULL,
  `permanent_conditions` text DEFAULT NULL,
  `department_id` varchar(5) DEFAULT NULL,
  `city_id` varchar(5) DEFAULT NULL,
  `residence_zone` enum('Urbana','Rural') NOT NULL DEFAULT 'Urbana',
  `occupation` varchar(255) DEFAULT NULL,
  `civil_status` enum('Soltero/a','Casado/a','Unión Libre','Divorciado/a','Viudo/a') DEFAULT NULL,
  `ethnicity` enum('Indígena','Rrom (Gitano)','Raizal (San Andrés y Providencia)','Palenquero (San Basilio de Palenque)','Negro, Mulato, Afrocolombiano','Ninguna de las anteriores (Mestizo/Blanco)') NOT NULL DEFAULT 'Ninguna de las anteriores (Mestizo/Blanco)',
  `affiliation_type` enum('Contributivo','Subsidiado','Vinculado','Particular','Otro') DEFAULT NULL,
  `regime_type` enum('General','Especial','Excepción') NOT NULL DEFAULT 'General',
  `sisben_level` varchar(5) DEFAULT NULL,
  `emergency_contact_name` varchar(255) DEFAULT NULL,
  `emergency_contact_phone` varchar(255) DEFAULT NULL,
  `emergency_contact_relationship` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `patients_user_id_unique` (`user_id`),
  UNIQUE KEY `patients_identification_unique` (`identification`),
  KEY `patients_insurance_id_foreign` (`insurance_id`),
  CONSTRAINT `patients_insurance_id_foreign` FOREIGN KEY (`insurance_id`) REFERENCES `insurances` (`id`),
  CONSTRAINT `patients_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,10,'eyJpdiI6IkRiOGZOQWM1RzN5SzdlY0pHakhHanc9PSIsInZhbHVlIjoidFVUZStSVGtlMGJZMVgzdXA1NUtTUT09IiwibWFjIjoiZWRjOWUzZjkzY2RkZTNhN2VjNjUxOGE4ZTViYjVlYjM0NGI3YmI3NzI0MmQ4OTY5MDlkYTE2NDFhMTdkNmQ2MSIsInRhZyI6IiJ9','eyJpdiI6ImJVenl5U0tIWjdGZjNlV013SFFxdVE9PSIsInZhbHVlIjoiQ1dldmJncTlId2ptVlFidmZSOXhldz09IiwibWFjIjoiNzAwZjRjZjRlYWQzODI4ZmZmOTNjYWRlNjliNWY0MGZlNGZmMjA5ODUzYTlkYWRhZjI4NmRhMjk3MmEzOWYxMiIsInRhZyI6IiJ9','B-','1982-01-26','male',84.00,1.72,5,NULL,'76','76001','Urbana','Independiente','Unión Libre','Ninguna de las anteriores (Mestizo/Blanco)','Subsidiado','General','B3','eyJpdiI6IjErT2lJejF3RDdpbFBTbUVQaloybGc9PSIsInZhbHVlIjoiM2NQTWJEQVlpa1RrSUc4UE9ZbXhvSzFILzhueGphQm1VOW9wR3NyRldUTT0iLCJtYWMiOiI4MzJlNWFmYmY3ZDgzYTBjNDc5ODFhNGYzNTQ0MGZiYjU3OTRlNjdhNDg4NDIwZGExZWNkMTQ5MTg4Njc0NWUyIiwidGFnIjoiIn0=','eyJpdiI6IlZjeFJoTk0ybVJaMzc0MzUzaFlDVWc9PSIsInZhbHVlIjoidXVsZVVLSW9sNFgzYnBTdVJzdEYzdz09IiwibWFjIjoiOTZmMjg1YzE4OTc3NjU3YTZhYzQ0MWVjMWQ2NzFhMzc2MzEzYzExZGE4YjM1ZjFmYTg3ZWM1ZTY2NmZiMTBlYSIsInRhZyI6IiJ9','Cónyuge/Compañero','2026-06-24 04:09:17','2026-06-23 23:19:21');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `plans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `plan` varchar(255) NOT NULL,
  `applicable_role` enum('doctor','clinic','patient') NOT NULL DEFAULT 'doctor',
  `max_addresses` int(11) NOT NULL DEFAULT 2,
  `max_services` int(11) NOT NULL DEFAULT 3,
  `max_doctors` int(11) NOT NULL DEFAULT 1,
  `max_appointments_per_year` int(11) NOT NULL DEFAULT 50,
  `can_search_patients` tinyint(1) NOT NULL DEFAULT 0,
  `can_see_whatsapp_contact_button` tinyint(1) NOT NULL DEFAULT 0,
  `max_patients_list` int(11) NOT NULL DEFAULT 20,
  `can_export_history` tinyint(1) NOT NULL DEFAULT 0,
  `has_telemedicine` tinyint(1) NOT NULL DEFAULT 1,
  `ai_scribe_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plans_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` VALUES (1,'Plan Free','free','free','doctor',2,3,1,50,0,0,20,0,1,1,0.00,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(2,'Plan Premium','premium','premium','doctor',10,20,1,500,1,1,200,1,1,1,500000.00,0,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(3,'Plan Gold','gold','gold','doctor',20,50,1,9999,1,1,10000,1,1,1,300000.00,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(4,'Plan Clínica Gold','clinic_gold','clinic_gold','clinic',15,100,25,99999,1,1,50000,1,1,1,8500000.00,1,'2026-06-07 12:46:47','2026-06-07 12:46:47');
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `rating` tinyint(3) unsigned NOT NULL,
  `comment` text DEFAULT NULL,
  `reviewable_type` varchar(255) NOT NULL,
  `reviewable_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_user_id_foreign` (`user_id`),
  KEY `reviews_reviewable_type_reviewable_id_index` (`reviewable_type`,`reviewable_id`),
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'patient','web','2026-06-07 12:46:47','2026-06-07 12:46:47'),(2,'doctor','web','2026-06-07 12:46:47','2026-06-07 12:46:47'),(3,'admin','web','2026-06-07 12:46:47','2026-06-07 12:46:47'),(4,'receptionist','web','2026-06-07 12:46:47','2026-06-07 12:46:47'),(5,'clinic','web','2026-06-07 12:46:47','2026-06-07 12:46:47');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned DEFAULT NULL,
  `address_id` bigint(20) unsigned NOT NULL,
  `clinic_id` bigint(20) unsigned DEFAULT NULL,
  `day` tinyint(3) unsigned NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schedules_address_doctor_day_index` (`address_id`,`doctor_id`,`day`),
  KEY `schedules_doctor_day_index` (`doctor_id`,`day`),
  KEY `schedules_clinic_id_index` (`clinic_id`),
  KEY `schedules_doctor_clinic_day_index` (`doctor_id`,`clinic_id`,`day`),
  CONSTRAINT `schedules_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedules_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedules_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (1,1,2,NULL,1,'06:00:00','18:00:00',1,'2026-06-08 10:32:37','2026-06-08 10:32:37'),(2,1,2,NULL,3,'06:00:00','18:00:00',1,'2026-06-08 10:32:37','2026-06-08 10:32:37'),(3,1,2,NULL,4,'06:00:00','18:00:00',1,'2026-06-08 10:32:37','2026-06-08 10:32:37'),(4,1,2,NULL,6,'08:00:00','12:00:00',1,'2026-06-08 10:32:37','2026-06-08 10:33:58'),(5,1,9,NULL,1,'06:00:00','18:00:00',1,'2026-06-08 10:34:57','2026-06-08 10:34:57'),(6,1,9,NULL,2,'06:00:00','18:00:00',1,'2026-06-08 10:34:57','2026-06-08 10:34:57'),(7,1,9,NULL,3,'06:00:00','18:00:00',1,'2026-06-08 10:34:57','2026-06-08 10:34:57'),(8,1,9,NULL,4,'06:00:00','18:00:00',1,'2026-06-08 10:34:57','2026-06-08 10:34:57'),(9,1,9,NULL,5,'06:00:00','18:00:00',1,'2026-06-08 10:34:57','2026-06-08 10:34:57'),(10,1,9,NULL,6,'08:00:00','13:00:00',1,'2026-06-08 10:34:57','2026-06-08 10:35:26'),(11,7,8,NULL,1,'06:00:00','18:00:00',1,'2026-06-08 11:09:08','2026-06-08 11:09:08'),(12,7,8,NULL,2,'06:00:00','18:00:00',1,'2026-06-08 11:09:08','2026-06-08 11:09:08'),(13,7,8,NULL,3,'06:00:00','18:00:00',1,'2026-06-08 11:09:08','2026-06-08 11:09:08'),(14,7,8,NULL,4,'06:00:00','18:00:00',1,'2026-06-08 11:09:08','2026-06-08 11:09:08'),(15,7,8,NULL,5,'06:00:00','17:00:00',1,'2026-06-08 11:09:08','2026-06-12 20:10:05'),(17,7,10,NULL,1,'06:00:00','18:00:00',1,'2026-06-08 11:10:09','2026-06-08 11:10:09'),(18,7,10,NULL,2,'06:00:00','18:00:00',1,'2026-06-08 11:10:09','2026-06-08 11:10:09'),(19,7,10,NULL,3,'06:00:00','18:00:00',1,'2026-06-08 11:10:09','2026-06-08 11:10:09'),(20,7,10,NULL,4,'06:00:00','18:00:00',1,'2026-06-08 11:10:09','2026-06-08 11:10:09'),(21,7,10,NULL,5,'06:00:00','18:00:00',1,'2026-06-08 11:10:09','2026-06-08 11:10:09'),(23,7,1,NULL,6,'08:00:00','13:00:00',1,'2026-06-12 20:14:39','2026-06-12 20:14:39'),(24,7,11,NULL,6,'09:22:00','13:00:00',1,'2026-06-12 20:23:03','2026-06-12 20:23:03'),(25,7,8,NULL,6,'14:00:00','16:30:00',1,'2026-06-12 20:32:21','2026-06-12 20:32:21');
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `search_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `specialty` varchar(100) NOT NULL,
  `city` varchar(255) NOT NULL DEFAULT 'unknown',
  `country` varchar(255) NOT NULL DEFAULT 'unknown',
  `ip_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `search_logs_specialty_index` (`specialty`),
  KEY `search_logs_city_index` (`city`)
) ENGINE=InnoDB AUTO_INCREMENT=524 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `search_logs` WRITE;
/*!40000 ALTER TABLE `search_logs` DISABLE KEYS */;
INSERT INTO `search_logs` VALUES (2,'audiologia','cali','Colombia','179.1.48.56','2026-06-17 08:05:44','2026-06-17 08:05:44'),(3,'ginecologia','columbus','United States','216.73.216.79','2026-06-17 08:13:40','2026-06-17 08:13:40'),(44,'ginecologia','cali','Colombia','179.1.48.56','2026-06-17 12:22:09','2026-06-17 12:22:09'),(45,'ginecologia','cali','Colombia','179.1.48.56','2026-06-17 12:24:52','2026-06-17 12:24:52'),(46,'ginecologia','cali','Colombia','179.1.48.56','2026-06-17 12:25:27','2026-06-17 12:25:27'),(48,'urologia','unknown','United States','66.249.68.71','2026-06-17 15:20:04','2026-06-17 15:20:04'),(52,'alergologia','cali','United States','74.125.210.37','2026-06-17 20:20:21','2026-06-17 20:20:21'),(53,'pediatria','unknown','United States','66.249.68.64','2026-06-17 22:52:05','2026-06-17 22:52:05'),(54,'dermatologia','amsterdam','The Netherlands','185.214.74.190','2026-06-18 06:26:34','2026-06-18 06:26:34'),(62,'urologia','unknown','United States','66.249.68.64','2026-06-19 00:11:51','2026-06-19 00:11:51'),(63,'ginecologia','unknown','United States','66.249.79.171','2026-06-19 02:41:51','2026-06-19 02:41:51'),(64,'pediatria','columbus','United States','216.73.216.79','2026-06-19 03:24:59','2026-06-19 03:24:59'),(65,'cardiologia','columbus','United States','216.73.216.79','2026-06-19 03:35:10','2026-06-19 03:35:10'),(66,'traumatologia','columbus','United States','216.73.216.79','2026-06-19 03:35:38','2026-06-19 03:35:38'),(67,'oftalmologia','columbus','United States','216.73.216.79','2026-06-19 03:40:00','2026-06-19 03:40:00'),(68,'otorrinolaringologia','columbus','United States','216.73.216.79','2026-06-19 03:41:09','2026-06-19 03:41:09'),(69,'urologia','columbus','United States','216.73.216.79','2026-06-19 03:43:59','2026-06-19 03:43:59'),(75,'otorrinolaringologia','unknown','United States','66.249.79.171','2026-06-19 08:18:53','2026-06-19 08:18:53'),(76,'ginecologia','atlanta','United States','74.7.242.31','2026-06-19 10:24:28','2026-06-19 10:24:28'),(77,'dermatologia','atlanta','United States','74.7.242.31','2026-06-19 10:24:33','2026-06-19 10:24:33'),(78,'medicina-general','atlanta','United States','74.7.242.31','2026-06-19 10:24:38','2026-06-19 10:24:38'),(79,'traumatologia','atlanta','United States','74.7.242.31','2026-06-19 10:24:55','2026-06-19 10:24:55'),(80,'cardiologia','atlanta','United States','74.7.242.31','2026-06-19 10:24:56','2026-06-19 10:24:56'),(81,'oftalmologia','atlanta','United States','74.7.242.31','2026-06-19 10:24:56','2026-06-19 10:24:56'),(82,'pediatria','atlanta','United States','74.7.242.31','2026-06-19 10:24:57','2026-06-19 10:24:57'),(83,'otorrinolaringologia','atlanta','United States','74.7.242.31','2026-06-19 10:24:58','2026-06-19 10:24:58'),(84,'urologia','atlanta','United States','74.7.242.31','2026-06-19 10:24:59','2026-06-19 10:24:59'),(85,'medicina-general','unknown','United States','66.249.79.172','2026-06-19 10:55:55','2026-06-19 10:55:55'),(86,'dermatologia','unknown','United States','66.249.68.71','2026-06-19 11:58:23','2026-06-19 11:58:23'),(87,'ginecologia','unknown','United States','66.249.68.64','2026-06-19 12:05:22','2026-06-19 12:05:22'),(88,'ginecologia','unknown','United States','66.249.79.172','2026-06-19 13:25:22','2026-06-19 13:25:22'),(89,'','singapore','Singapore','43.156.250.82','2026-06-19 16:12:17','2026-06-19 16:12:17'),(90,'','singapore','Singapore','43.156.67.44','2026-06-19 22:23:10','2026-06-19 22:23:10'),(91,'endocrinologia','cali','Colombia','179.1.48.56','2026-06-20 00:22:51','2026-06-20 00:22:51'),(92,'','santa-clara','United States','43.153.26.165','2026-06-20 00:36:13','2026-06-20 00:36:13'),(93,'endocrinologia','cali','Colombia','179.1.48.56','2026-06-20 00:49:15','2026-06-20 00:49:15'),(94,'endocrinologia','unknown','United States','173.194.92.191','2026-06-20 00:49:20','2026-06-20 00:49:20'),(95,'urologia','unknown','United States','66.249.68.65','2026-06-20 03:23:08','2026-06-20 03:23:08'),(96,'medicina-general','unknown','Sweden','192.71.142.134','2026-06-20 07:18:31','2026-06-20 07:18:31'),(97,'cardiologia','chicago','United States','88.216.68.132','2026-06-20 10:15:32','2026-06-20 10:15:32'),(98,'medicina-general','unknown','Sweden','192.36.109.78','2026-06-20 10:56:49','2026-06-20 10:56:49'),(99,'medicina-general','ashburn','United States','43.165.65.117','2026-06-20 12:30:32','2026-06-20 12:30:32'),(100,'traumatologia','ashburn','United States','170.106.35.137','2026-06-20 12:41:19','2026-06-20 12:41:19'),(101,'dermatologia','santa-clara','United States','43.162.103.213','2026-06-20 13:18:21','2026-06-20 13:18:21'),(102,'otorrinolaringologia','tokyo','Japan','43.165.167.69','2026-06-20 13:20:39','2026-06-20 13:20:39'),(103,'medicina-general','singapore','Singapore','43.128.89.111','2026-06-20 13:27:13','2026-06-20 13:27:13'),(104,'dermatologia','hong-kong','Hong Kong','43.154.140.188','2026-06-20 13:27:51','2026-06-20 13:27:51'),(105,'pediatria','frankfurt-am-main','Germany','43.131.32.36','2026-06-20 14:18:03','2026-06-20 14:18:03'),(106,'cardiologia','hong-kong','Hong Kong','124.156.157.91','2026-06-20 14:36:51','2026-06-20 14:36:51'),(108,'pediatria','singapore','Singapore','43.160.219.138','2026-06-20 14:57:16','2026-06-20 14:57:16'),(109,'medicina-general','ashburn','United States','43.166.134.114','2026-06-20 15:10:39','2026-06-20 15:10:39'),(110,'otorrinolaringologia','unknown','Japan','43.167.239.66','2026-06-20 16:07:33','2026-06-20 16:07:33'),(111,'urologia','sao-paulo','Brazil','43.157.147.3','2026-06-20 16:16:41','2026-06-20 16:16:41'),(112,'ginecologia','unknown','United States','66.249.79.172','2026-06-20 17:36:24','2026-06-20 17:36:24'),(113,'dermatologia','santa-clara','United States','43.159.141.150','2026-06-20 18:57:31','2026-06-20 18:57:31'),(115,'ginecologia','hong-kong','Hong Kong','129.226.174.80','2026-06-20 19:11:04','2026-06-20 19:11:04'),(116,'dermatologia','unknown','United States','66.249.79.171','2026-06-20 20:01:25','2026-06-20 20:01:25'),(117,'traumatologia','tokyo','Japan','43.165.174.53','2026-06-20 21:29:14','2026-06-20 21:29:14'),(118,'traumatologia','ashburn','United States','43.165.65.117','2026-06-21 03:39:14','2026-06-21 03:39:14'),(119,'cardiologia','unknown','United States','66.249.68.65','2026-06-21 10:40:30','2026-06-21 10:40:30'),(120,'ginecologia','singapore','Singapore','43.134.162.36','2026-06-21 12:14:40','2026-06-21 12:14:40'),(121,'pediatria','ashburn','United States','43.165.67.31','2026-06-21 15:09:07','2026-06-21 15:09:07'),(122,'oftalmologia','frankfurt-am-main','Germany','49.51.141.76','2026-06-21 21:29:38','2026-06-21 21:29:38'),(123,'cardiologia','unknown','United States','66.249.79.171','2026-06-22 03:49:34','2026-06-22 03:49:34'),(124,'traumatologia','unknown','United States','66.249.79.171','2026-06-22 03:57:28','2026-06-22 03:57:28'),(125,'urologia','unknown','United States','66.249.79.172','2026-06-22 04:05:22','2026-06-22 04:05:22'),(126,'pediatria','atlanta','United States','74.7.243.235','2026-06-22 04:07:20','2026-06-22 04:07:20'),(127,'traumatologia','atlanta','United States','74.7.243.235','2026-06-22 04:07:30','2026-06-22 04:07:30'),(128,'pediatria','unknown','United States','66.249.79.172','2026-06-22 04:13:15','2026-06-22 04:13:15'),(129,'dermatologia','unknown','United States','66.249.79.170','2026-06-22 04:51:31','2026-06-22 04:51:31'),(130,'urologia','unknown','United States','66.249.79.170','2026-06-22 05:01:24','2026-06-22 05:01:24'),(131,'medicina-general','unknown','United States','216.244.66.249','2026-06-22 06:33:28','2026-06-22 06:33:28'),(132,'urologia','ashburn','United States','170.106.15.3','2026-06-22 06:59:22','2026-06-22 06:59:22'),(133,'ginecologia','singapore','Singapore','43.134.177.47','2026-06-22 07:07:54','2026-06-22 07:07:54'),(134,'oftalmologia','unknown','United States','66.249.79.172','2026-06-22 07:38:37','2026-06-22 07:38:37'),(135,'oftalmologia','unknown','United States','66.249.79.171','2026-06-22 07:48:37','2026-06-22 07:48:37'),(136,'otorrinolaringologia','unknown','Singapore','101.33.80.42','2026-06-22 08:51:43','2026-06-22 08:51:43'),(137,'auxiliar-de-enfermeria','cali','Colombia','179.1.48.56','2026-06-22 08:56:51','2026-06-22 08:56:51'),(138,'auxiliar-de-enfermeria','cali','Colombia','179.1.48.56','2026-06-22 08:57:21','2026-06-22 08:57:21'),(139,'auxiliar-de-enfermeria','cali','Colombia','179.1.48.56','2026-06-22 08:57:29','2026-06-22 08:57:29'),(140,'auxiliar-de-enfermeria','cali','Colombia','179.1.48.56','2026-06-22 08:59:15','2026-06-22 08:59:15'),(141,'oftalmologia','hong-kong','Hong Kong','119.28.140.106','2026-06-22 10:10:36','2026-06-22 10:10:36'),(142,'cardiologia','ashburn','United States','43.165.65.117','2026-06-22 10:19:14','2026-06-22 10:19:14'),(143,'cardiologia','frankfurt-am-main','Germany','43.157.62.101','2026-06-22 13:31:43','2026-06-22 13:31:43'),(176,'auxiliar-de-enfermeria','cali','Colombia','179.1.48.56','2026-06-22 17:21:58','2026-06-22 17:21:58'),(177,'medicina-general','cali','Colombia','179.1.48.56','2026-06-22 17:22:12','2026-06-22 17:22:12'),(178,'general','cali','Colombia','179.1.48.56','2026-06-22 17:22:40','2026-06-22 17:22:40'),(179,'medicina-general','cali','Colombia','179.1.48.56','2026-06-22 17:23:36','2026-06-22 17:23:36'),(180,'ginecologia','unknown','United States','66.249.79.170','2026-06-22 17:47:52','2026-06-22 17:47:52'),(181,'otorrinolaringologia','unknown','United Kingdom','185.191.171.15','2026-06-22 18:18:32','2026-06-22 18:18:32'),(182,'ginecologia','ashburn','United States','85.208.96.200','2026-06-22 19:15:49','2026-06-22 19:15:49'),(183,'alergologia','santa-clara','United States','170.106.72.178','2026-06-22 21:28:41','2026-06-22 21:28:41'),(186,'ginecologia','unknown','United States','216.244.66.249','2026-06-22 23:17:25','2026-06-22 23:17:25'),(187,'ginecologia','atlanta','United States','74.7.243.235','2026-06-23 04:11:16','2026-06-23 04:11:16'),(188,'dermatologia','atlanta','United States','74.7.243.235','2026-06-23 04:11:18','2026-06-23 04:11:18'),(521,'oftalmologia','santa-clara','United States','170.106.187.106','2026-06-23 20:28:31','2026-06-23 20:28:31'),(522,'urologia','frankfurt-am-main','Germany','43.157.62.101','2026-06-23 20:40:02','2026-06-23 20:40:02'),(523,'alergologia','cali','Colombia','179.1.48.56','2026-06-23 23:37:54','2026-06-23 23:37:54');
/*!40000 ALTER TABLE `search_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `service_specialty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_specialty` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `service_id` bigint(20) unsigned NOT NULL,
  `specialty_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_specialty_tenant_unique` (`service_id`,`specialty_id`,`user_id`),
  KEY `service_specialty_search_idx` (`specialty_id`,`user_id`),
  KEY `service_specialty_owner_idx` (`user_id`,`service_id`),
  CONSTRAINT `service_specialty_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_specialty_specialty_id_foreign` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_specialty_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `service_specialty` WRITE;
/*!40000 ALTER TABLE `service_specialty` DISABLE KEYS */;
INSERT INTO `service_specialty` VALUES (5,2,24,3,'2026-06-08 12:03:38','2026-06-12 19:32:42'),(6,2,49,3,'2026-06-08 12:03:38','2026-06-12 19:32:42'),(7,2,99,9,'2026-06-08 12:03:38','2026-06-08 12:03:38'),(8,2,3,9,'2026-06-08 12:03:38','2026-06-08 12:03:38'),(9,3,3,9,'2026-06-08 12:17:20','2026-06-08 12:17:20'),(20,2,58,3,'2026-06-12 19:32:42','2026-06-12 19:32:42'),(21,2,69,3,'2026-06-12 19:32:42','2026-06-12 19:32:42'),(22,5,24,2,'2026-06-13 17:33:44','2026-06-13 17:33:44'),(25,1,24,3,'2026-06-17 11:28:03','2026-06-17 11:28:03'),(26,1,58,3,'2026-06-17 11:28:03','2026-06-17 11:28:03'),(27,1,49,3,'2026-06-17 11:28:03','2026-06-17 11:28:03'),(28,1,69,3,'2026-06-17 11:28:03','2026-06-17 11:28:03');
/*!40000 ALTER TABLE `service_specialty` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` enum('physical','virtual') NOT NULL DEFAULT 'physical',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (1,'Consulta por Telemedicina','virtual',1,'2026-06-08 12:02:40','2026-06-08 12:02:40'),(2,'Consulta de Control','physical',1,'2026-06-08 12:03:38','2026-06-08 12:03:38'),(3,'Servicio de Cardiología No Invasiva','physical',1,'2026-06-08 12:17:20','2026-06-08 12:17:20'),(4,'Implantación de Marcapasos y Desfibriladores','physical',1,'2026-06-12 08:21:53','2026-06-12 08:21:53'),(5,'Consulta de Inmunología Clínica','physical',1,'2026-06-13 17:33:44','2026-06-13 17:33:44');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('2BCuago5D7qFLHoNLH9rhbhbAO5bZmAO5CRwvOTO',NULL,'74.125.210.163','Google-Lens','eyJfdG9rZW4iOiJLVmVSWHF4eHlSU1BZSGFRenZ1ZVpwSXJ4aEN2SWYwY2w0YzBuV0NzIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL29wZW5kb2N0b3Iub25saW5lXC9kYXNoYm9hcmQifSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZVwvZGFzaGJvYXJkIiwicm91dGUiOiJhZG1pbi5kYXNoYm9hcmQifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1782274202),('2fjpO93P9d0bqx9OUrkHuBB9y6BOfYH8PqBIObx9',NULL,'43.128.149.102','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJ4cE5EYlQyaEI4V00xSFNwS3hZQUM3MlV0T1d2MlhjeFh5Q3M3Z3NUIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1782263770),('2gN5ZZRrFVzEJM2F7vXczIsfSS2GtiUix4WPgAlt',NULL,'74.125.210.164','Google-Lens','eyJfdG9rZW4iOiJlUDFkMEJpUWJ1MHBMdlU3aW9HWXBYYW5BaVhnbE9iUzBQNjVjQnBSIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZVwvbG9naW4iLCJyb3V0ZSI6ImxvZ2luIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782274202),('3kdahMmXijASE17xpQnHjnWOM0cUMQhOuBcAbVqB',NULL,'43.157.62.101','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJRQ0xqOGt3NGZmTDEwOEdlTlJxU29TaXI3WFN6akZsaEdXcmRZeVhFIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZVwvc2VhcmNoP2NpdHk9JnNwZWNpYWx0eT11cm9sb2dpYSIsInJvdXRlIjoic2VhcmNoIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782265202),('5zIPtmxqo2mOU0yKwf14GdVHgsHkOeDGXXnS5QGE',NULL,'190.34.58.244','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.86 Safari/537.36','eyJfdG9rZW4iOiJJSGhyNkE2S3RzWkpoNUFNUE55ZFI4NEdTQWdYVHNGenlaZWpsdnNrIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1782264480),('A62QyP3Cwd0hNSByCjzBEo3XxYFfaHnH09l9x9AQ',NULL,'179.1.48.56','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/30.0 Chrome/143.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJLeTJOWkVmendxQ3Fwb2dFd1dJcWJmRDUwWTE1TGtHRGt6NEs3c0o1IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZVwvc2VhcmNoP2NpdHk9JnNwZWNpYWx0eT1hbGVyZ29sb2dpYSIsInJvdXRlIjoic2VhcmNoIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782275874),('anYS2RNBt5JzbrTecWYpQuEnJ2eNBoVFNrNnutH0',NULL,'43.159.62.129','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJrOUtQbnBXbHFsWEVTZWJ4RjVQNzJYSDlDUnlSNWNnM1BGRkdHWWw0IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cub3BlbmRvY3Rvci5vbmxpbmVcL3NpbnRvbWFzXC9tYXJlb3MtY29uc3RhbnRlcy1hbC1tb3Zlci1sYS1jYWJlemEiLCJyb3V0ZSI6InN5bXB0b20ubGFuZGluZyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1782267688),('aOChcMlTiIYuiDwt2kQpsOaROQ8a2QwKmqJdfHJs',NULL,'97.107.131.17','','eyJfdG9rZW4iOiI5VkFtY3diUDRaM2FoTlZnNVBESFlCTDIzMUVUUmZ5aDRpM2NXTEF1IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9lYzItNDQtMjE0LTI1NC0zMS5jb21wdXRlLTEuYW1hem9uYXdzLmNvbSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1782269283),('AXkrcSgsekOb7RQBDq0o4MpSISbyRV5dWfaMZTYE',NULL,'97.107.131.17','','eyJfdG9rZW4iOiI5NlI0Wk5CVEtmUnE4MHdycmQzd0xBeEI2Nkk3bU5CaGtSZGVZOGVZIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1782269282),('cRGP84BuuNzdPMVlA4vEDmTxhSHzuS3Na4c1WWfw',NULL,'97.107.131.17','','eyJfdG9rZW4iOiJncFlxZzVlYWlKRzh0aDRQYjVRN25Rd243ajJBdmh0VG5ISjJvbzZoIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1782269283),('D4pnzUKCw4lpcS5W9zMoan6LYxclHDa55zCEof3g',NULL,'82.197.70.199','Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJ4NGxTRmw2SGhNdmFMUmxyRXRoQkFkSHNrZGVCSnVnZ2dTT0V1Znc1IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC80NC4yMTQuMjU0LjMxIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782272287),('D4u5ZtCOUQwHQN50m0pdGkqxv9LNQnY1ISRqozdc',10,'179.1.48.56','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJxdE1GNFBXUEN0MTZ6OHJvUEdIRWdRM212cW1Fb2I3M1NqS1QyNHlpIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cHM6XC9cL29wZW5kb2N0b3Iub25saW5lXC9kZXBhcnRtZW50c1wvNzZcL2NpdGllcyIsInJvdXRlIjpudWxsfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjEwLCJwYXNzd29yZF9oYXNoX3NhbmN0dW0iOiJiOGQ0MTUxOTM0ZDk2YmI2NTlmZWY4MmI1ZGEwMDYzNGExNjY0ODg1N2UwM2NkMjJhMmQzNzgzNDg1ZTZhNTA3In0=',1782274949),('fNC5TydODzWs6MFIhmwgw9jtQeY6QmIzLtXX69JA',NULL,'65.49.1.69','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/109.0','eyJfdG9rZW4iOiJxc1hySWpOY3lMdVFsS2lnYndnRXpaNmRaN3ZhVXRqWWJpV0ZkbnpYIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC80NC4yMTQuMjU0LjMxIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782270753),('fNL1fdNhBQcaArxwhNp5HpU4yxS3sn6yXcpI9lIb',NULL,'74.125.210.164','Google-Lens','eyJfdG9rZW4iOiJYZlRIdElGSXBsbDZ1SWVVVWxJVk16aTBYajZTZlBTODdibFpSWWdOIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL29wZW5kb2N0b3Iub25saW5lXC9wYXJ0bmVyXC9wcm9maWxlIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvb3BlbmRvY3Rvci5vbmxpbmVcL3BhcnRuZXJcL3Byb2ZpbGUiLCJyb3V0ZSI6InBhcnRuZXIucHJvZmlsZS5lZGl0In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782272818),('g8eTZLZTI8H6na3bKkdxWhyualv7SL2LqJehGFI9',NULL,'43.134.78.217','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJpTmcySFV4SEhkTTlWeWtPdFZKRVQwSFNvSmd5aW41Rk9IWVh0dEhtIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZVwvc2ludG9tYXNcL3Zpc2lvbi1ib3Jyb3NhLWRlLXJlcGVudGUtZW4tdW4tb2pvIiwicm91dGUiOiJzeW1wdG9tLmxhbmRpbmcifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1782265808),('Gh04GeTu9IP3Qq7y2FuofQZqXhFEbpfA69fwm3YS',NULL,'82.197.70.199','Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJUS3JyMm9zbXVJQkIwUFpJTHZ6ZnVyWWVCNk9hZTdJNzBUVTF1Rm96IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC80NC4yMTQuMjU0LjMxIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782262540),('iAwXATx3h33ifRDPZYIOZe2xX8Um3LhVk7dYd0Yr',1,'179.1.48.56','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/30.0 Chrome/143.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJVcHIzWW9PcDZLbUxOVFBpaWp1OERqTW5mZTViYTBGYXRKYms5bkU3IiwidXJsIjpbXSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoxLCJwYXNzd29yZF9oYXNoX3NhbmN0dW0iOiIwYjViYzdlNTYxNzc3MjA5OGYwZmU2YzA3YWRhMDEzMDNhZDMxZTE4OGY3OTJkZWY4ZjIxYmJkYjg0ZmI3NjdiIn0=',1782266560),('iPb3cQGrgdbMZHXs3vZDkmUvcRgrRsOC7tfIlR4p',NULL,'82.197.70.199','Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJEbFFMeE5XbVJzNUMwUEp5SmJpZHJQVnc2a1NSTG1zYWhBdDBRMmY5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC80NC4yMTQuMjU0LjMxIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782273964),('KxVgA5TBt0ugY8GlEr6g63TDPnoIVCmtiWUNiuyh',NULL,'66.249.79.172','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','eyJfdG9rZW4iOiJZU0Y4TVN0NVQ4YWZTeFNpbGdOQlpKTHVFQTJ3Q1pGaFNxb2QwYUpWIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZVwvc2ludG9tYXM/cGFnZT0yIiwicm91dGUiOiJzeW1wdG9tLmluZGV4In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782269606),('lhkGUty0AE2uJF9bBqe0jsrdlOoPFxgHfVXCAjzH',NULL,'82.197.70.199','Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJLQWM2RG1yaTFkQzN5eGZRYWFFb1B1d2xQUlREdWFzbjZDdlBBOXZmIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC80NC4yMTQuMjU0LjMxIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782267310),('LSsN3dF97eaJ2nr9k7Krxvkqma4mfW22EYOt7UYA',NULL,'170.106.187.106','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJIOHB2eUlOQTdGWW5vaGdYeUJrVjd4dUJZQzFaU2J6Z2NGRXlhV3RNIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZVwvc2VhcmNoP2NpdHk9JnNwZWNpYWx0eT1vZnRhbG1vbG9naWEiLCJyb3V0ZSI6InNlYXJjaCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1782264511),('LtJgHm6T1dLkaQe3mAtyECU0K0LeZPcRW4yuEVRo',NULL,'82.197.70.199','Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJBb2luUGRKeTJ4MXYyMlcwMXI2SnN3b3NXMU9WY0l5V2dFWGFHaUV3IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC80NC4yMTQuMjU0LjMxIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782265721),('NgDTMNDtZ9HccsDz95WjiWPJrIHVlFxJ330jNLpi',NULL,'49.51.141.76','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJ5V0lYN3c0WEJoeXJCcUx5VENZR1VvZUhjVkxLMVFJM3hEUU41TzR5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cub3BlbmRvY3Rvci5vbmxpbmUiLCJyb3V0ZSI6ImhvbWUifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1782262568),('NYbHVdqGUWFU3pG7Ts2Ltqz2Knsnv2hOrjn0OWEo',NULL,'66.249.79.170','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','eyJfdG9rZW4iOiJtNEJLam1Ta0l5MDY2VnBpaUNCNm02VjRjSXdBQ2pNMnN5cksyS1VXIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZVwvc2ludG9tYXNcL21lLWR1ZWxlLWxhLWNhYmV6YSIsInJvdXRlIjoic3ltcHRvbS5sYW5kaW5nIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782274106),('oKNo8Udr9TzbMXO9i88KXAWGbNyaD7RqNzLEpUf2',NULL,'51.161.37.119','Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)','eyJfdG9rZW4iOiJoRnU5VjdyUmdVMEU5MTJYTXBYNXUxdXBjUmNmc1hqczJDVTFVWVJlIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1782266521),('p0axhKTSmCCaS5UHXjh8qVWS8DqoyU0ydQBDzH2j',NULL,'43.134.163.229','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJ6YkNXYVB3d2dHOEJSZ1hWVTF0a1JsckpRSnNwdTFTT1RkSUFCME9kIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cub3BlbmRvY3Rvci5vbmxpbmUiLCJyb3V0ZSI6ImhvbWUifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1782266880),('pfRh7cdxhITate3bEKWPn9GPt4UHiMOIiRbbmgVn',NULL,'82.197.70.199','Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJZM1lzVW5EWEdsdkFuRndvUmNERGNWVHdVOU5IbjVvTmhlNmdKZW9MIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC80NC4yMTQuMjU0LjMxIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782277297),('psb1PJ4u73UufkuuByHAV389n0V3Hp1vZXifV1ts',NULL,'74.125.210.162','Google-Lens','eyJfdG9rZW4iOiIxNHRZS1lzc0toYXNab29LdnN1dGQ5dEFkWWNPVEhWd2pVNnc2cXZnIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL29wZW5kb2N0b3Iub25saW5lXC9wYXJ0bmVyXC9wcm9maWxlIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvb3BlbmRvY3Rvci5vbmxpbmVcL3BhcnRuZXJcL3Byb2ZpbGUiLCJyb3V0ZSI6InBhcnRuZXIucHJvZmlsZS5lZGl0In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782273123),('QUqQjxuN72m8RQhVztALwdu2mGtTMP8SSUx5e8vQ',NULL,'153.180.187.144','python-requests/2.28.1','eyJfdG9rZW4iOiJsc2hoa1NpeXVoQ3JTVWUwSzBRQVN0NDhtdm5RTEp0S2x4RWJmM3hqIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC80NC4yMTQuMjU0LjMxIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782263283),('r1FpMb7nIM6wY8e6cfN7k14BvLfBFSssTlsXFpBl',NULL,'74.125.210.163','Google-Lens','eyJfdG9rZW4iOiJRQXgyM2lINVFBRlFDUjVZUnQ2U3ExamJYYWlrWlc1OWFPY2s5alJzIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZVwvbG9naW4iLCJyb3V0ZSI6ImxvZ2luIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782272818),('Rvgv469tes6K5vZyzje0aaIYnmOfESpNVNgAHOoZ',NULL,'74.125.210.164','Google-Lens','eyJfdG9rZW4iOiI1MGJOaHNPTm5DcTZlWmNObnl0NVB4TXdCaldXcGxPeHE0dWVOT2RxIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZVwvbG9naW4iLCJyb3V0ZSI6ImxvZ2luIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782273123),('tD8oJSgSecaS8wtD37qDhOMFC6IyaSkW9LHdU1hG',NULL,'176.65.139.238','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJzUVRPdVkxYmFTWlk0TXMyVHJMZDVybHcwd3BYaWtoYzBQVWJjT25FIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1782266446),('uK86j41IIP1ezca2G51YCYTGmulm4KiEhl1NBV1s',NULL,'51.222.168.202','Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)','eyJfdG9rZW4iOiJlUjZadHJBSFRIR1hMRXJqc2FpR0FaY3REaGJkd2N4MHJCRHZuTDJRIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1782272267),('veH1fDr7MGwGcukjqKPrPGaij8iUQmqS7ljQCQzc',NULL,'216.244.66.249','Mozilla/5.0 (compatible; DotBot/1.2; +https://opensiteexplorer.org/dotbot; help@moz.com)','eyJfdG9rZW4iOiJuR2tBUUZ0M1MycnZDRlozS3oycjFSdkdZeG5rU0dBbU80bDJIRmozIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZVwvZXhhbWVuZXMiLCJyb3V0ZSI6ImV4YW1zLmluZGV4In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782274310),('vrfS3svlQ1bszha14qKb0MY1L1pY11njUgovBu3F',NULL,'82.197.70.199','Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiI1MUxJNEM3NXkwbUlFNmF1a21UR1ZBdkFVOGNIUGJtNEh0eFVSNUZ0IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC80NC4yMTQuMjU0LjMxIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782268919),('wUoMzC5NnZ16WIYkmzkZZiTlexX1iggzoqkcYj12',NULL,'66.132.195.115','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','eyJfdG9rZW4iOiI2eDVkS0RyNFFsYVFNdDFRVXVHUDV2Q0psZDlaTWc5TUZJUnU1U3Z4IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC80NC4yMTQuMjU0LjMxXC9sb2dpbiIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1782276801),('YdLxVPPKRYJbhXKKm1vEO7zAd4U6YQb7mc0F9Doo',NULL,'16.58.56.214','visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJJZ0FtSFpvR3ZWdndEdXpTYnJRNDBPZ296eXZYazd4eXJTWXAzUmVoIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC80NC4yMTQuMjU0LjMxIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1782272681),('YZ70lElZui26elYaPhX5E8WEhv2I1mZrgPfydui9',NULL,'203.55.131.3','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJranpEMjBuZ2o3YzZzR1U1VG9qQkd6ejVUTElkMDBmc3I2U3ZnY2hEIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9vcGVuZG9jdG9yLm9ubGluZSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1782264092);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `group` varchar(255) NOT NULL DEFAULT 'general',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'medical_analysis_price','18700','saas','2026-06-19 17:52:03','2026-06-19 17:52:03'),(2,'support_email','soporte@opendoctor.online','saas','2026-06-19 17:52:03','2026-06-19 17:52:03');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `signed_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `signed_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `signable_type` varchar(255) NOT NULL,
  `signable_id` bigint(20) unsigned NOT NULL,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `patient_id` bigint(20) unsigned NOT NULL,
  `type` enum('prescription','clinical_record','incapacity','referral') NOT NULL,
  `document_hash` varchar(255) NOT NULL,
  `signature_hash` varchar(255) NOT NULL,
  `storage_path` varchar(255) NOT NULL,
  `signed_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `signed_by_ip` varchar(255) DEFAULT NULL,
  `status` enum('signed','revoked') NOT NULL DEFAULT 'signed',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `signed_documents_signable_type_signable_id_index` (`signable_type`,`signable_id`),
  KEY `signed_documents_doctor_id_foreign` (`doctor_id`),
  KEY `signed_documents_patient_id_foreign` (`patient_id`),
  CONSTRAINT `signed_documents_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`),
  CONSTRAINT `signed_documents_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `signed_documents` WRITE;
/*!40000 ALTER TABLE `signed_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `signed_documents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `specialties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `specialties` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `specialties_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `specialties` WRITE;
/*!40000 ALTER TABLE `specialties` DISABLE KEYS */;
INSERT INTO `specialties` VALUES (1,'Medicina General','medicina-general',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(2,'Psicólogia','psicologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(3,'Cardiología','cardiologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(4,'Pediatría','pediatria',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(5,'Dermatología','dermatologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(6,'Ginecología','ginecologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(7,'Otorrinolaringología','otorrinolaringologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(8,'Oftalmología','oftalmologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(9,'Psiquiatría','psiquiatria',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(10,'Traumatología','traumatologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(11,'Urología','urologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(12,'Ortopedista y Traumatólogia','ortopedista-y-traumatologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(13,'Odontólogia','odontologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(14,'Cirujano Plástico','cirujano-plastico',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(15,'Internista','internista',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(16,'Endocrinólogia','endocrinologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(17,'Neurólogia','neurologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(18,'Gastroenterólogia','gastroenterologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(19,'Cirujano General','cirujano-general',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(20,'Neurocirujano','neurocirujano',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(21,'Nutricionista','nutricionista',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(22,'Fisioterapeuta','fisioterapeuta',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(23,'Terapeuta Complementario','terapeuta-complementario',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(24,'Alergólogia','alergologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(25,'Reumatólogia','reumatologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(26,'Neumólogia','neumologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(27,'Cirujano Maxilofacial','cirujano-maxilofacial',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(28,'Cirujano Vascular','cirujano-vascular',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(29,'Médico Alternativo','medico-alternativo',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(30,'Fonoaudiílogia','fonoaudiilogia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(31,'Médico Fisiatra Rehabilitador','medico-fisiatra-rehabilitador',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(32,'Nefrólogia','nefrologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(33,'Médico Estetico','medico-estetico',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(34,'Sexologia','sexologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(35,'Hematólogia','hematologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(36,'Infectólogia','infectologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(37,'Neuropsicólogia','neuropsicologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(38,'oncólogo','oncologo',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(39,'Endocrinólogia Pediátrica','endocrinologia-pediatrica',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(40,'Neurólogia Pediátrica','neurologia-pediatrica',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(41,'Nutriólogia','nutriologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(42,'Neumólogia Pediátrica','neumologia-pediatrica',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(43,'Médico Laboral','medico-laboral',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(44,'Radiologia','radiologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(45,'Especialista en Medicina Deportiva','especialista-en-medicina-deportiva',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(46,'Cirujano Pediátrico','cirujano-pediatrico',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(47,'Geriatra','geriatra',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(48,'Cirujano de Cabeza y Cuello','cirujano-de-cabeza-y-cuello',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(49,'Anestesiólogia','anestesiologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(50,'Cirujano Cardiovascular','cirujano-cardiovascular',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(51,'Mastológia','mastologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(52,'Especialista en Medicina Familiar','especialista-en-medicina-familiar',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(53,'Podólogo','podologo',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(54,'Genetista','genetista',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(55,'Protólogo','protologo',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(56,'Terapeuta Ocupacional','terapeuta-ocupacional',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(57,'Especialista en Tratamiento del Dolor','especialista-en-tratamiento-del-dolor',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(58,'Audiólogia','audiologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(59,'Cirujano de Tórax','cirujano-de-torax',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(60,'Nefrólogia Pediátrica','nefrologia-pediatrica',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(61,'Coloproctólogia','coloproctologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(62,'Tecnico en Laboratorio','tecnico-en-laboratorio',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(63,'Hepatólogia','hepatologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(64,'Gastroenterólogo Pediátrico','gastroenterologo-pediatrico',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(65,'Toxicólogia','toxicologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(66,'Terapeuta Respiratorio','terapeuta-respiratorio',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(67,'Especialista en Cuidados Críticos','especialista-en-cuidados-criticos',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(68,'Ortopedista Infantil','ortopedista-infantil',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(69,'Cardiólogia Pediátrica','cardiologia-pediatrica',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(70,'Cirujano de Mama y Tejidos Blandos','cirujano-de-mama-y-tejidos-blandos',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(71,'Oftalmólogo Pediátrico','oftalmologo-pediatrico',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(72,'Epidemiólogia','epidemiologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(73,'Psiquiatra Infantil','psiquiatra-infantil',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(74,'Neurofisiólogia','neurofisiologia',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(75,'Infectólogo Pediatra','infectologo-pediatra',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(76,'Oncólogo Radioterápico','oncologo-radioterapico',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(77,'Alergólogo Pediátrico','alergologo-pediatrico',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(78,'Especialista en Medicina Nuclear','especialista-en-medicina-nuclear',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(79,'Especialista en Medicina Domiciliaria','especialista-en-medicina-domiciliaria',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(80,'Psicoanalista','psicoanalista',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(81,'Médico Vascular','medico-vascular',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(82,'Enfermero','enfermero',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(83,'Especialista en Medicina de Urgencias','especialista-en-medicina-de-urgencias',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(84,'Neuro Oftalmólogo','neuro-oftalmologo',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(85,'Perinatólogo','perinatologo',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(86,'Urólogo Pediátrico','urologo-pediatrico',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(87,'Auxiliar de Enfermería','auxiliar-de-enfermeria',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(88,'Ortodoncista','ortodoncista',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(89,'Reumatólogo Pediátrico','reumatologo-pediatrico',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(90,'Dermatólogo Pediátrico','dermatologo-pediatrico',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(91,'Especialista en Salud Pública','especialista-en-salud-publica',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(92,'Radioterapeuta','radioterapeuta',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(93,'Psicopedagogo','psicopedagogo',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(94,'Especialista en Medicina Aeroespacial','especialista-en-medicina-aeroespacial',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(95,'Odontopediatria','odontopediatria',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(96,'Homeópata','homeopata',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(97,'Oncólogo Pediátrico','oncologo-pediatrico',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(98,'Cirujano Oncólogo','cirujano-oncologo',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47'),(99,'Bacteriólogo','bacteriologo',NULL,1,'2026-06-07 12:46:47','2026-06-07 12:46:47');
/*!40000 ALTER TABLE `specialties` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `unavailabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `unavailabilities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_id` bigint(20) unsigned NOT NULL,
  `address_id` bigint(20) unsigned DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unavailabilities_doctor_id_foreign` (`doctor_id`),
  KEY `unavailabilities_address_id_foreign` (`address_id`),
  CONSTRAINT `unavailabilities_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `unavailabilities_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `unavailabilities` WRITE;
/*!40000 ALTER TABLE `unavailabilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `unavailabilities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `current_team_id` bigint(20) unsigned DEFAULT NULL,
  `profile_photo_path` varchar(2048) DEFAULT NULL,
  `role` enum('admin','doctor','patient','clinic') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Andres Ocampo','administrador@ejemplo.com','2026-06-07 12:46:47','$2y$12$5abaRZCsmkH3MTyqxN6dnu.9.Zikhm9sexsef0fbFivfEsX2pZqTa',NULL,NULL,NULL,'y00EX8Xn9f2btR8exptd067fWBdQ7Umk7mn9MJxihvbMtb2wf0o5KLtjI6Is',NULL,NULL,'admin','2026-06-07 12:46:48','2026-06-07 12:46:48'),(2,'Clínica Versalles','1985steps@gmail.com',NULL,'$2y$12$S8B1m02ak5XnS0NkA1ff1e.4VLLXOWu.C1G3FhLf4WFGVOuxL5frK',NULL,NULL,NULL,'NkOsFo1wMvYrCfn6piWdhktrKCyAXnjXKkjMdIsbin3xQWemCzp5D57ZQP9E',NULL,NULL,'clinic','2026-06-07 12:51:05','2026-06-07 12:51:05'),(3,'Juan Sebastian Chaparro Vargas','ocampotecnologo@gmail.com',NULL,'$2y$12$MGm.qeSJnU0H63i/oskEMOTFpQtjY3pOFKKvnc7lMe8Gccn6ExMKm',NULL,NULL,NULL,'4YGykZKBCo0YFAw79fH2SMN02rSjbmDNPOrHw4XTO5ut7XFNOwE9a55I32Sw',NULL,NULL,'doctor','2026-06-07 12:59:03','2026-06-07 12:59:03'),(9,'Pedro Pablo Pérez Pinzón','smartripreservas@gmail.com',NULL,'$2y$12$8Y8HstBMQLHOGeSG1smPhOaoL44MyI0kbmtqApx9BICCyKX.UyC/y',NULL,NULL,NULL,'fdexzAYTl5CzMS18gtscVORFht2E6i1PEpmnhqMWWTs5yJqDOgDEEZpCo6Nh',NULL,NULL,'doctor','2026-06-07 14:32:50','2026-06-08 10:57:24'),(10,'Pepito Perez lopez','cgoprayer@gmail.com',NULL,'$2y$12$wwQUXQd2QwgtXbka31kE1uXysH.FLNWvXtntJ2y5TPMPR981DfjwK',NULL,NULL,NULL,NULL,NULL,NULL,'patient','2026-06-11 05:51:27','2026-06-11 05:51:27');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `zoom_creation_failures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `zoom_creation_failures` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `appointment_id` bigint(20) unsigned NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `last_error` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `zoom_creation_failures_appointment_id_foreign` (`appointment_id`),
  CONSTRAINT `zoom_creation_failures_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `zoom_creation_failures` WRITE;
/*!40000 ALTER TABLE `zoom_creation_failures` DISABLE KEYS */;
/*!40000 ALTER TABLE `zoom_creation_failures` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

